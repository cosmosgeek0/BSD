BSD research history | 25 November 2026 (India time)
Project contact: admin@cosmosgeek.org

Reading order
1. BSD Conjecture.md is the original topical handoff. BSD-Pro-Handoff.txt.txt is the separate original Pro handoff.
2. The eight numbered source parts are the original files recovered from the BSD ChatGPT project. Together they cover entries 1–455. In part 08, entry 453 is the reconstructed p^4 cohomological bound, followed by a prior-work discussion and an internal review.
3. BSD-successor-research-note-2026-11-20.md is the original successor note, starting at 456 and ending at 655. Its numbered headings jump from 535 to 538; it uses one heading for 635/637. Entries 612–617 cover the explicit quadratic-twist sign and its comparison with central values. These are historical results and hypotheses, not 655 independently proved theorems.
4. bsd-source-conversations.md is a later preservation snapshot of assistant replies from 28 hosted project chats and their latest research-selection checks. It marks clipped replies, omits tool outputs, and links each retained conversation. Its coverage is limited to what the account returned. The earlier eleven files were exported from the hosted project without rewriting their contents.

A November 17 cumulative file named by a source chat was not found in the project source list and is not included. This archive does not establish that all work done during the month is present. Historical sandbox links may require the original account or may have expired. Treat unverified claims and superseded attempts as historical text.

Original project https://chatgpt.com/g/g-p-6af063133b8c8191a21408c978a0ca5b/project?tab=sources
Original successor chat https://chatgpt.com/c/6b007460-d838-83ec-b673-fe66dca8e493
Original handoff and item 453 review https://chatgpt.com/c/6af068e6-a3b4-8320-b137-01d03fe069a1
