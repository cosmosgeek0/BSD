# Birch–Swinnerton-Dyer — successor research note, 20 November 2026

## Target and provenance

**Unchanged full target:** prove for every elliptic curve \(E/\mathbf Q\) that
\(\operatorname{rank}E(\mathbf Q)=\operatorname{ord}_{s=1}L(E,s)\), or exhibit an actual rigorously checked counterexample. Finiteness of \(\Sha\) and the refined leading coefficient are distinct tasks. No full proof or counterexample is obtained here.

Read: the provided `BSD-Pro-Handoff.txt.txt` and focused sections of the eight numbered `BSD-research-record-01..08` attachments (especially 304, 318, 405–407, 419–427, 429–450, 451–455). Source-level statuses are retained, not upgraded: the all-prime A4 theorem (453) passed internal reconstruction, not external review or novelty certification. The restricted automorphic construction concerns prime-conductor \(E\), inert \(p\) in \(K=\mathbf Q(\sqrt{-2})\), an auxiliary form \(g\ne E\), residual surjectivity and Tate-period assumptions; even resolving its \(\lambda_g=1\) target does not prove the BSD rank equality of \(E\). The full-coefficient conditional bound of 318 and equality profile of 405 remain conditional. In particular, \(N\le3a\) does not rule out \(\lambda_g=3\).

The locally checked \(p=13,q=7\) matrix calculation and the known rank-two curve 389.a1 are **retained, not rerun**. The earlier local countermodels 441 and 452, global countermodel 407, and the conjugacy-invariant failure 447 are still barriers. No uploads, submissions, purchases, downloads or installations were made.

The attachment literally named `BSD Conjecture.md` and separate `GOAL.md`/`AGENTS.md` were not among the accessible files; this continuation uses the explicit objective and working rules in the supplied project handoff. The Clay problem page remains marked unsolved (checked 20 November 2026): <https://www.claymath.org/millennium/birch-and-swinnerton-dyer-conjecture/>.

## 456. A cyclotomic deformation can be nonconstant: the precise obstruction is a Tor defect

### Theorem (internally derived here; independent checking outstanding)

Let \(\mathcal O\) be a finite extension of \(\mathbf Z_p\), \(D=\mathcal O/\varpi^N\), \(R=D[\eta]/(\eta^2)\). Let \(\widetilde U\) be a finite \(R\)-module, and set
\[
 U=\widetilde U/\eta\widetilde U,\qquad W=\eta\widetilde U.
\]
The well-defined, surjective \(D\)-map
\[
 \pi:U\longrightarrow W,\qquad [u]\longmapsto\eta u
\]
has kernel
\[
 \Delta_\eta=\widetilde U[\eta]/\eta\widetilde U
 \cong\operatorname{Tor}_1^R(\widetilde U,D).
\]

Let \(K=\mathbf Q(\sqrt{-2})\), \(S=\{\mathfrak p\}\cup\{\mathfrak l: \ell\mid m\}\), where \(p\ge11\) is inert, the aux primes \(\ell\) are inert, and the normalized cyclotomic values \(b_\ell=\kappa_{\rm cyc}(\operatorname{Frob}_{\mathfrak l})\in D^\times\) have been selected as in research item 448. Give \(\widetilde U\) the scalar action
\[
 g\cdot u=\epsilon(g)(1+\eta\kappa_{\rm cyc}(g))u.
\]
Suppose \(c= u_p[p]+\sum_{\ell\mid m}u_\ell[\ell]\in H^1(G_{K,S},U(1))\) lifts to a class of \(H^1(G_{K,S},\widetilde U)\) with this twisted action. Then
\[
 \pi(u_\ell)=0\qquad(\ell\mid m).
\]
In particular
\[
 T_{\rm tame}:=\sum_{\ell\mid m}D u_\ell\subseteq\Delta_\eta,
 \qquad \operatorname{length}_{\mathcal O}T_{\rm tame}\le
 \operatorname{length}_{\mathcal O}\operatorname{Tor}_1^R(\widetilde U,D).
\]
If this Tor group vanishes, **all** the auxiliary central Kummer coordinates vanish, without any identification \(\widetilde U\simeq U\otimes_D R\).

### Proof

The exact sequence \(0\to W\to\widetilde U\to U\to0\) is Galois-equivariant for both the ordinary action \(\epsilon\) and the deformed scalar action \(\epsilon(1+\eta\kappa_{\rm cyc})\); on \(W\), \(\eta\) acts as zero, so the action is just \(\epsilon\). Compute the two cohomological connecting maps with the *same* lifted cochain. If \(\widetilde c\) lifts a cocycle \(c\) as a cochain, the difference between the two degree-two differentials is
\[
 (d_{\rm def}-d_0)\widetilde c(g,h)
 =\epsilon(g)\eta\kappa_{\rm cyc}(g)\widetilde c(h)
 =\kappa_{\rm cyc}(g)\epsilon(g)\pi(c(h)).
\]
Therefore \(\delta_{\rm def}(c)=\delta_0(c)+\kappa_{\rm cyc}\cup\pi_*c\) in \(H^2(G_{K,S},W(1))\).

The *untwisted* map \(H^1(G_{K,S},\widetilde U(1))\to H^1(G_{K,S},U(1))\) is surjective. Indeed, since \(K\) has class number one, global units of p-prime-to-order and the relevant \(S\)-unit/Brauer complexes give, for **any** finite trivial coefficient module \(M\),
\[
 H^1(G_{K,S},M(1))\simeq M[p]\oplus \bigoplus_{\ell\mid m}M[\ell]
\]
(the bracket here denotes a formal copy of \(M\), not p-torsion). Lift each coefficient in \(U\) to \(\widetilde U\). Hence \(\delta_0=0\).

For the twisted lift, \(\delta_{\rm def}(c)=0\) is necessary. Local Tate reciprocity in the Kummer/Brauer description (item 449) gives
\[
 \kappa_{\rm cyc}\cup\pi_*c
 \longleftrightarrow (b_\ell\pi(u_\ell))_{\ell\mid m}.
\]
Since \(b_\ell\) is a unit for every selected \(\ell\), this vector is zero exactly when every \(\pi(u_\ell)=0\). This proves the principal claim. The kernel formula follows from the definition of \(\pi\). To identify Tor, use the exact periodic free resolution \(\cdots\xrightarrow\eta R\xrightarrow\eta R\to D\to0\): after tensoring with \(\widetilde U\), its first homology is \(\ker(\eta)/\eta\widetilde U\). QED.

### Sharpness test: arbitrary nonzero Tor loss is realizable

Take \(D=\mathcal O/\varpi^N\), integers \(N\ge t\ge k\ge0\), and
\[
 \widetilde U=R/(\varpi^t,\varpi^k\eta).
\]
Then \(U=D/(\varpi^t)\), \(W=D/(\varpi^k)\), and \(\pi\) is reduction modulo \(\varpi^k\). Consequently
\[
 \Delta_\eta=\varpi^k U,
 \qquad\operatorname{length}(\Delta_\eta)=t-k.
\]
For any auxiliary prime, the tame class \(c=\varpi^k[\ell]\) lifts: its coefficient \(\varpi^k\in\widetilde U\) is killed by \(\eta\), so the deformed action on this specific coefficient coincides with the untwisted action. Here \(T_{\rm tame}=\Delta_\eta\). Thus the length inequality is sharp in general, and **the existence of a twisted class with arbitrary nilpotent coefficient module does not itself imply tame vanishing**.

### Conditional GMA consequence and precise limitation

Suppose the actual automorphic finite Hecke/GMA specialization can be lifted into \(D[\eta]/\eta^2\), with the correct normalized cyclotomic ratio of its two outer diagonal characters, and the corresponding universal central quotient \(\widetilde U\) reduces to \(U_C\). Its universal central cocycle then supplies the lift in the theorem. It is enough to prove \(\operatorname{Tor}_1^R(\widetilde U,D)=0\), not the stronger and generally unnecessary claim that the whole coefficient module is a constant deformation.

If the critical-p relation \(x^2u_p\in T_{\rm tame}\) is *also* established and \(a=v_\varpi(x)\), then
\[
 \operatorname{length}(U_C)\le\min(N,2a)+\operatorname{length}(\Delta_\eta).
\]
With the established **conditional** adjacent length bounds and \(\operatorname{Fitt}_D(\bar C)=0\), this gives
\[
 N\le 3a+\operatorname{length}(\Delta_\eta).
\]
Even with Tor zero this is only \(N\le3a\); **the \(\lambda_g=3\) equality case remains possible** (item 405). This theorem removes at most one missing gate, and only if the actual family supplies the indicated lift and Tor control.

## 457. No additional scalar first-order character can see the central p-unit class on the selected cores

### Proposition (internally derived here; no novelty claim)

Assume \(K=\mathbf Q(\sqrt{-2})\), \(p\ge11\) inert, and \(S=\{p\}\cup\{\ell\mid m\}\), where every auxiliary rational \(\ell\) is inert and \(p\nmid(\ell^2-1)\) as in the strengthened core choices 429. The maximal **abelian pro-p** quotient of \(G_{K,S}\) is \(\mathbf Z_p^2\). It has two primitive coordinates \(\kappa_+\) (cyclotomic) and \(\kappa_-\) (anticyclotomic), distinguished by complex conjugation. For every finite p-primary scalar coefficient ring \(D\), any additive scalar character \(\kappa:G_{K,S}\to D\) is of the form
\[
 \kappa=\alpha\kappa_++\beta\kappa_-,\qquad \alpha,\beta\in D.
\]
For every selected inert \(\ell\),
\[
 \kappa_-(\operatorname{Frob}_{K_\ell})=0,
 \qquad \kappa_+(\operatorname{Frob}_{K_\ell})=b_\ell\in D^\times.
\]
Consequently, for \(c=u_p[p]+\sum u_\ell[\ell]\), the entire family of scalar first Bocksteins is
\[
 \beta_\kappa(c)=(\alpha b_\ell u_\ell)_{\ell\mid m}.
\]
In particular **every** such Bockstein kills \(u_p[p]\), and the span of all scalar first-order tests is generated by the one normalized cyclotomic test of item 449. Adding further scalar tangent characters from the same ramification set does not create another independent condition that could exclude the maximal \([p]\) direction in item 405.

### Proof

At an inert \(\ell\ne p\), \(K_\ell/\mathbf Q_\ell\) is unramified quadratic and its residue multiplicative group has order \(\ell^2-1\). Since this is prime to \(p\), \(\mathcal O_{K_\ell}^\times\) has trivial maximal pro-p quotient (principal units are pro-\(\ell\)). Local class field theory therefore makes every p-primary *abelian* character unramified at \(\ell\). Allowing those primes in \(S\) adds no abelian p-ramification.

Because \(K\) has class number one and units \(\{\pm1\}\), the pro-p class-field quotient unramified outside the unique prime over \(p\) is the pro-p quotient of \(\mathcal O_{K_p}^\times\). The unramified quadratic local field has
\[
 1+p\mathcal O_{K_p}\xrightarrow{\log}p\mathcal O_{K_p}\simeq\mathbf Z_p^2,
\]
with no p-power roots of unity. Complex conjugation decomposes this lattice into trace and trace-zero lines, since \(2\) is a p-unit. This gives the two primitive characters.

The cyclotomic Frobenius formula is exactly 448. For \(\kappa_-\), an inert prime of \(K\) is preserved by conjugation, so its unramified Frobenius class is conjugation-fixed. An anti-invariant additive character takes its value to its negative, implying \(2\kappa_-(\operatorname{Frob})=0\); this is zero since \(p\) is odd. The local cup-product computation in item 449 now gives the displayed vector, which contains no \(u_p\). QED.

**Boundary of the no-go result:** This concerns first-order **scalar** p-primary twists with the selected ramification set. It does not exclude a genuinely non-scalar deformation, a new ramified prime, an automorphic nearby-cycle comparison, a nonlinear operation, or critical-p local geometric information. It is consistent with the explicit global \([p]\) equality model 407.

## 458. A finite Hecke weight family does not automatically give the required first-order lift

Let \(\Lambda=\mathcal O[[w]]\) with **normalized weight coordinate** \(w\), and let a complete-intersection local Hecke algebra have a presentation
\[
 A=\Lambda[[T_1,\ldots,T_r]]/(F_1,\ldots,F_r).
\]
Let \(\phi_0:A\to D\) be a fixed specialization with \(\phi_0(w)=0\), \(\phi_0(T_i)=t_i\). A lift \(\phi_\eta:A\to D[\eta]/\eta^2\) with \(w\mapsto\eta\), \(T_i\mapsto t_i+\eta v_i\) exists **if and only if**
\[
 \sum_j\frac{\partial F_i}{\partial T_j}(\mathbf t,0)v_j
 =-\frac{\partial F_i}{\partial w}(\mathbf t,0)
 \quad\text{in }D\quad\forall i.
\]
(The generators must lie in the relevant maximal ideal so formal evaluation makes sense.) Thus the weight-tangent obstruction is the class of \(-\partial_w\mathbf F\) in the cokernel of the Jacobian \(J_T\) over \(D\). This criterion is derived by expanding each relation modulo \(\eta^2\); no eigenvariety smoothness is being asserted.

**Exact adversarial family.** For \(k\ge0\), take the finite-free reduced \(\Lambda\)-algebra
\[
 A_k=\Lambda[T]/(T^2-\varpi^k w)
\]
and the special point \(w=T=0\) mapping to \(D\). Its Jacobian in \(T\) is zero and its weight derivative is \(-\varpi^k\). Therefore a lift with \(w\mapsto\eta\) exists **exactly when** \(N\le k\). For \(k=0\) none exists for any \(N>0\), despite the algebra being finite free, reduced and a complete intersection with abundant characteristic-zero points. For larger \(k\), the obstruction depends sharply on coefficient precision. Formal density or a Hida family alone is insufficient.

There is an **independent** central-module obstruction even if the weight-map tangent exists. Take \(A=\Lambda\) smooth in weight, a free ambient corner \(C=A\), and quotient it by the ideal \((w,\varpi^t)\). At \(w=\eta\) the resulting central quotient is \(R/(\eta,\varpi^t)\), on which \(\eta\) acts by zero; hence \(\Delta_\eta=U\), its maximal value. Smoothness of the base and freeness of an ambient corner therefore do not imply the required \(\eta\)-flatness of the *central quotient*.

For an actual application, one must (i) calculate the weight-tangent map of the **actual ordinary finite Hecke algebra**, (ii) identify the correct outer GMA character ratio with \(\epsilon(1+\eta\kappa_{\rm cyc})\), (iii) keep the same faithful GMA before reducing modulo nilpotents, and (iv) compute or bound \(\operatorname{Tor}_1^R(\widetilde U,D)\). No such calculation for the project’s actual automorphic algebra is supplied by its present archive.

## 459. Rank-one tame monodromy controls a central coordinate only through its middle-entry ideal

**Framed local lemma.** Suppose there is an actual rank-four representation in a free \(1|2|1\) frame over \(D\), and the tame inertia logarithm \(N\) has all \(2\times2\) minors zero **in the full coefficient ring**. Write \(C\) for the outer central module and \(P,Q\) for the adjacent modules. Let \(J_{\rm mid}\) be the ideal of \(D\) generated by the entries \(N_{ij}\) with \(i,j\in\{2,3\}\). If \(u_\ell\) is the class of \(N_{14}\) modulo \(P Q\) in the central extraction, then
\[
 J_{\rm mid}\,u_\ell=0.
\]
In particular, if \(J_{\rm mid}=(\varpi^d)\), then \(\operatorname{length}(Du_\ell)\le d\).

**Proof:** For each \(i,j\in\{2,3\}\), the minor with rows \((1,i)\) and columns \((j,4)\) gives
\(N_{1j}N_{i4}-N_{14}N_{ij}=0\). Its first term is an adjacent-product element. Thus every \(N_{ij}\) annihilates the central class of \(N_{14}\). QED.

**Sharpness and application gate:** In the actual local model of item 441, \(N=r^2E_{23}-rE_{13}+rE_{24}-E_{14}\), so \(J_{\rm mid}=(r^2)\) and the central tame coordinate has exactly the allowed length \(2v_\varpi(r)\). The stronger-prime replacement 452 retains this pattern. Thus rank-one/purity alone is not enough; a **unit middle monodromy entry in the actual integral frame** would kill \(u_\ell\), but the recorded examples have the middle entry divisible by \(r^2\). Moreover, the project’s global object is a finite GMA, not a demonstrated free rank-four frame. One may not infer integral minors from characteristic-zero traces after nonreduced specialization (items 423 and 442–447).

## Research decision and unresolved exact implications

The present mathematical continuation establishes new *conditional algebraic and Galois-cohomological criteria*, but **neither a complete rank-BSD proof nor a counterexample**. It does **not** establish that the actual auxiliary \(g\) satisfies its canonical first-theta-coefficient unit condition; even that would not establish \(\operatorname{rank}E=\operatorname{ord}_{s=1}L(E,s)\). No novelty, external review or prize claim is asserted.

The next useful proof work is not another local type/purity argument or a rerun of 389.a1. It is:

1. **Weight-family bridge:** obtain an actual normalized first-order \(A\to D[\eta]/\eta^2\) congruence specialization (or a derived substitute), and calculate the *central* \(\eta\)-flatness defect. The lemma 456 shows exactly what a nonconstant deformation would suffice to prove and how much tame error is left if it is not flat. Item 458 shows two independent blockers.
2. **Critical-p/equality bridge:** impose the full finite-Artin adjacent local conditions and \(x^2u_p\in T_{\rm tame}\); then find a genuine arithmetic reason excluding an equality in the \(N=3a\) profile. Proposition 457 shows that adding scalar first Bocksteins on this same core cannot exclude the maximal \([p]\) class. This is why the original irreducible middle representation/automorphic global lattice remains essential.
3. **Back to the actual elliptic curve:** independently connect a proven statement about the auxiliary form \(g\) to **both** Mordell–Weil rank and the *complex* Taylor order of \(L(E,s)\). The recorded congruence and finite-precision bounds alone do neither, and the special curve 389.a1 does not fill the universal quantifier.
4. **Full quantifier:** after any restricted theorem, generalize from the prime-conductor/inert-\(p\) hypotheses to *every* elliptic curve over \(\mathbf Q\). No such reduction/generalization is available in this record.

No separate task or process is running. This file is a self-contained supplemental checkpoint for the next research pass, not an overwrite of the master archive.

## 460. Exact presentation and precision threshold when the equality-case central quotient is cyclic

This refines 456 into a concrete computation for the **conditional** \(\lambda_g=3\) equality profile of item 405.

**Proposition.** Let \(D=\mathcal O/\varpi^N\), \(R=D[\eta]/\eta^2\), and let \(\widetilde U\) be a finite \(R\)-module with \(\widetilde U/\eta\widetilde U\simeq D/(\varpi^t)\), \(1\le t\le N\). Then \(\widetilde U\) is cyclic over \(R\), and for a suitable cyclic generator it has a presentation
\[
 \widetilde U\simeq R/(\varpi^t+\eta q,\ \eta\varpi^k),
 \qquad 0\le k\le t,
 \quad\varpi^{N-t}q\in(\varpi^k)\text{ in }D.
\]
Its first-order base-change defect is
\[
 \Delta_\eta\simeq\varpi^k D/\varpi^tD,
 \qquad \operatorname{length}_{\mathcal O}\Delta_\eta=t-k.
\]
If the defining ideal is **principal**, generated by \(\varpi^t+\eta q\), then, writing \(v_\varpi(0)=\infty\),
\[
 k=\min\{t,N-t+v_\varpi(q)\},
 \qquad \operatorname{length}\Delta_\eta
 =\max\{0,\,2t-N-v_\varpi(q)\}.
\]
Thus for the conditional equality profile \(N=3a\), \(U_C\simeq D/(\varpi^{2a})\), and a *principal* lifted central ideal,
\[
 \operatorname{length}\Delta_\eta
 =\max\{0,\,a-v_\varpi(q)\}.
\]
In particular, a first-order relation derivative \(q\) divisible by \(\varpi^a\) implies \(\Delta_\eta=0\), so 456 would force every auxiliary \(u_\ell=0\). If \(q\) is a unit, the possible defect has length \(a\). No claim that the actual GMA central relation is principal or that this derivative divisibility holds is made.

**Proof.** Lift a generator of \(U\) to \(\widetilde U\). As \(\widetilde U=Ru+\eta\widetilde U\), a second substitution using \(\eta^2=0\) gives \(\widetilde U=Ru\). Write \(\widetilde U=R/I\). The image of \(I\) in \(D=R/(\eta)\) is the ideal \((\varpi^t)\), so choose \(f=\varpi^t+\eta q\in I\). The intersection \(I\cap\eta D\) is \(\eta\varpi^kD\) for some \(k\). Since \(\eta f=\eta\varpi^t\in I\), one has \(k\le t\). Every element of \(I\) can be reduced by a multiple of \(f\) to the intersection, proving \(I=(f,\eta\varpi^k)\); multiplying \(f\) by \(\varpi^{N-t}\) supplies the stated compatibility condition. In \(R/I\), \(\eta\widetilde U=\eta D/(I\cap\eta D)\simeq D/(\varpi^k)\), and multiplication by \(\eta\) maps \(U=D/(\varpi^t)\) onto it by reduction modulo \(\varpi^k\). Its kernel has the displayed length. If \(I=(f)\), its intersection with \(\eta D\) is generated by \(\eta\varpi^t\) and \(\eta\varpi^{N-t}q\) (the two conditions come from killing the constant coefficient), so \(k=\min(t,N-t+v(q))\). Substitution gives the formula. QED.

**Adversarial example at the smallest equality precision:** for \(N=3,t=2\), \(\widetilde U=R/(\varpi^2+\eta)\) has \(\Delta_\eta\) of length one, while \(R/(\varpi^2+\eta\varpi)\) has \(\Delta_\eta=0\). Both special fibres are \(D/(\varpi^2)\). Therefore merely knowing cyclicity, special-fibre length \(2a\), and a weight tangent does **not** determine auxiliary vanishing: the first-order relation and any extra \(\eta\)-relations must actually be computed.

A potential symmetry-driven shortcut was also tested. The parity of \(f(0,X)\) at **one** weight does not imply that its weight derivative \(\partial_w f(0,X)\) is divisible by \(X\): \(f(w,X)=X^3+w\) has odd special fibre and unit weight derivative. Only a proved two-variable functional equation constraining the entire family, plus an identification of its defining relation with this central quotient, could justify such divisibility. This test prevents another unsupported move from anticyclotomic parity to weight-direction Tor vanishing.

---

# 20 November 2026 — second independent run: direct all-curves proof routes (items 461–465)

**Mandate:** prove or refute `rank E(Q) = ord_(s=1) L(E,s)` for every elliptic curve over Q, not merely a restricted prime-conductor auxiliary case. Follow one failed idea through to a genuinely different proof attempt in the same run. Do not overwrite the earlier calculations, the finite-precision conditional character inequality, p=13,q=7 local verification, the known curve 389.a1, or the local/global countermodels. The user supplied a valid rank-jump family as a test; its claimed generic rank 2 and independent specialization are treated as given rather than re-proved. No full BSD proof or counterexample is obtained in this run.

## 461. Rational specialization cannot upper-bound rank; the exact quadratic anti-invariant source

Let `F=Q(t)`, `d=t^2-48`, and `E/F: y^2=x^3-28x+d`. The two sections `P=(-2,t)`, `Q=(-4,t)` are F-rational. The extension `K=F(sqrt(d))` has a rational parameter `u=t+sqrt(d)` because `u*(t-sqrt(d))=48`. Thus

` t=(u+48/u)/2`, `sqrt(d)=(u-48/u)/2`, and `R=(0,sqrt(d)) in E(K)`.

The nontrivial deck involution `sigma` sends `u` to `48/u`, fixes `P,Q`, and sends `R` to `-R`. The Neron–Tate bilinear pairing over the function field is Galois invariant and bilinear, so `<P,R>=<Q,R>=0`. If a specialization with R independent of P,Q occurs, R cannot be generically torsion; a torsion section of a smooth proper group scheme specializes to torsion. Thus the generic rank *over K* increases by at least one, without implying that the generic rank *over F* increases.

This can be expressed as a rational point on the twist `d Y^2 = X^3-28X+d`, namely `(X,Y)=(0,1)` over F. The usual short-Weierstrass twist is `E^(d): y^2=x^3-28 d^2 x+d^4`, with point `(0,d^2)`. For any field F of characteristic zero and any nonsquare d, one has the *exact rational rank identity*

`rank E(F(sqrt d)) = rank E(F) + rank E^(d)(F)`.

Proof: tensor E(K) with Q, apply the idempotents `(1±sigma)/2` to its finite-dimensional Q-vector space, and use the isomorphism between the minus eigenspace and `E^(d)(F)⊗Q`. These eigenspaces are complementary; the plus part is E(F)⊗Q. Applying this to the user's family makes the extra rank explicitly anti-invariant, rather than a contradictory failure of the specialization theorem (which provides a generic *lower* rank bound for most specializations, not a generic *upper* bound).

**Failed proof attempt A:** hope for a specialization induction from generic elliptic surfaces to all E/Q, with generic rank bounding every specialized rational rank. The example is a counterexample to that necessary premise. Restricting to a thin set, or appealing to specialization injectivity, does not recover an upper bound. No analytic rank statement follows from this section construction alone.

## 462. Quadratic base change has an exact BSD-discrepancy conservation law

Let E/Q be arbitrary and D a non-square rational discriminant. Let K=Q(sqrt D). Define `a(E)=ord_(s=1)L(E,s)`, `r(E)=rank E(Q)`, `delta(E)=a(E)-r(E)`. Modularity makes L(E,s) entire. The standard complete finite Euler-factor identity and Artin formalism yield

`L(E/K,s)=L(E,s)*L(E^(D),s)`.

The plus/minus decomposition from 461 gives

`r(E/K)=r(E)+r(E^(D))`.

Therefore, without assuming BSD for either factor,

`delta(E/K)=delta(E)+delta(E^(D))`.

**Failed variant of attempt A:** choose infinitely many twists E^(D) of analytic rank 0 or 1 (where BSD is known), hoping that base change to K reduces the unknown discrepancy. Instead each twist with `delta(E^(D))=0` preserves it exactly: `delta(E/K)=delta(E)`. If a(E)>=2, the base-change analytic rank is at least a(E), since `a(E^(D))>=0`; no rank-0/1 theorem on E/K can be reached this way. An apparent numerical gain from twist rank jumps is fully accounted for by the anti-invariant rank, not an attack on the discrepancy.

This failure motivated a genuinely different route: the zeta function and Picard cycles of an *arithmetic surface* over Spec Z. This second route keeps the FULL all-curves quantifier and does not use the auxiliary GU form g.

## 463. Direct all-curves pole/Picard identity (a known arithmetic-surface reduction, proved explicitly)

**Statement.** Let E/Q be any elliptic curve and let `X -> Spec Z` be a regular, proper, flat, projective model with generic fibre E (take the minimal proper regular model if desired). For each finite prime p let `C_p` be the set of irreducible components of `X_{overline F_p}`, and let `Frob_p` permute them. Let `m_p` be the number of Frobenius orbits in C_p, equivalently the number of F_p-irreducible components. Except at finitely many p, m_p=1. Put `v(X)=sum_p(m_p-1)`. Then

`rank_Z Pic(X) = 1 + r(E) + v(X)`

and, writing `ord` as the meromorphic zero order (negative for a pole),

`ord_(s=1) zeta(X,s) = -1 - a(E) - v(X)`.

Thus the **exact, model-independent equality** is

`-ord_(s=1) zeta(X,s) - rank Pic(X) = a(E)-r(E) = delta(E)`.

Consequently the general BSD *rank* conjecture is equivalent, for every E/Q, to the **arithmetic-surface pole-order assertion**

`-ord_(s=1) zeta(X,s) = rank Pic(X)`.

This is the rank-only part of a known arithmetic-surface reformulation, **not** a new solution or novelty claim. The source comparison is Matthias Flach–Daniel Siebel, *Special values of the zeta function of an arithmetic surface* (2021), Theorem 6.1(a), and Stephen Lichtenbaum–Niranjan Ramachandran, *Values of zeta functions of arithmetic surfaces at s=1* (2022/2023), Theorem 2. The latter proves equivalence of a *stronger full special-value conjecture*, not its truth. Original source pages: <https://www.cambridge.org/core/journals/journal-of-the-institute-of-mathematics-of-jussieu/article/special-values-of-the-zeta-function-of-an-arithmetic-surface/2788A8FDB1B045B777445671D6EF3785> and <https://www.cambridge.org/core/journals/journal-of-the-institute-of-mathematics-of-jussieu/article/values-of-zeta-functions-of-arithmetic-surfaces-at-s1/9BAF5F5B623566BF815941227D0D4A65>.

**Picard-rank proof.** Restriction from X to E gives a surjection `Pic(X) -> Pic(E)` because the closure of any divisor on the smooth generic curve is a Cartier divisor on the regular surface. A class restricting to zero is generated by vertical prime divisors. For each p, the free lattice on F_p-irreducible fibre components has precisely one rational-linear relation from `div_X(p) = X_p = sum_i n_i C_(p,i)`. There are no further Q-linear relations across different p: a rational function on X whose generic divisor is zero is a nonzero constant in Q, whose vertical principal divisor is a sum of these full fibres. Each fibre has a component of multiplicity one because the rational origin extends to a section; the relation is primitive, but primitivity is not required for rank. Hence `rank ker = sum_p(m_p-1)`. Finally `Pic(E) ≅ E(Q) ⊕ Z`, using the identity as a rational divisor of degree one, giving the displayed formula.

**Zeta-order proof, retaining every bad prime.** For each p fix an auxiliary etale cohomology prime `ell != p`, let `W_p = Q_ell[C_p]` be the permutation representation on geometric components and set `T=p^{-s}`. The fibre is a proper connected curve; H^0 has one Frobenius eigenvalue 1, and H^2 has eigenvalues p times the permutation eigenvalues of Frob on W_p. The local zeta function therefore satisfies

`Z(X_p,T)=P_(1,p)(T)/((1-T)*det(1-pT*Frob_p | W_p))`.

For good p, `P_(1,p)(T)=1-a_p T+p T^2`. For multiplicative reduction the normalized components are rational, their dual graph is a loop, and `P_(1,p)(T)=1-a_p T`, with a_p=+1 or -1 according to split/nonsplit. For additive Kodaira fibres the component graph is a tree, so H^1=0 and `P_(1,p)=1`. These are exactly the reciprocals of the standard full Euler factors `L_p(E,s)`, including primes 2 and 3. Consequently, globally,

`zeta(X,s) = [zeta(s)*zeta(s-1)/L(E,s)] * product_p [(1-p^(1-s))/det(1-p^(1-s)*Frob_p |W_p)]`.

All but finitely many factors in the product equal one. The determinant has a zero at s=1 of order `dim W_p^Frob = m_p`, while the numerator has exactly one zero. Thus the finite correction product has pole order `sum_p(m_p-1)`. Since `zeta(s)` has a simple pole at 1, `zeta(s-1)=zeta(0)=-1/2` is nonzero, and L(E,s) has a zero of order a(E), the zeta-order formula follows. This formula also supplies the meromorphic continuation needed for zeta(X,s).

**Explicit sanity check: split I_n.** Its special fibre is an n-gon of rational curves with `#X_p(F_(p^k))=n*p^k`. Therefore `Z(X_p,T)=(1-pT)^(-n)`. The standard split-multiplicative Euler factor is `L_p(E,s)=(1-p^{-s})^{-1}`. The correction is precisely `(1-pT)^{-(n-1)}`, contributing n-1 to both the Picard rank and zeta pole order. Thus neither the type-I_n components nor the Tamagawa number should be omitted.

**Blowup invariance audit.** Blow up X at a closed point of residue field F_(p^f). The exceptional divisor is P^1 over F_(p^f); by zeta additivity, replacing the point with the exceptional divisor multiplies zeta by

`Z(P^1_(F_(p^f)),p^{-fs}) / Z(Spec F_(p^f),p^{-fs}) = (1-p^(f(1-s)))^{-1}`,

which has a simple pole at s=1. The blowup formula adds a free rank-one Picard generator, so `-ord zeta - rank Pic` is unchanged. This is a sharp consistency test: any proposed proof yielding a model-dependent BSD rank discrepancy is false.

### Why this direct route remains open

The *unproved* assertion is precisely the pole-order relation `-ord zeta(X,1)=rank Pic(X)` for arbitrary regular arithmetic elliptic surfaces. Establishing it from global arithmetic geometry without already assuming BSD would solve the rank conjecture for every E/Q. Flach–Siebel and Lichtenbaum–Ramachandran prove an equivalence of relevant arithmetic-surface special-value conjectures to BSD, not the conjectures themselves. The above derivation removes all local correction ambiguity but supplies **no new mechanism forcing the global pole order** to equal the global Picard rank.

## 464. Adversarial failure of the fibrewise-Tate shortcut and a Brauer invisibility lemma

**Proposed step (rejected):** use the Tate conjecture for each geometric special fibre to identify the local H^2 pole factors with algebraic cycles, then sum the local ranks to conclude the global surface relation in 463.

**Failure 1: analytic continuation does not sum local poles.** Every local factor of `zeta(P^1_Z,s)` has `(1-p^(1-s))^{-1}`, which is singular at s=1. Yet the global product is `zeta(s)zeta(s-1)` and has only a *simple* pole at s=1, since zeta(0) is finite. The analytic continuation of the infinite Euler product is essential; fibrewise Tate statements say nothing about the extra zero order of the middle global L-function. The failure already occurs for a surface whose Picard rank is known and in which no elliptic curve is present.

**Failure 2: Brauer classes are undetectable on smooth good fibres.** For any smooth, proper, geometrically connected curve C/F_q, `Br(C)=0`. One proof uses `Br(C_bar)=0`, `Br(F_q)=0`, and the Hochschild–Serre spectral sequence: the remaining `H^1(F_q,Pic(C_bar))` vanishes because its degree-Z quotient has no H^1 and its connected Jacobian has H^1=0 by Lang's theorem. Thus for every smooth good reduction prime p of an arithmetic elliptic surface, the restriction `Br(X) -> Br(X_p)` is the zero map. This is true **regardless of whether Br(X) is finite**. Since the global Brauer group is the arithmetic-surface counterpart of the Tate–Shafarevich group, the property `Br(X_p)=0` for all good p cannot imply finiteness of global Sha or a global zeta-pole identity. The literature's full special-value equivalences explicitly retain Br(X) rather than discarding it.

This is not a counterexample to BSD; it is a counterexample to the inference from all geometric local fibre calculations to the needed global arithmetic class statement.

## 465. Exact continuation checkpoint and next truly mathematical obstruction

**Accepted, non-novel exact identities:** (461) quadratic eigenspace rank decomposition and the explicit anti-invariant rank jump; (462) base-change conservation `delta(E/K)=delta(E)+delta(E^D)`; (463) the all-curves model-independent pole/Pic discrepancy identity, with bad fibres and blowups included; (464) rejection of fibrewise pole summation and finite-field Brauer detection.

**Full goal still open.** For an arbitrary E/Q, the missing implication in this new route is

`rank Pic(X) = -ord_(s=1) zeta(X,s)`.

It is equivalent to BSD rank equality and *cannot* be taken as a theorem. The full arithmetic-surface special-value statement would also require finite Br(X) and regulator/period comparisons. A proof attempt should isolate a genuinely GLOBAL input: for example, a Weil–etale/motivic complex with proven finite generation and a proven link between its determinant and the global meromorphic zeta at s=1, rather than a conjectural special-value identity; or a direct global arithmetic pairing that controls the extra zero order of `L(E,s)` without assuming p-adic-height nondegeneracy or finite Sha. Neither has been constructed here.

The previous GU(2,2) route's exact gaps are also retained independently: weight-deformation/central Tor and universal lift, adjacent and critical-p full finite-coefficient local conditions, strict `lambda_g=3` equality exclusion, comparison from auxiliary g to the ORIGINAL E/Q complex analytic and algebraic ranks, and universal extension beyond prime-conductor/inert-p assumptions. The independent arithmetic-surface route avoids these particular auxiliary gaps but confronts an equivalent global Tate-pole theorem.

**Source status:** Published Cambridge primary papers were opened in text/html and their precise rank/full-formula equivalence statements inspected; the 2026-11-16 Naccarato arXiv abstract was checked for the conditional higher-rank twist scope. No third-party code, software, or papers were downloaded or installed; in-memory symbolic checks only. Nothing was sent externally. A counterexample to a proposed *proof shortcut* is not a counterexample to BSD itself.

---

# 20 November 2026 — third independent run: Kato derivatives, signed Mellin moments, and a verified rank-three obstruction (items 466–470)

**Exact goal remains unchanged.** Prove `rank E(Q) = ord_(s=1)L(E,s)` for **all** elliptic curves over Q, or give a rigorously verified counterexample. The user supplied two independently certified fibres `E_7` and `E_13` with algebraic and analytic rank exactly three; these are recorded as *given coordinator certifications*, not re-proved. The eight original archive parts and previous successor entries 456–465 remain unchanged. No new universal BSD proof or counterexample is claimed. All work below is internal mathematical checking, not a novelty/publication claim.

## 466. Higher Kato derivatives: the first proof mechanism has two independent arithmetic gaps

**Primary published source actually inspected:** D. Burns, M. Kurihara, T. Sano, *On derivatives of Kato's Euler system for elliptic curves*, J. Math. Soc. Japan 76 (2024), 855–919, <https://doi.org/10.2969/jmsj/90699069>; author text <https://nms.kcl.ac.uk/david.burns/web_page/katozeta.pdf>, introduction/Theorem 1.3 and Conjecture 1.1. A web PDF text read and screenshot attempt occurred; the screenshot service returned a cache-miss, so no independent visual audit of its printed typography is claimed. This route is distinct from the GU auxiliary form g and the arithmetic-surface pole/Picard equivalence.

The published setup takes a real abelian extension F/Q, finite group G, augmentation ideal I of Z_p[G], and Kato's zeta class z_F. Its norm-encoding

`N_(F/Q)(z_F) = sum_(sigma in G) sigma(z_F) tensor sigma^{-1}`

is conjectured to lie in the `(r-1)`-th augmentation power when `r=rank E(Q)>0`; a higher Bockstein leading-class identity is separately conjectural. **Theorem 1.3's stated sufficient hypotheses include finiteness of both Sha(E/Q)[p^infinity] and Sha(E/F)[p^infinity], along with p>3, large image and absence of local p-torsion.** Thus using that theorem to *prove* p-primary Sha-finiteness would be circular. Removing those finiteness assumptions by assertion does not create an unconditional universal rank theorem. Even given the augmentation containment, the leading-term identity remains Conjecture 1.1(iii), not a result identifying an arbitrary complex L-derivative with the rank.

This is a decisively failed route to full BSD in the current proof attempt. It was not abandoned after a summary: the two input/output failures were located in the actual primary theorem and the proof moved to a mathematically different mechanism.

## 467. A universal signed-moment upper bound for analytic rank (self-contained proof)

Let E/Q be any elliptic curve of conductor N, and `f_E(z)=sum_(n>=1) a_n exp(2*pi*i*n*z)` its normalized weight-two modular newform (modularity is a published theorem). Put

`Lambda_E(s)=N^(s/2)*(2*pi)^(-s)*Gamma(s)*L(E,s)`, `w_E=(-1)^sigma in {+1,-1}`.

Define the *real* function

`g(x)=exp(x)*f_E(i exp(x)/sqrt(N))`, `x in R`.

The classical Mellin transform gives the **exact entire identity**

`Lambda_E(1+z)=integral_(R) g(x)*exp(z*x) dx`.

To verify the change of variables, start from `(2*pi)^(-s)Gamma(s)L(E,s)=integral_(0,infinity) f_E(iy)y^(s-1)dy`, set `y=exp(x)/sqrt(N)` and obtain the stated formula. The weight-two Fricke eigenrelation is `f_E(i/(Ny))=w_E*Ny^2*f_E(iy)`. Hence `g(-x)=w_E*g(x)`. This holds with the full level-N modular form and all bad Euler factors, not an imprimitive L-function.

Writing `sigma=0` for w=+1 and `sigma=1` for w=-1, the full Taylor series is

`Lambda_E(1+z)=2 sum_(j>=0) [z^(2j+sigma)/(2j+sigma)!] * mu_j`,

`mu_j=integral_(0,infinity) g(x)*x^(2j+sigma)dx`.

Rapid decay at both ends makes every term/integral legitimate, and `Lambda_E` has the same central vanishing order as L(E,s). Because `a_1=1`, `f_E(iy)>0` for sufficiently large y; therefore g eventually has positive sign. The function is real analytic and nonzero, so it has only finitely many real zeros on any compact interval. Define `nu(E)` to be its finite number of **sign changes** on x>0; finiteness is made fully explicit in 468.

**Theorem (internal derivation; no originality claim).** For every elliptic curve E/Q,

`ord_(s=1)L(E,s) <= 2*nu(E)+sigma`.

**Proof.** Let `a=ord_(s=1)L(E,s)=2m+sigma`. Then `mu_0=...=mu_(m-1)=0`. If there were only k<m sign changes at positive x-values `c_1<...<c_k`, the monic polynomial `P(X)=product_(i=1..k)(X-c_i^2)` has the property that `g(x)*P(x^2)` has fixed nonnegative sign for x>0 after one overall sign choice. It is strictly positive on an interval and integrable with positive weight x^sigma. Thus

`integral_(0,infinity) g(x)*x^sigma*P(x^2)dx !=0`.

Expanding P expresses this integral as a linear combination of `mu_0,...,mu_k`, which are all zero since k<m. Contradiction. Hence `nu(E)>=m`. QED.

**Sharp-sign corollary.** If E has exactly m sign changes and `mu_0=...=mu_(m-1)=0`, then its analytic order is exactly `2m+sigma`, and the first nonzero derivative has the exact **positive integral**

`Lambda_E^(2m+sigma)(1)=2 integral_(0,infinity) |g(x)|*x^sigma*product_(i=1..m)|x^2-c_i^2| dx >0`.

Proof: after moment cancellations replace x^(2m) with the monic P(x²) in `mu_m`. Since the sign of g is positive in the final tail and P is monic, g*P=|g||P| everywhere. The Taylor coefficient is therefore nonzero and positive. Dividing by the strictly positive `N^(1/2)*(2*pi)^(-1)*Gamma(1)` preserves the sign of the first nonzero derivative of the uncompleted L. This corollary is only a *sufficient analytic certificate*; it is **not** assumed to apply to every E.

## 468. The sign bound is an effectively finite test involving no unproved heights

For any weight-two normalized elliptic newform, the known Hecke/Deligne coefficient bound gives `|a_n|<=d(n)*sqrt(n)<=2n`; the bound also holds at bad primes, using the usual local recurrences. For `q=exp(-2*pi*y)`,

`exp(2*pi*y)*f_E(iy)>=1-2 sum_(n>=2) n*q^(n-1)=3-2/(1-q)^2`.

Since y>=1/3 implies q<=exp(-2*pi/3)<1/7 and hence `3-2/(1-q)^2>0`, we have the **universal tail lemma**

`f_E(iy)>0 for ALL y>=1/3`.

Thus all sign changes of g(x) for x>0 occur in

`0<x<max(0,log(sqrt(N)/3))`,

with an empty interval if sqrt(N)/3<=1. This is a compact interval with endpoints known from the exact conductor. Analyticity and nonidentity-zero make the number of sign changes finite. Each sign sample can be rigorously certified from a FINITE set of integer a_n using the uniform bound on the rest of the q-series:

`|sum_(n>M) a_n q^n| <= 2*q^(M+1)*((M+1)/(1-q)+q/(1-q)^2)`.

This is independent of any Sha-finiteness or p-adic regulator conjecture. It is potentially useful for analytic upper-rank certificates on individual curves. **It is not an algorithm proving the Mordell–Weil rank.**

## 469. An exact rank-three counterexample to the simplest arithmetic sign-count bridge

The coordinator independently certified `r(E_7)=a(E_7)=3` and `r(E_13)=a(E_13)=3` for the fibres

`E_7: y²=x³-28x+1`, `E_13: y²=x³-28x+121`.

Their discriminants (direct exact arithmetic) are

`Delta_7=1404496=2^4*41*2141`,

`Delta_13=-4919984=-2^4*331*929`.

At 2 both have additive reduction, so their conductors satisfy `N_7>=4*41*2141>500²`, `N_13>=4*331*929>500²`. Consequently all the rational sample heights below lie **to the right of the Fricke fixed height** `y=1/sqrt N`, and their sign changes count toward nu(E).

**New, exact finite arithmetic certificates.** The separate self-contained verifier `bsd_mellin_sign_verifier.py` uses only the Python standard library. It computes `a_p` by integer point counting on the good residual cubics (and on the nodal odd bad reductions), uses `a_2=0` for additive reduction, builds the other coefficients by Hecke recurrence up to M=14000, brackets pi by the rational Machin arctangent identity, brackets exp(-x) by alternating rational Taylor partial sums, and uses fixed-point Horner with a **rational rigorous error bound**, including the infinite tail above. No floating-point comparison is used to accept a sign.

Its verified results are:

| curve | y | sign f_E(iy) | truncated value (for orientation) | rigorous total error |
|---|---:|:---:|---:|---:|
| E_7 | 1/500 | + | +0.18546617957254 | <3.36e-20 |
| E_7 | 1/400 | − | −0.56803542686248 | <2.15e-20 |
| E_7 | 1/10 | + | +0.00713833021120 | <1.35e-23 |
| E_13 | 1/500 | − | −12.25433059832228 | <3.36e-20 |
| E_13 | 1/10 | + | +0.04409837847371 | <1.35e-23 |

The three **provable** signs for E_7 imply, by real-analytic continuity, that `nu(E_7)>=2`. Yet its certified algebraic and analytic ranks both equal three and its root number is odd. Therefore the attractive universal sign-count-to-rank claim

`nu(E) <= (rank E(Q)-1)/2 for odd root number`

is **FALSE for an actual elliptic curve** (E_7), and so is the proposed universal identity `a(E)=2nu(E)+sigma`. This is a counterexample to a *proof bridge*, **not** to BSD. For E_13 the two certified signs prove only `nu(E_13)>=1`; numerical scanning suggests one crossing, but no exact uniqueness proof has been completed and none is claimed. The proven sign-count bound may be nonsharp even when BSD itself holds.

The calculation consequently resolves a genuine yes/no question about the new route: real sign variation by itself cannot recover the Mordell–Weil rank, even on two fibres with already-proved equality. It is stronger than merely saying that no comparison is known: the most obvious comparison is refuted with exact rational arithmetic.

## 470. Final proof obligation and direction after both attempts

The **unrestricted BSD equality remains open**. The first mechanism failed because the primary Euler-system theorem assumes Sha-finiteness and leaves its leading-term comparison conjectural. The second mechanism established an unconditional bound on `a(E)` for every E from a finite real sign-change count, but the rank-three E_7 certificate proves the tempting upper bound on the sign count from known rational points is invalid.

A mathematically meaningful route beyond this test must introduce an **arithmetic correction of the signed Mellin kernel** (or a different rank-detecting spectral quantity) and PROVE that its sign variation is controlled by Mordell–Weil rank, while preserving the central zero order. There is presently no such construction; multiplying `Lambda_E` by an arbitrary zero-free analytic factor or smoothing the kernel does not automatically carry a rational-point interpretation. One could instead pursue a higher-rank geometric regulator identity, but the exact interpolation and global point-origin implications must be proved rather than assumed. For the actual full goal, both inequalities `a(E)<=r(E)` and `a(E)>=r(E)` remain unproved generally.

All earlier local GMA/cyclotomic-Tor results and their countermodels, the finite p=13,q=7 calculation, the known rank-two 389.a1, and the new rank-three E_7/E_13 certificates are retained with separate scopes. No external submission, install, spending, or third-party code download was made. No work is running in the background.

---

# 20 November 2026 — independent third run (471–477): Kummer splitting densities and a two-sided trace deformation

**Full target unchanged.** Prove or disprove `rank E(Q) = ord_(s=1) L(E,s)` for *every* elliptic curve over Q. Keep the verified `E_7` sign-variation counterexample from 469, the coordinator's rank-three algebraic/analytic certificates for `E_7,E_13`, and all previously checked local/global GMA obstructions. This run does not re-certify the rank-three claims; it derives independent arithmetic information and tests a new arithmetic–analytic bridge. All computations below use exact integers and finite-field group operations. Neither a general BSD proof nor a counterexample emerged.

## 471. A short exact mod-5 Mordell–Weil saturation certificate for E_7

Let `E:y^2=x^3-28x+1` and `P=(-2,7), Q=(-4,7), R=(0,1)`. Its integral Weierstrass discriminant and c4 are

`Delta=1404496=2^4*41*2141`, `c4=1344`. The rational j-invariant `j=c4^3/Delta=151732224/87781` is not an integer, so E is non-CM. Its existing coordinator rank certificate gives `rank E(Q)=3`. The following mod-5 saturation is *new in this run* and does not rely on that rank result except in its final index consequence.

At the three good rational primes ell=19,71,83, exact enumeration and the group law give:

| ell | n=#E(F_ell) | [n/5]P | [n/5]Q | [n/5]R | normalized ratio |
|---:|---:|---|---|---|---|
| 19 | 25 | (3,18) | (18,3) | (3,18) | (1,2,1) |
| 71 | 75 | O | (59,10) | (60,55) | (0,1,2) |
| 83 | 90 | (63,23) | O | (6,7) | (1,0,3) |

In each row the selected nonzero element `[n/5]P` (or `[n/5]Q` at 71) has order five, so all ratios are genuinely equalities in E(F_ell)[5]. If `aP+bQ+cR=5S` in E(Q), then `[n/5](aP+bQ+cR)=nS=O` after reduction at ell. The three rows give the linear conditions modulo 5

`a+2b+c=0`, `b+2c=0`, `a+3c=0`.

Their coefficient determinant is `det[[1,2,1],[0,1,2],[1,0,3]]=6=1 mod 5`. Consequently `a=b=c=0 mod 5`. Thus the classes P,Q,R are independent in `E(Q)/5E(Q)`. In particular they are linearly independent over Q without using the prior rank certificate. The curve has no Q-rational 5-torsion since #E(F7)=12, so with the separate established rank 3, their rank-three lattice has index prime to 5 in E(Q)/torsion.

**Reproducibility.** `/mnt/data/bsd_kummer_exact_certificate.py` contains only standard-library exact arithmetic, enumerates #E(F7), #E(F19), #E(F71), #E(F83), verifies every displayed group equality, determinant, discriminant and degree; it was executed successfully on this run. No previous 389.a1, p13/q7 or E13 calculations were rerun.

## 472. Explicit full mod-5 image and maximal three-point translation kernel

At good ell=7, #E(F7)=12, hence `a7=7+1-12=-4`. The Frobenius characteristic polynomial modulo five is `X^2+4X+7=X^2-X+2`, with discriminant `(-4)^2-4*7=-12=3 mod5`, a nonsquare. Consequently the image H of G_Q on E[5] is irreducible over F5.

Since `v_41(Delta)=1`, `v_41(c4)=0`, the integral equation is minimal multiplicative type I_1 at 41. Tate-curve monodromy on E[5] for 41≠5 has a nontrivial unipotent element u (a transvection), because 5 does not divide the Tate-period valuation 1. Its fixed line L is not H-stable by irreducibility; choose h in H with hL≠L. With basis vectors respectively in L and hL, the powers of u and h u h^{-1} are the full upper and lower elementary unipotent subgroups. They generate SL2(F5). The Weil-pairing determinant is the surjective mod-five cyclotomic character, so

`H = GL2(F5)`, `|H|=(25-1)(25-5)=480`, `L=Q(E[5])` has degree 480 over Q.

Let `V=E[5]` and `K=Q(E[5],5^{-1}P,5^{-1}Q,5^{-1}R)`, where each division point means one chosen algebraic point and E[5] supplies all the others. Each rational point has a Kummer cocycle `c_i in H^1(Q,V)`, and 471 proves these classes independent over F5. Because the central matrix `-I` in H acts as -1 on V, the elementary Sah identity `(z-1)c(g)=(g-1)c(z)` makes `H^1(H,V)=0`. Inflation–restriction therefore injects the span of the `c_i` into `Hom(G_L,V)`.

The joint image `W` of `G_L -> V^3` is H-stable. The F5-linear span of H=GL2(F5) in End(V) is all M2(F5). Every H-submodule of `V^3=V tensor F5^3` therefore equals `V tensor U` for a subspace `U of F5^3` (apply the two coordinate projectors and off-diagonal matrix units). If W were proper, a nonzero F5-linear functional on F5^3 annihilating U would give a nontrivial relation among the restricted c_i; by inflation–restriction it would give a relation among the original rational Kummer classes, contrary to 471. So W=V^3, of order 5^6, and

`Gal(K/L)=V^3`, `[K:Q]=480*5^6=7,500,000`.

The field K/Q is Galois: E[5] is present and every Galois conjugate of a chosen fifth-division point differs by a point of E[5]. This result is independent of the coordinator's analytic rank-three certificate. The full mod-5 image and saturated three-point Kummer extension are two separate exact arithmetic controls.

## 473. Prime-density singularity encoding the algebraic rank

Let S be the set of good rational primes ell≠5 for which (i) Frobenius is identity on E[5], so ell splits completely in L, and (ii) P,Q,R each reduce to elements of 5E(F_ell). When ell splits in L, Frobenius acts on a fifth-division point Q_i as Q_i+t_i, with t_i in V. Since all five-torsion is F_ell-rational, P_i is locally five-divisible iff t_i=0. Hence BOTH requirements are equivalent to Frobenius being the identity in Gal(K/Q). By Chebotarev,

`delta(S)=1/7,500,000`, and the conditional density among primes splitting in L is `1/5^6=1/15625`.

There is an exact analytic realization, not merely an informal density statement. Set for s>1

`D_S(s)=sum_(ell in S) ell^(-s)`.

For finite G=Gal(K/Q), the identity-class indicator is `1_{g=1}=(1/|G|)sum_(rho irreducible) (dim rho) Tr rho(g)`. Expanding the Artin Euler products at unramified primes gives `log L(s,rho)=sum_ell Tr rho(Frob_ell) ell^(-s)+O(1)` near s=1 from the k>=2 prime-power terms. Brauer induction and nonvanishing of nontrivial finite-order Hecke L-functions imply `L(1,rho)` is finite nonzero for every nontrivial irreducible Artin rho; the trivial representation contributes `log zeta(s)=log(1/(s-1))+O(1)`. Therefore

`D_S(s) = (1/7,500,000)*log(1/(s-1)) + O(1)` as s decreases to 1.

Equivalently, the prime-splitting Euler product `Z_S(s)=product_(ell in S)(1-ell^(-s))^(-1)` has a *fractional pole exponent* `1/7,500,000` in its logarithmic asymptotic. The algebraic rank of E_7 can be read from the conditional splitting density as

`3 = -(1/2) log_5( 480*delta(S) )`.

More generally, whenever E/Q has no p-torsion, H=Gal(Q(E[p])/Q) acts irreducibly on E[p], has End_H(E[p])=Fp and H^1(H,E[p])=0, and r rational points are independent modulo p, their joint Kummer extension has relative degree `p^(2r)`. For **every non-CM E/Q**, Serre's open image theorem makes these hypotheses true for all sufficiently large primes p and a full Mordell–Weil basis (after omitting finitely many primes dividing an index). Thus its rank is encoded by a basis-free p-division splitting density. For CM curves one requires a separate inert-prime image argument; no unconditional universal CM quantifier is silently claimed from this particular GL2 proof.

The key limitation is that the coefficient of `log(1/(s-1))` is a splitting DENSITY of a point-dependent finite Galois extension. The desired analytic rank is an INTEGER zero order of the infinite-image elliptic L-function. Equality of those two differently normalized quantities has not been established.

**Primary background read:** https://link.springer.com/article/10.1007/s40574-024-00427-6 (Kummer image and open-image mechanism); https://jmarzec.ukw.edu.pl/marzec%2Cneururer-lecture.pdf (Brauer induction/nonvanishing at 1); https://web.math.ucsb.edu/~castella/PRconj.pdf (point extension versus Selmer image, cited earlier). These sources are for known theorems, not novelty certificates for the local calculations above.

## 474. First proposed analytic bridge fails exactly: finite Artin L-functions see a pole, not BSD zeros

For a finite-image complex Galois representation rho, Brauer induction and Hecke's nonvanishing theorem give the general identity

`ord_(s=1) L(s,rho) = -dim rho^(G_Q)`.

For a genuine representation this is a pole or a nonzero finite value, never a central zero of positive order. In particular the Dedekind zeta function `zeta_K(s)` of the Kummer extension K has ONE pole at s=1 despite K having degree 7,500,000 and encoding three rational point directions through its translation kernel. All nontrivial irreducible Artin factors are finite and nonzero at s=1. A *virtual* Artin representation can manufacture positive zeros only by inserting negative copies of the trivial representation, so that order would have been supplied by hand.

**Concrete failed implication:** `r rational Kummer directions` does NOT imply `ord_(s=1) zeta_K(s)=r`, nor does any ordinary Artin L-function of their finite extension acquire a zero of order r. On E_7 the desired Hasse-Weil L has, by the independent coordinator certificate, analytic order THREE, whereas every genuine finite Artin L of K has order <=0. No equality of their zero orders can come from this finite Artin representation theory.

A stronger extension-invisibility check applies to arbitrary rank-r 1-motives, not only finite levels. Given P_1,...,P_r in E(Q), let `M_P=[Z^r -> E]` send basis vectors to those points. Its p-adic Tate realization has exact sequence

`0 -> V_p E -> V_p M_P -> Q_p^r -> 0`.

At every common unramified prime ell, the characteristic polynomial of Frobenius is, by the block-triangular representation,

`det(1-T*Frob | V_p M_P) = det(1-T*Frob | V_p E)*(1-T)^r`.

Therefore outside a finite set, `L^S(M_P,s)=L^S(E,s)*zeta^S(s)^r`, *independently of which P_i were chosen*. The split 1-motive `M_0=[Z^r -> E]` mapping every basis vector to zero has exactly the same Frobenius polynomials and partial L-function as M_P, although all its point-extension classes are trivial. Tensor products, duals, symmetric/exterior powers and any other polynomial operation on these representations still have the same semisimplified Frobenius characters. Thus ordinary trace-based L-functions of the 1-motive do not distinguish an r-dimensional point lattice from an artificially chosen zero map of the same source rank.

For E_7 with r=3 the partial L-function of either 1-motive is `L^S(E_7,s) zeta^S(s)^3`, hence has order 0 at s=1 given the separate known a(E_7)=3. This does *not* prove an extension-sensitive comparison for arbitrary E; it shows exactly why a pure Euler-trace or tensor operation cannot provide one. The 1-motive extension class, together with its Neron-Tate height pairing, is extra arithmetic information invisible to semisimplified Frobenius data.

Additional adversarial check: replacing one point P by nP with 5 not dividing n multiplies its Kummer cocycle by the unit n modulo 5, so the corresponding fifth-division extension over Q(E[5]) is unchanged. Yet the canonical height changes by n^2. Consequently the fixed mod-five splitting field, its Artin L-functions and splitting densities cannot even determine the height of a given non-torsion point. This rules out recovering the BSD regulator by only a fixed-level Kummer discriminant or Artin residue.

## 475. A genuinely different possible analytic coupling: two-sided deformation with an exact cup-product gate

The preceding failure suggests trying to make invisible extensions appear in Frobenius CHARACTERISTIC POLYNOMIALS by coupling an upper and a lower extension, rather than just twisting a finite Artin representation. The following lemma is **formal linear algebra/cohomology**, not an arithmetic or automorphic construction.

Let k be a characteristic-zero field, G a profinite group, V a finite-dimensional continuous k-representation rho, and choose cochains c(g) in V and d(g) in V^* satisfying

`c(gh)=rho(g)c(h)+c(g)`, `d(gh)=d(g)rho(h)+d(h)`.

Set `R=k[u,v]/(u^2,v^2)`, where uv is nonzero. Seek a TWO-PARAMETER genuine representation on `V plus k` of the shape

`R_(u,v)(g)=[[rho(g)+uv A(g), u c(g)], [v d(g), 1+uv a(g)]]`.

A direct multiplication shows that `R_(u,v)(gh)=R_(u,v)(g)R_(u,v)(h)` holds EXACTLY modulo `(u^2,v^2)` if and only if the two equations

`A(gh)=rho(g)A(h)+A(g)rho(h)+c(g)d(h)`,

`a(gh)=a(g)+a(h)+d(g)c(h)`

have solutions A(g),a(g). They are the upper/lower Yoneda cup-product obstructions, with End(V) and scalar targets respectively. In particular independent valid one-sided Kummer cocycles need not combine into this two-sided representation.

For an explicit countermodel take G=Z_p^2, rho=1 on V=Q_p, c(x,y)=x, d(x,y)=y. On commuting elements g=(1,0),h=(0,1), the scalar equation would require simultaneously `a(gh)-a(g)-a(h)=d(g)c(h)=0` and `a(hg)-a(h)-a(g)=d(h)c(g)=1`, impossible. Equivalently, the upper and lower infinitesimal matrices have commutator `uv(E11-E22)`, which is nonzero. This shows the cup-product gate is real even for perfect explicit individual cocycles.

If the obstructions vanish and a two-sided representation exists, at a single unramified Frobenius g set `q=ell^(-s)`, `D=I-q*rho(g)`. A Schur-complement calculation gives the EXACT mixed coefficient of the local Euler log:

`[uv] log det(I-q R_(u,v)(g))^(-1)`

`= q*Tr(D^(-1) A(g)) + (q/(1-q))*a(g) + (q^2/(1-q))*d(g)D^(-1)c(g)`.

Unlike the one-sided 1-motive, a genuine two-sided deformation can therefore carry a bilinear expression involving both extension cocycles into a Frobenius trace. This is a mathematically specific way extension information COULD reach an analytic Euler product. However A and a are additional primitives; choices and H^1 ambiguities matter. Nothing here constructs a canonical global deformation attached to E(Q), shows the exact cup classes vanish for the right Tate-twisted coefficients, makes the representation automorphic, or identifies a mixed trace with the complex s-derivatives of L(E,s).

## 476. Rejected shortcut: tensoring with the dual is NOT the desired two-sided coupling

One may try to avoid the cup obstructions by tensoring an upper Kummer extension V_p M_P with its dual. It is a genuine representation automatically, but it still cannot detect the point: its trace equals the PRODUCT of the two traces, each of which is already independent of P. The same argument holds for all tensor-polynomial operations because every character is unchanged after semisimplification. Thus a two-sided trace-visible deformation must actually change the semisimple character of the family at a positive infinitesimal order; merely writing a dual extension alongside an upper one in a tensor product does not do so. This precisely prevents mistaking the appearance of both matrix orientations in a tensor basis for a genuine nonzero reducibility product.

For the elliptic curve, the dual of the Kummer class naturally lives in the Tate-twisted dual `V_pE^*(1)`, so the correct global two-sided problem has a cyclotomic outer character and a potentially nonzero `H^2(Q,Q_p(1))` obstruction. It is not legitimate to use the scalar untwisted `k` example above as proof that the actual elliptic obstruction is nonzero; it is only a sharp formal counterexample to automatic lifting. The existing project records already analyze related GMA central characters and adjacent products in a *restricted auxiliary GU family*; this route would need a direct E-based compatible global deformation and an analytic comparison, not a relabeling of those conditional GU inequalities.

## 477. Full-target checkpoint and exact next mathematical implication

This run produced an **independent, reproducible rank-three Kummer arithmetic certificate**, not another computation of the already-known rank or analytic order. On E_7, three local reductions prove fifth-power saturation, two other local facts prove the full GL2(F5) Galois image, and independent group/cohomology deductions give a maximal translation kernel of order 5^6 and a degree-7,500,000 Galois extension. Its splitting-prime Dirichlet series has a rigorously determined logarithmic coefficient 1/7,500,000. This is a concrete arithmetic–analytic rank signal with a full local proof.

The attempted direct transfer to BSD's complex analytic zero order FAILS: finite Artin L functions have no positive-order zeros at1; the elliptic 1-motive L-function is insensitive to the actual Kummer extension classes; height changes under nP with the same mod-five field; the tensor-with-dual shortcut remains trace-blind. These are decisive mathematical obstructions, not the assertion that the ideas are merely 'unverified'.

The next distinct potentially useful bridge is **construct an actual extension-sensitive deformation of the original elliptic representation** (not an auxiliary g) whose mixed Frobenius term is a controlled height/regulator pairing, AND prove an interpolation identity connecting that term to a complex s-Taylor coefficient of L(E,s). Step 475 states the exact first cohomological gate. Without those two new theorems, even perfect Kummer density information is not a rank BSD proof.

No equality/counterexample for all E/Q was obtained. All earlier verified calculations, the selected p=13/q=7 check, the known rank-two 389.a1, the rank-three E_7/E_13 and sign-variation results, the finite-precision GU constraints and their countermodels are preserved without being rerun. No spending, external submission, installation or third-party code download was performed.

---

# 20 November 2026 — independent fourth run (478–484): Chebotarev–Hecke comparison, integral Heisenberg lift, and precise failure of the analytic bridge

**Full target:** For every elliptic curve `E/Q`, prove or disprove `rank E(Q) = ord_{s=1} L(E,s)`. This run starts from the maximal mod-five three-point Kummer extension proved in 471–473, retains 469's actual E7 sign-change counterexample, and retains (without redoing) the coordinator's E7 and E13 rank-three algebraic/analytic certifications. No universal BSD conclusion is asserted. Computations use the Python standard library only; no spending, external submission, installation or download.

## 478. Universal joint divisibility density for maximal Kummer families

**Proved theorem.** Let `p` be an odd prime, `E/Q` an elliptic curve with surjective residual representation `rho_{E,p}:G_Q→GL_2(F_p)`, and `P_1,...,P_r∈E(Q)` whose joint Kummer extension `F=Q(E[p],p^{-1}P_1,...,p^{-1}P_r)` has translation kernel `E[p]^r` over `Q(E[p])`. The full Galois group has order `|GL_2(F_p)|p^{2r}`. Then the natural density of good rational primes `ell≠p` for which **every** `P_i` is divisible by `p` in `E(F_ell)` is

`delta_{p,r} = 1/|GL_2(F_p)| * sum_{A∈GL_2(F_p)} p^{-r dim ker(A-I)}`.

*Proof.* With a choice of `p`-division point `Q_i` for each `P_i`, the Frobenius data consist of `A=rho(Frob_ell)` and translations `t_i=Frob(Q_i)-Q_i∈E[p]`. An `F_ell`-rational preimage of `P_i` exists if and only if some `v∈E[p]` makes `Frob(Q_i+v)=Q_i+v`, equivalently `t_i∈(I-A)E[p]`. The image has codimension `d(A)=dim ker(A-I)` in the two-dimensional space. The `p^{2r}` translations are uniformly distributed for each `A`, since the full translation kernel makes every fibre of `Gal(F/Q)→GL_2(F_p)` a torsor for `E[p]^r`. Thus the relative proportion is `p^{-rd(A)}`, and Chebotarev gives the formula. The argument requires full translation image, not merely independence of mod-p coordinates without the Galois/cohomology justification.

There are precisely three possibilities for `d(A)`. The identity is the only matrix with `d=2`. The `d=1` matrices are (i) diagonalizable ones with eigenvalues `1` and `lambda∈F_p^×\{1}`, contributing `(p-2)*p*(p+1)` elements, and (ii) the nonidentity unipotents, contributing `p²−1` elements. Thus

`N_1=(p+1)(p²-p-1)`, `N_2=1`,

`N_0=p(p-1)²(p+1)-N_1-1=p^4-2p³-p²+3p`, and hence

`delta_{p,r} = [N_0+N_1 p^{-r}+p^{-2r}]/[p(p-1)²(p+1)]`.

The density is strictly decreasing in `r`. `delta_{p,0}=1`, while for large `r` it tends to `N_0/|GL2|` rather than zero: the ordinary matrices with `A-I` invertible give local divisibility for any finite collection of rational points. This is a precise quantitative limitation on the information in unrestricted reduction primes.

For the established rank-three control `E_7:y²=x³-28x+1`, the previous exact mod-five tests verify all hypotheses for `P=(-2,7),Q=(-4,7),R=(0,1)`. The complete matrix counts are `N_0=365`, `N_1=114`, `N_2=1`, `|GL2(F5)|=480`, giving

`delta_{5,3}=(365+114/125+1/15625)/480=59556/78125 = 0.7623168`.

The additional exact verifier `bsd_kummer_density_2026_11_20.py` enumerates all matrices in `GL2(F_p)` for `p=3,5,7` and independently matches the closed formulas. This is exact finite-group arithmetic; it is not an analytic-rank computation.

## 479. A sharper Hecke-congruence-conditioned density

**Proved refinement.** At a good rational prime `ell≠p`, the characteristic polynomial of `A=rho(Frob_ell)` is `X²-a_ell X+ell` modulo `p`. Consequently the arithmetic-Hecke conditions

`ell≡1 mod p` and `a_ell≡2 mod p`

are equivalent to `tr A=2`, `det A=1`, or `A` being unipotent. There are `p²−1` nonidentity unipotents, with `dim ker(A-I)=1`, and one identity, with dimension two. Therefore the density among **all** rational primes satisfying both these Hecke congruences and simultaneous point divisibility is

`eta_{p,r}= [(p²−1)p^{-r}+p^{-2r}]/|GL2(F_p)|`.

For the actual `E_7,p=5,r=3`, this becomes

`eta_{5,3}=(24/125+1/15625)/480 = 3001/7500000`.

Among the Hecke-congruence primes themselves the conditional density is

`eta_{5,3}/(25/480) = 3001/390625`.

The Dirichlet series `sum_{ell in S_{5,3}} ell^{-s}` for this precisely defined prime set has singularity

`(3001/7500000)*log(1/(s-1)) + O(1)` as `s→1+`, by effective qualitative Chebotarev/Artin character expansion (the O(1) term is at least bounded; no effective error rate is required here). This is an exact **arithmetic and mod-five Hecke** correlation, not a statement about the actual complex Taylor coefficients of `L(E,s)`.

## 480. The attempted analytic connection via the Euler logarithm fails at a specific analytic step

The ordinary good-prime Euler factor is `[(1-alpha_ell ell^{-s})(1-beta_ell ell^{-s})]^{-1}`, with `alpha_ell+beta_ell=a_ell`, `alpha_ell beta_ell=ell`, `|alpha_ell|=|beta_ell|=sqrt(ell)`. On its absolutely convergent half-plane, the local Euler-log expansion starts

`log L(E,s) = sum_good a_ell ell^{-s} + 1/2 sum_good (a_ell²-2ell) ell^{-2s} + R_E(s)`,

where the sum of the terms of power `m>=3` converges absolutely near `s=1` (indeed for `Re s>5/6`); finitely many bad Euler factors are absorbed into `R_E` near 1. The identity is initially justified for `Re s>3/2`, not by termwise convergence at the critical point `s=1`.

The point-sensitive density in 479 controls **bounded functions of finite Frobenius residues**. The first Euler-log term uses unbounded integers `a_ell` of typical scale `sqrt(ell)`, and the second term has magnitude up to a constant times `1/ell` at `s=1`. Its prime sum is not absolutely convergent there. Thus one cannot discard the prime-square contribution as an `O(1)` remainder or replace the first term by a Chebotarev-density logarithm. Doing so would be a demonstrably invalid analytic interchange. In addition, a fixed finite Kummer field sees only `a_ell mod p` and not the full integral `a_ell`.

This is the precise missing theorem for the attempted Hecke-conditioned prime-density bridge: a **global weight-one automorphic cancellation/continuation comparison**, plus an identification of its finite-Kummer arithmetic dependence. The density formula supplies neither. The general BSD rank equality remains open after this attempt.

## 481. Every pair of finite elliptic Selmer classes admits a global Heisenberg extension (no full-rank conclusion)

**Proved construction, with ramification scope retained.** Fix an odd prime `p` and `m>=1`, put `V=E[p^m]`, `mu=mu_{p^m}`, and let `c_P,c_Q∈H¹(Q,V)` be ANY two `p^m`-Selmer classes, not necessarily rational-point Kummer classes. The global Weil-pairing cup product

`c_P cup_e c_Q ∈ H²(Q,mu_{p^m})`

is zero. For every place `v`, the localization of each class lies in the local Kummer subgroup of `H¹(Q_v,V)`. That subgroup is self-annihilating under local Tate duality, so the local cup products are zero. Global Kummer/Hilbert 90 identifies `H²(Q,mu_{p^m})` with `Br(Q)[p^m]`; the Brauer–Hasse–Noether injection into the direct sum of local Brauer groups proves global vanishing. This proof deliberately takes cohomology over the entire `G_Q`: it does NOT silently claim that the lift can be chosen unramified outside the original set of bad primes.

Choose continuous cocycle representatives `c_P(g),c_Q(g)∈V`. Let `rho(g)` be the action on `V`, `epsilon(g)` the action on `mu`, so `det rho=epsilon`. Define a row map

`u_P(g):V→mu`, `u_P(g)(w)=e(c_P(g),rho(g)w)`.

It satisfies `u_P(gh)=epsilon(g)u_P(h)+u_P(g)rho(h)` using Galois equivariance of the Weil pairing. Global cup vanishing supplies a continuous cochain `b:G_Q→mu` satisfying

`b(gh)=epsilon(g)b(h)+u_P(g)c_Q(h)+b(g)`.

Hence the block-upper-triangular matrices

`T(g) = [[epsilon(g), u_P(g), b(g)], [0,rho(g),c_Q(g)], [0,0,1]]`

are an ACTUAL continuous four-dimensional representation with `1|2|1` blocks over `Z/p^m`, with top and bottom one-dimensional constituents, and central extension recording the chosen nullhomotopy. Choices of `b` differ by one-cocycles and must not be called canonical. This is a genuine global finite-characteristic lift, not an automorphic or characteristic-zero representation.

**Decisive limitation:** The same argument applies to EVERY pair in the full finite Selmer group, including classes whose Weil–Chatelet images could be nonzero. Existence of the Heisenberg extension therefore does not distinguish `E(Q)/p^m E(Q)` from `Sha(E/Q)[p^m]` and is not a rational-point criterion. Its characteristic polynomial is identically

`(X-epsilon(g)) det(X-rho(g)) (X-1)`, independent of `P,Q` and of the central cochain `b`. Even all these global nilpotent lifts combined leave ordinary Euler traces unchanged. This is consistent with, but more pairwise-explicit than, archived abstract level-two Selmer-lifting obstructions; it is **not** a new BSD case.

## 482. The missing cyclotomic twist prevents a direct two-sided Kummer trace deformation

To produce a non-upper-triangular deformation with trace depending on `P,Q`, the previous run attempted simultaneous maps `V⇄1`. But a rational point gives a class with coefficients `V`, whereas the reverse arrow is a class in `V^*`. The Weil pairing supplies an isomorphism only

`V ≅ V^*(1)`, or equivalently `V^* ≅ V(-1)`,

not an untwisted map `V→V^*`.

For `E_7` at `p=5`, the full `GL2(F5)` image makes this an exact representation-theoretic obstruction:

`Hom_{GL2(F5)}(V,V^*)=0`.

Indeed the central scalar matrix `2I` acts by `2` on `V` but by `2^{-1}=3` on `V^*`. Any equivariant map must be zero. On `V^*⊗det`, the central action is `2^{-1}*2²=2`, so the alternating Weil-pairing isomorphism is permitted. The code checks these scalar equalities exactly.

Thus two Kummer point classes cannot automatically occupy opposite blocks of a trace-changing `V⊕1` representation with the same constant diagonal: the desired opposite class has the wrong Tate weight. The successful upper-triangular `1|2|1` construction uses the cyclotomic character as an OUTER constituent and remains trace-blind. Any actual trace-changing lift needs a more substantial motivic/weight deformation and an independent analytic comparison.

## 483. What the rank-three controls really give on BOTH sides

The established E7 local Kummer certificate gives `rank E_7(Q)>=3` without any analytic assumption. The coordinator's separate 2-descent gives the upper bound `rank<=3`, so `r(E_7)=3`. The coordinator's independently certified third complex derivative and vanishing of lower derivatives yield `a(E_7)=3`, and similarly for E13. The arithmetic-Hecke density formulas of 478–479 are a genuinely different exact consequence of the E7 rational-point certificate, but they do not REPROVE the complex derivative certificate.

There is a general, useful **one-sided arithmetic-to-analytic implication** from existing theorems. If an elliptic curve over Q has two independent rational points, it cannot have analytic order 0 or 1: Gross–Zagier–Kolyvagin, together with modularity, proves analytic order 0 or 1 entails the same algebraic rank. If its functional equation has sign `-1`, then its analytic order is odd; hence **any E with at least two independent rational points and sign -1 has analytic order >=3**. If its sign is `+1`, the analogous lower bound is order >=2. The bound is independent of p and true for arbitrary E/Q. On E7 and E13, the sign is -1 because their independently certified analytic order is three. Thus the Kummer rank lower bound itself forces `a>=3` for these controls, using the known rank-0/1 theorem. Combining it with the coordinator's separate rigorously nonzero third derivative gives `a=3`. This uses no claim that arbitrary algebraic rank r forces analytic rank >=r; that missing higher-rank implication is the core of BSD.

## 484. Exact continuation checkpoint after two distinct failed bridges

This run pursued (A) Chebotarev/Hecke prime-density control and (B) global pairwise Heisenberg Galois lifts. Both yielded checkable theorems but each failed at a distinct, explicit arithmetic–analytic implication. Route A yields a rank-sensitive density even after imposing actual mod-p Hecke eigenvalue constraints, but the weight-one `a_ell` and borderline prime-square Euler terms prevent identifying its logarithmic coefficient with the central Taylor order of the Hasse–Weil L-function. Route B proves all finite Selmer-class pairs admit an actual global 1|2|1 lift, but these lifts are upper-triangular and trace-blind; a potential opposite-arrow remedy hits the nontrivial Tate twist, already visible for the full `GL2(F5)` image on E7.

A next potentially meaningful proof objective is to construct a **canonical globally defined, extension-sensitive regulator / height object attached to the ORIGINAL E**, with an arithmetic detection mechanism distinguishing the global point lattice from the full Selmer group, and a PROVEN complex archimedean spectral identity comparing it to the first nonzero derivative of `L(E,s)`. The project already has exact countermodels to simply asserting p-adic height nondegeneracy or taking semisimplified Galois traces. Neither this object nor the required comparison has been constructed. Full BSD remains open, and the earlier Kummer and sign-change counterexamples survive unchanged.

**Source checks during this run:** the local Kummer isotropy statements were compared with Gross's account of Kolyvagin's work (https://wstein.org/papers/bib/gross-kolyvagins_work_on_modular_elliptic_curves.pdf) and the standard Tate-pairing discussion (https://www.dpmms.cam.ac.uk/~taf1000/papers/ctp.pdf). The analytic rank-0/1 theorem was checked against the Columbia exposition (https://www.math.columbia.edu/~chaoli/docs/BSD.html). These sources give established inputs, not external review of the new finite-group derivations. The exact Python verifier is `bsd_kummer_density_2026_11_20.py` in the same working directory.

## 485. The full p-power Kummer tower is insensitive to prime-to-p point multiplication

**Proved all-level lemma.** For any `E/Q`, rational point `P∈E(Q)`, prime `p`, and integer `n` coprime to `p`, let

`K_k(P)=Q(E[p^k], [p^k]^{-1}P)`,

where adjoining one division point and the full torsion is equivalent to adjoining all division points. Then

`K_k(nP)=K_k(P)` for EVERY `k>=1`, including as actual subfields of a common algebraic closure.

*Proof.* If `[p^k]Q=P`, then `[p^k](nQ)=nP`; this gives `K_k(nP)⊂K_k(P)`. Conversely choose integers `a,b` with `an+bp^k=1`. If `[p^k]T=nP`, then `[p^k](aT+bP)=anP+bp^kP=P`; thus `K_k(P)⊂K_k(nP)`. No hypothesis on rank, reduction type or the residual Galois image is used.

More generally, let `P=(P_1,...,P_r)` and let `M∈M_r(Z)` have determinant coprime to `p`. For each `k`, `M` is invertible modulo `p^k`, so the division-point fields attached to `P` and to `MP` are EQUAL after adjoining E[p^k], by the same Bézout/lattice computation. Thus their entire unions over all `k` agree.

On the other hand the Néron–Tate Gram matrix `H=(<P_i,P_j>)` changes to `H'=M^t H M`; in particular `det H'=(det M)^2 det H`. For the actual `E_7,p=5` take `M=diag(2,1,1)`; every mod-`5^k` joint division field is identical for `(P,Q,R)` and `(2P,Q,R)`, but the determinant of their real height matrices differs by the exact factor **four**. This is a real arithmetic difference in the index-two point sublattice, not a claim that the canonical regulator of the FULL Mordell–Weil group changes. It proves that an unlabelled fixed-`p` full Kummer tower, even with all finite levels, cannot by itself reconstruct the regulator of an arbitrary chosen point sublattice.

## 486. The same density law holds for non-point Selmer classes

**Proved formal strengthening** of 478, independent of Sha finiteness. Fix `p>=5` with `rho_{E,p}(G_Q)=GL_2(F_p)`, put `V=E[p]`, `L=Q(E[p])`, and choose independent classes `c_1,...,c_r∈H¹(Q,V)`. They need not be Kummer images of rational points. By the central `-I` argument `H¹(GL_2(F_p),V)=0`, so inflation–restriction injects their span under restriction to `G_L`. On `G_L`, each class is an ordinary homomorphism to `V`. Their joint image `W⊂V^r` is `GL_2(F_p)`-stable. The span of `GL_2(F_p)` inside `End_Fp(V)` is the full matrix algebra, so `W=V⊗U` for some subspace `U⊂F_p^r`. If `U` were proper, a nonzero linear combination of the given `c_i` would vanish on `G_L`, contrary to restriction injectivity and linear independence. Hence `W=V^r`.

At a good prime `ell!=p` each localization has an unramified Frobenius value with class in `V/(A-I)V`. The event that ALL localizations vanish therefore has the SAME density `delta_{p,r}` of 478. If the `c_i` belong to `Sel_p(E/Q)`, then local Kummer theory identifies their localizations with local point-division classes, but the original global classes need not come from global rational points; they could have nonzero images in `Sha(E/Q)[p]`. As a result **the finite Chebotarev density calculation can detect the dimension of arbitrary independent Selmer directions just as easily as Mordell–Weil directions. It cannot, on its own, determine which ones are rational points.** No actual nonzero Sha class on E7 is claimed.

This is a stronger arithmetic obstruction to a BSD proof by splitting density: the same numerical mechanism is consistent with `s_p=r+t_p` and does not eliminate the unknown divisible Sha term.

## 487. A different arithmetic–analytic attempt using the REAL height theta function

The previous failed mechanisms used finite or p-adic Galois data. To recover the information omitted by the all-level Kummer tower in 485, insert the actual positive-definite Néron–Tate pairing. For any r independent rational points `P_1,...,P_r`, let `H` be their real symmetric positive-definite height Gram matrix. Define the Gaussian theta function

`Theta_H(t)=sum_{n∈Z^r} exp(-pi*t*n^t H n)`, `t>0`.

By elementary Fourier transformation of a Gaussian and Poisson summation,

`Theta_H(t)=t^{-r/2} (det H)^(-1/2) Theta_{H^{-1}}(1/t)`.

Hence as `t→0+`,

`Theta_H(t) = (det H)^(-1/2) t^{-r/2} + O(exp(-c/t)t^{-r/2})`

for some `c>0`. Its Mellin transform is the Epstein zeta function

`Z_H(s)=sum_{n∈Z^r\{0}}(n^t H n)^(-s)`, initially `Re s>r/2`, with

`pi^{-s}Gamma(s) Z_H(s)=integral_0^infinity (Theta_H(t)-1)t^{s-1}dt`.

Splitting the integral at 1 and applying Poisson summation gives meromorphic continuation with its rightmost simple pole at `s=r/2` and residue

`Res_{s=r/2} Z_H(s)=pi^{r/2}/[Gamma(r/2)*sqrt(det H)]`.

**This is an exact genuinely archimedean analytic encoding of both the arithmetic rank and the height regulator of the CHOSEN point lattice.** For the rank-three E7 control, every independent triple of points gives a height theta with rightmost pole at `s=3/2`; scaling P to 2P halves this residue, exactly as `det H` changes by four, although the complete 5-power Kummer tower remains unchanged by 485.

**Attempted BSD bridge and decisive failure:** The pole of `Z_H(s)` lies at `r/2` **by construction** from the chosen rank-r lattice. The Hasse–Weil L-function `L(E,s)`, by contrast, has its critical center at 1 and Euler factors from the elliptic Frobenius traces; no equality of Euler factors, spectral traces, or leading Taylor coefficients has been constructed between these two functions. The height-theta Poisson functional equation does not imply the Hasse–Weil functional equation or BSD. Merely placing the point lattice's theta function next to the Hasse–Weil L-function would assume the missing arithmetic–analytic comparison, not prove it. Nonetheless this attempt isolates the missing type of information: a successful construction must use a genuinely archimedean height/regulator invariant, and then link it to the original elliptic motive by a proved global identity rather than by Chebotarev or generic cohomological trace formalism.

## 488. Revised exact full-target checkpoint

Three mathematically different approaches are now exhausted to precise boundaries: (i) Chebotarev densities of point division, refined by actual mod-p Hecke congruences; (ii) finite integral pairwise Heisenberg lifts and attempted two-sided Galois trace deformations; (iii) real Néron–Tate Gaussian theta/Epstein-zeta spectral encoding. Results (478),(479),(481),(485),(486),(487) are exact constructions/theorems with stated hypotheses. None proves universal `ord_{s=1}L(E,s)=rank E(Q)`. The two rank-three E7/E13 controls remain valid; the rank-three E7 sign-change counterexample invalidating the simple sign-count/rank inequality remains valid; the earlier conditional auxiliary GU finite-precision theorem still has no direct E-rank consequence, and the p=13/q=7 local check and rank-two 389.a1 are preserved without being redone.

The first unproved *new* implication that would connect the now separated inputs is: produce a **canonical, functorial elliptic-motive arithmetic height object** whose point-origin and regulator information survive in a COMPLEX analytic transform and whose Taylor order is forced to agree with the central order of the *original* weight-two Hasse–Weil L-function. The current Epstein-zeta construction is a fully explicit control showing what the archimedean point input can supply, but its failure of Euler-factor compatibility prevents treating it as the needed object. The unrestricted BSD target is still active and unsolved.

---

# Continuation 2026-11-20, late session: original E, complex and cyclotomic p-adic L-functions

## 489. Local Tate periods and exceptional-zero invariants at both certified rank-three controls

**Scope / verified arithmetic.** Let `E_t:y^2=x^3-28x+t^2-48`; put `B=t^2-48`. The standard invariants are `c4=1344`, `c6=-864B`, `Delta=16(87808-27 B^2)`. For `t=7`, `B=1`, `Delta=2^4*41*2141`. For `t=13`, `B=121`, `Delta=-2^4*331*929`. Each displayed odd prime is type I_1, since `c4` is a unit and the discriminant has valuation one. The node of `x^3-28x+B` has x-coordinate `a=-3B/(2*(-28)) (mod p)`; its tangent cone is `y^2=(3a)(x-a)^2`, so the reduction is split precisely when `3a` is a nonzero square. This classifies `E_7`: 41 nonsplit, 2141 split; `E_13`: 331 split, 929 nonsplit. The accompanying self-contained Python verifier checks each case by exact finite-field arithmetic.

At a split I_1 prime p, write the Tate parameter `q_E`, with `v_p(q_E)=1` and normalize `log_p(p)=0`. The modular j-series `j(q)=q^{-1}+744+O(q)` implies `q=j^{-1}+744j^{-2}+O(j^{-3})`. Since `j=c4^3/Delta` and `v_p(j)=-1`, setting `w=(Delta/p)*c4^{-3} mod p^2` yields the fully integral identity

`q_E/p = w+744*p*w^2 (mod p^2)`.

For a p-unit `w`, define `F_p(w)=((w^(p-1)-1)/p) (mod p)` using an integral representative modulo `p^2`. As `log_p(w)/p = -F_p(w) (mod p)`, the exact local formula is

`Linv_p(E)/p = 744*(w mod p) - F_p(w) (mod p)`, `Linv_p(E)=log_p(q_E)/v_p(q_E)`.

The arithmetic gives `(p,w mod p,F_p(w),Linv/p mod p)` equal to `(2141,984,772,1243)` for `E_7` and `(331,302,138,132)` for `E_13`. Both p-adic L-invariants are nonzero; the result is NOT a nonvanishing theorem for the higher coefficient of the cyclotomic p-adic L-function, and does not assert actual p-adic valuation exactly one for that coefficient.

**Sources:** Tate j/q expansion, standard local Tate uniformization; Greenberg–Stevens exceptional zero theorem https://math.bu.edu/people/ghs/papers/Greenberg_Stevens_Invent.pdf . Computational provenance: `/mnt/data/bsd_exceptional_zero_rank3_verifier.py`.

## 490. Kato's rank-sensitive p-adic order for the ORIGINAL curve, with local shift

**Published theorem, checked in the primary published statement.** Burns–Kurihara–Sano, Proposition 6.1, reproduces Kato's Theorem 18.4: for a rational elliptic curve, with cyclotomic p-adic L-function `L_{S,p}` and `r=rank E(Q)`, `L_{S,p}` belongs to `I^r` when p is good or nonsplit multiplicative and to `I^(r+1)` when p is split multiplicative. The statement of Proposition 6.1 has **no finite-Sha hypothesis**; contrast Hypothesis 2.2 used in subsequent stronger higher-rank formulae.

Applying the coordinator's independent certificates `r(E_7)=r(E_13)=3`, the actual p-adic functions satisfy

- `ord_T L_41(E_7,T)>=3` and `ord_T L_2141(E_7,T)>=4`;
- `ord_T L_929(E_13,T)>=3` and `ord_T L_331(E_13,T)>=4`.

This is a same-curve two-prime test of the exact local exceptional-zero shift. The coordinator additionally established complex analytic order three for both original curves, independently via rigorous central-third-derivative intervals. One cannot identify an order-three COMPLEX coefficient with the third cyclotomic p-adic coefficient at split p: the latter vanishes by the separate Kato theorem. The correct candidate lies in degree FOUR and involves an additional p-adic regulator.

**Primary checked source:** Burns–Kurihara–Sano, *On derivatives of Kato's Euler system for elliptic curves*, J. Math. Soc. Japan 76 (2024), Proposition 6.1, https://kurihara.math.keio.ac.jp/bks4.pdf (printed p.895). Kato 2004 Astérisque 295 Theorem 18.4: https://numdam.org/item/AST_2004__295__117_0.pdf .

## 491. An infinite explicit family carrying three independent rational points AND p-adic fourth-order vanishing

**Proved arithmetic plus published p-adic theorem.** Let `M=7*19*71*83=783769`, `p=2141`, and for `k>=0` set

`u=8+k*M*p^3`, `t=(u+48/u)/2`, `v=(u-48/u)/2`, `E_u:y^2=x^3-28x+t^2-48`.

The conic identity `t^2-v^2=48` supplies three rational points `P=(-2,t),Q=(-4,t),R=(0,v)`. At good primes 19,71,83 the residue `u=8` gives fixed 5-primary rows

`(1,2,1)`, `(0,1,2)`, `(1,0,3)`

from `[ #E(F_ell)/5 ](P,Q,R)` in a cyclic subgroup of order five. The determinant is `1 mod 5`. Hence any mod-five relation among P,Q,R reduces to the zero coefficient vector. At the additional good prime 7, `#E(F_7)=12`, so rational 5-torsion is absent (injective prime-to-7 torsion reduction). Therefore `rank E_u(Q)>=3` for EVERY k. Since `u=8 mod p^3`, also `t=7 mod p^3`, the p=2141 fibre is split type I_1, and the preceding Tate parameter calculation is constant through `p^2`: `Linv_2141(E_u)/2141=1243 mod2141`. Kato then gives `ord_T L_2141(E_u,T)>=4` for all k. For k increasing, u grows with positive v and |Delta| changes, so the j-invariants are infinitely many distinct rational values.

**New, same-original-curve COMPLEX consequence:** Modularity, Gross–Zagier and Kolyvagin prove for every E/Q that analytic rank 0 or 1 entails algebraic rank equal to that order. Contrapositively `rank E_u(Q)>=3` implies

`L(E_u,1)=L'(E_u,1)=0`, i.e. `ord_(s=1) L(E_u,s)>=2`

for EVERY k. Therefore the ENTIRE infinite family simultaneously has 3 independent points, a complex central double zero, and a cyclotomic p-adic zero of order at least 4. If its particular global root number is -1, odd parity of the complex Taylor series strengthens the complex lower bound to order >=3. **The root sign has not been proved uniform across k**, and analytic rank 2,3,... is unresolved for k>0. The k=0 member is E7, already independently certified to have exact algebraic and complex rank three. This result does not establish equality for any new arbitrary k, and does not generalize the small-analytic-rank theorem into the missing general inequality `ord L>=rank`.

**Source:** Gross–Zagier–Kolyvagin (e.g. explicit theorem statement https://weixiao-lu.github.io/files/Kolyvagin_Theorem.pdf §1.3), published Kato bound as above. Complete finite arithmetic certificate `/mnt/data/bsd_exceptional_zero_rank3_verifier.py`.

## 492. Exceptional specialization of the three displayed rational sections: an EXACT dependence at t=8

**Proved independent correction to a preliminary numerical suggestion.** The conic `t^2-v^2=48` also has integer solution `(t,v)=(8,4)` (u=12). On `E_8:y^2=x^3-28x+16`, put `P=(-2,8),Q=(-4,8),R=(0,4)`. Direct group law gives `P+Q=(6,-8)` and `(P+Q)+R=(-2,-8)=-P`. Thus

`2P+Q+R=O` exactly.

More generally on the conic, `P+Q=(6,-t)` for all t. For `2P+Q+R=O` it is necessary and sufficient that `P=(-2,t)` lie on the line through `(6,-t)` and `R=(0,v)`. The slopes are `-t/4` and `-(t+v)/6`, so this is equivalent to `t=2v`. Combining with `t^2-v^2=48` forces `(t,v)=(8,4)` or `(-8,-4)`. This explains why a computational scan of the E8 reductions has mod-5 row rank only two, not three. E8 has three displayed point *sections* but these generate at most rank two; its full curve rank is NOT asserted equal to two. Previous preliminary commentary suggesting a nonzero E8 determinant is retracted by this exact calculation. The rank-three certificate for E7 (and the separate E13 proof) is unaffected.

The special relation illustrates a key project constraint: presence of extra rational sections after base change does not imply specialization rank increases unless independence is separately certified. It complements the user's stronger fact that generic rank cannot be an upper bound for arbitrary specialization ranks.

## 493. Failed exact leading-term transfer: the real height regulator cannot replace the p-adic regulator

**Attempt.** Compare the actual complex leading coefficient of E7 at order three to the first permitted cyclotomic p-adic coefficient at split p=2141, of degree four. In the published Burns–Kurihara–Sano Corollary 6.7 the desired p-adic Beilinson formula at split multiplicative p has shape

`L_{S,p}^{(r+1)} = [1/ord_p(q_E)](1-rec_p(q_E)) * [L^*_{S\setminus{p}}(E,1)/(Omega_xi * R_infty)] * R_p^Sch`

where the left side lives in the `(r+1)`st augmentation graded quotient and `R_p^Sch` is the relevant p-adic Schneider regulator. Importantly the authors explicitly state **"Conjecture 4.8 implies"** this identity; it is NOT an unconditional theorem. Their Hypothesis 2.2 includes (iii) the finiteness of `Sha(E/Q)[p^infinity]`, which is not known for either analytic rank-three control merely from equality of algebraic and analytic ranks. They separately prove an unconditional order-of-vanishing lower bound (Proposition 6.1), and a conditional refined higher Rubin formula (Theorem 6.2), neither of which establishes that complex and p-adic Taylor orders agree.

On E7, algebraic rank 3, complex order 3, `R_infty>0`, nonzero complex `L^*`, and nonzero local `Linv_2141` are all known. Yet neither finite `Sha[2141^infinity]`, the generalized Perrin–Riou leading-term comparison (Conjecture 4.8), nor `R_p^Sch !=0` follows from these facts. A nonzero local exceptional-zero factor does NOT force nondegeneracy of the global 3-by-3 p-adic height pairing. Consequently **even the exact value `ord_T L_2141(E7,T)=4` remains unproved by this comparison**; only the lower bound >=4 is established. This is an explicit failed attempt, with every missing hypothesis labeled, not a claimed BSD result.

The real period regulator belongs to a positive real symmetric form. Replacing a p-adic determinant by it would silently assume the missing p-adic height nondegeneracy and a mixed archimedean/p-adic comparison. Project countermodels in items 2/10/16 already show why determinant order and Selmer corank alone cannot provide that step.

**Primary source audited, including PDF screenshots:** Burns–Kurihara–Sano https://kurihara.math.keio.ac.jp/bks4.pdf, Hypothesis 2.2 (printed p866), Proposition 6.1 (p895), Corollary 6.7 (p897), Conjecture 4.8 (pp. 881–883), Theorem 6.2. Keep the source's distinctions between a conjecture, a hypothesis, and an unconditional theorem.

## 494. New no-go theorem for ALL finite tensor/Schur constructions of point 1-motives

**Proved theorem; extension of earlier one-sided trace obstruction.** Let `k` be a characteristic-zero field and let `0->V->W->U->0` be a short exact sequence of finite-dimensional representations of a group G. Let `F` be any functor built by finitely many tensor products, direct sums, duals, exterior powers, symmetric powers, Schur polynomial functors and fixed character twists. Then for every `g in G`, the characteristic polynomial of `g` on `F(W)` is the SAME as on `F(V directsum U)` (with corresponding functor applied); equivalently these operations do not recover the nontrivial extension class from characteristic polynomials.

*Proof.* For each fixed `g`, choose a basis adapted to V, so the matrix of g on W is block upper triangular. Over an algebraic closure its eigenvalue multiset equals that of the block-diagonal matrix on `V directsum U`. On tensor powers, the eigenvalue multiset is the multiplicative multiset of eigenvalues from each factor; on `Sym^n`, `wedge^n` and more general Schur polynomial representations, it consists of appropriate monomials in the original eigenvalues, with multiplicities depending only on their multiset (e.g. via the polynomial characters of GL). Dual replaces eigenvalues by their inverses, and character twists multiply them by known scalars. All of these are invariant under upper-triangular extension data. Iteration and direct sums preserve the conclusion. This establishes equality of characteristic polynomials for every group element. The statement does not include arbitrarily chosen non-functorial subrepresentations or extension-sensitive regulators.

Apply to the point 1-motive `M=[Z^r -> E]` for rational points of any elliptic E/Q: its p-adic representation fits `0->Vp E->Vp M->Qp^r->0`. For every prime of good reduction away from p, the Frobenius polynomials of `F(Vp M)` equal those of `F(Vp E directsum Qp^r)`, independent of which rational points define M. Thus ANY standard almost-everywhere Euler product obtained solely from a finite combination of such linear algebra functors is **trace-blind** to point-extension information, even after passing to exterior powers, symmetric powers, duals and Tate twists. The usual standard function for W is `(incomplete) L(E,s)*zeta(s)^r`, the same for split and nonsplit point extensions.

This closes a wide class of proposed "recover the rank using higher tensor/Frobenius Euler factors of the point 1-motive" arguments. To reach BSD from the point lattice, a construction must go beyond semisimplified Frobenius eigenvalues and include extension-sensitive information, such as a global Bockstein/regulator and a PROVEN comparison to the complex Taylor coefficient of the original `L(E,s)`. The no-go theorem is an obstruction to a proof method, not to BSD or to such regulator constructions.

## 495. Exact checkpoint and next original-target implication

Preserve the all-E/Q goal `rank E(Q)=ord_(s=1)L(E,s)`; finite Sha and the refined coefficient formula remain separate. This continuation produced (a) exact local p-adic Tate invariants at the two accepted rank-three controls, (b) their p-adic order shifts from Kato, (c) a certified INFINITE rank>=3 family with an unconditional same-curve complex order>=2 and p-adic order>=4, (d) the newly discovered exact E8 dependence relation, (e) a precise failed application of the conditional higher-rank p-adic Beilinson bridge, and (f) a theorem showing no finite Schur/tensor construction of the point 1-motive can recover extension classes from standard Frobenius Euler factors.

The FIRST unproved general-rank bridge remains a canonical comparison between arithmetic point/Selmer classes and the **complex** leading Taylor order of the original E. At split multiplicative primes, a more specific exact missing claim is to construct, without assuming finite Sha or generalized Perrin–Riou, a higher derivative of Kato's zeta class with a nondegenerate arithmetic height component and identify it with `L^(r)(E,1)` after the correct exceptional-zero shift. None of the newly proved finite/local facts establishes this. The two rank-three controls validate the intended normalizations, but their existing complex order certificates cannot serve as the missing universal comparison.

**No general BSD proof or elliptic counterexample obtained.** No spending, submissions, installations, third-party code downloads or external collaborators were used.

## 496. Uniform FULL mod-five and maximal three-point division-field Galois groups throughout the infinite family

**Proved strengthening of entry491.** For each `u=8+k*783769*2141^3` with k>=0, the residual representation

`rho_{E_u,5}: G_Q -> GL2(F5)`

is surjective, and the joint three-point 5-division field has degree exactly `7,500,000` over Q. In particular the Chebotarev densities from earlier entries478–479 are UNIFORM for every member of this explicitly described infinite family, not just for E7.

*Proof of full mod-five image.* Every curve reduces modulo the good prime7 to E7. Exact point counting gives `#E_u(F7)=12`, so `a_7=7+1-12=-4`. The characteristic polynomial of residual Frobenius7 has discriminant `a_7^2-4*7=-12=3 mod5`, which is nonsquare. Hence the image of rho on F5² is irreducible: if it preserved an F5-line, this Frobenius polynomial would split. At the DIFFERENT prime2141, every member has split multiplicative type I1, with Tate period of valuation1. In its mod-five Tate module inertia contains a transvection of exact order five, since adjoining a fifth root of the Tate parameter is tamely ramified and the valuation1 is prime to5. An irreducible subgroup of GL2(F5) containing a nontrivial transvection contains SL2(F5): conjugating the transvection by an element moving its fixed line produces a transvection with a different fixed line; in a basis of the two fixed lines, their powers give the upper and lower elementary matrices. These generate SL2(F5). The Weil-pairing determinant is the full mod-five cyclotomic character, surjective onto F5^×. Therefore the image is ALL GL2(F5), of order `(25-1)(25-5)=480`.

*Proof of full point-translation image.* At good primes19,71,83 the three point Kummer classes are independent modulo five, with determinant1 (entry491), and `E_u(Q)[5]=0` follows also from the full Galois image. Let `L=Q(E_u[5])`, and choose fifth roots `P_i'` of the three rational points. The affine Galois group of the joint roots over `L` embeds in `E_u[5]^3`. It is stable under GL2(F5). The central scalar `-I` shows `H1(GL2(F5),E_u[5])=0`: the cocycle identity with central -I makes every cocycle a coboundary. Consequently restriction `H1(Q,E[5])->H1(L,E[5])` is injective, and the three independent Kummer classes remain independent when restricted to `G_L`. Matrix-unit invariance implies a GL2(F5)-stable subgroup of `V^3` is `V tensor U` for some `U⊂F5³`; were U proper, an F5-linear combination of our three restricted classes would be zero, contradicting that injectivity. Hence U=F5³ and the translation image is exactly `V^3`, of cardinality `5^6`. The image projects onto all GL2 and contains all translations, hence is the full affine semidirect group, and

`[ Q(E_u[5],5^(-1)P,5^(-1)Q,5^(-1)R) : Q ] = 480*5^6 = 7,500,000.`

By Chebotarev, for every member (separately, with the usual finite set of bad primes omitted) the primes where full E[5] is rational over F_ell and all three points are 5-divisible have natural density `1/7,500,000`. Across all good primes the joint local divisibility density is

`(365+114/125+1/15625)/480=59556/78125`,

and with additional modular constraints `ell=1 mod5`, `a_ell=2 mod5`, the joint density is `3001/7,500,000`, as in entries478–479. All of these are exact arithmetic statements for each E_u.

**Combined same-curve results.** Every E_u has `rank>=3`, a COMPLEX central zero of order >=2 (Gross–Zagier–Kolyvagin contraposition), a cyclotomic 2141-adic L zero of order >=4 (Kato), a nonzero local exceptional-zero invariant whose normalized first digit is1243, and the same abstract maximal affine mod-five division-field group. These results STILL do not give equality of the complex and algebraic ranks for k>0. The identical Galois-group type, finite splitting densities and fixed 2141-local Taylor data cannot be used as a surrogate for an actual complex central-derivative comparison.

This is a scoped original-family arithmetic amplification, not a universal BSD theorem or proof of novelty relative to all publications.

---

# New independent continuation, 2026-11-21: entries 497–504

**Full target remains unrestricted rank BSD for every elliptic curve over Q.** These entries incorporate the coordinator's four-independent-point control at `t=817/56`, without presuming its exact total rank or analytic rank. Results here distinguish unconditional calculations, published theorems, formal counterexamples to proof bridges, and missing general implications. The earlier rank-three sign-change counterexample and all restrictions on the GU auxiliary route remain retained.

## 497. Canonical full-point Kummer degree, rather than the chosen-subspace density

**Theorem (unconditional under full p^n image).** Let `p>=5`, `R=Z/p^n Z`, `V=E[p^n]`, and assume `rho_{E,p^n}(G_Q)=GL2(R)`. Set `r=rank E(Q)` and `K=Q(E[p^n])`. Let `F_MW,n` be obtained by adjoining to `K` the division points `[p^n]^{-1}P` for every `P in E(Q)` (a finite extension because a finite set of generators suffices). Then

`Gal(F_MW,n/K)=Hom_R(E(Q)/p^n E(Q),V) = V^r`

and

`[F_MW,n:Q]=|GL2(R)| p^(2nr)`.

In particular the primes `ell` with `E[p^n] subset E(F_ell)` and `red_ell E(Q) subset p^n E(F_ell)` have natural density `(|GL2(R)|p^(2nr))^(-1)` (exclude `ell=p` and finitely many bad primes). This is canonical for the WHOLE Mordell–Weil group, not for a chosen independent subset.

**Proof.** Full image implies `E(Q)[p]=0`, so `A=E(Q)/p^n E(Q)=R^r`. Kummer embeds `A -> H1(Q,V)`. The central `-I` in GL2(R) acts as `-1` on `V`; for any 1-cocycle `c` on this finite group, the central cocycle identity gives `(h-1)c(-I)=(-2)c(h)`, exhibiting `c` as a coboundary. Hence `H1(GL2(R),V)=0`, and inflation–restriction injects global classes into `H1(G_K,V)=Hom_cont(G_K,V)`. The joint translation image `W subset Hom_R(A,V)=V^r` is stable under GL2(R), hence under its R-algebra, all of `M2(R)`. Matrix-unit invariance gives `W=U directsum U` for some `U subset R^r`. If `U` were proper, the self-duality of the finite Frobenius ring `R` provides a nonzero `a in A` annihilated by every functional in `U`, contradicting the injectivity just proved. Thus `U=R^r`. Chebotarev proves the density. The same argument works verbatim for any finite R-submodule of global H1; see entry502.

For the accepted rank-three `E_7`, at `p=5,n=1` this reproduces `7,500,000`. For the rank-at-least-four control `E_(817/56)`, the FULL-point field has degree at least `187,500,000`; equality would require total rank exactly four, which is NOT established here. The first three chosen points still generate an abstract degree-`7,500,000` subfield. This reconciles the coordinator's new control exactly.

## 498. Four explicit mod-five-independent points on E_(817/56), with a new certificate

Put

`E_*: y²=x³-28x+516961/3136`.

A specific fourth point, in addition to the three previously identified, is

`P=(-2,817/56), Q=(-4,817/56), R=(0,719/56), S=(-5,751/56)`.

All lie on `E_*`; the last follows from `15+516961/3136=(751/56)²`. At primes `103,197,227,257` the group orders are `105,190,235,280`, all divisible by five exactly once. Using group-law arithmetic, the image of `[ #E(F_ell)/5]` on the four points has coordinates in a generator of order five given by the four rows

`(1,4,2,2), (1,2,4,1), (1,2,4,3), (1,0,0,4)`.

Their determinant is `-24=1 mod5`. A global combination divisible by five would reduce to zero under all four maps, so its coefficients must be divisible by five. Thus these four point classes are independent in `E_*(Q)/5 E_*(Q)`; in particular they span a primitive rank-four Z5 sublattice. This is stronger than rational independence.

The discriminant in the given rational model is

`Delta(E_*) = -6352166814299/(2^8*7^4)`.

The integer `q=6352166814299` is prime by the Lucas `q-1` certificate: `q-1=2*398731*7965479`, each displayed factor is prime by trial division up to its square root, `2^(q-1)=1 mod q`, and for each prime divisor `d` of `q-1`, `gcd(2^((q-1)/d)-1,q)=1`. Since `c4=1344` is a q-unit, the curve has type `I1` at q, giving a mod-five transvection. At good prime 3, `#E_*(F3)=7`, `a3=-3`, and `a3²-12=-3=2 mod5`, nonsquare. The mod-five Galois image is irreducible and contains a transvection; conjugating two distinct such transvections generates `SL2(F5)`. Cyclotomic determinant is surjective, hence the image is `GL2(F5)`. The FOUR chosen points generate a field of exact degree `480*5^8=187,500,000` over Q. The standard-library verifier `bsd_rank4_fourpoint_kummer_verifier.py` replays the full certificate, including exact primality.

## 499. A genus-one parameter curve and an infinite rank-at-least-four arithmetic family

To make all four points rational simultaneously, write `t²-v²=48`, `t²-w²=33`, where the first two sections are `(-2,t),(-4,t)` and the new sections are `(0,v),(-5,w)`. Setting `t=(u+48/u)/2` reduces the second square condition to

`Y²=u^4-36u²+2304`, `Y=2uw`.

The birational change

`X=2(Y+u²), Z=2u(X-36)`

identifies this genus-one curve with

`B: Z²=(X-36)(X-96)(X+96)`.

The inverse functions are

`u=Z/[2(X-36)]`, `t=(u+48/u)/2`, `v=(48/u-u)/2`, `w=(X/2-u²)/(2u)`.

Direct substitution proves both square conditions and all four E_t point equations.

Two rational points of B are `T=(256,3520)` and `S0=(100,224)`, and direct doubling gives **`S0=2T`**. Their t-parameters are respectively `7` and `817/56` (with the chosen signs of v,w). The point T is nontorsion: B has good reduction at 7 and 13, with group orders 8 and 12, while T reduces to orders 4 and 3, respectively. Any rational torsion order would divide both group orders after excluding its possible 7 and 13 primary parts using the opposite prime, hence would divide 4; the order-three reduction contradicts this.

Let `q=6352166814299` and `Pset={13,103,197,227,257}`. The parameter curve B has good reduction at every listed prime (its discriminant is supported on `{2,3,5,11}`). Exact point counts for B are:

`#B(F13)=12, #B(F103)=100, #B(F197)=200, #B(F227)=248, #B(F257)=276`.

Define the explicit positive integer

`M=16427520000 * q * #B(F_q)`;

`#B(F_q)` is a mathematically well-defined integer, even though no explicit enumeration at this enormous prime was carried out. Let `S_k=(2+kM)T` on B and define `u_k,t_k,v_k,w_k` by the inverse rational maps. Exclude finitely many k giving poles or singular E_t fibres.

For each `ell in Pset`, `S_k` reduces to `2T=S0` modulo ell because M is divisible by `#B(F_ell)`. At q, multiplication by `#B(F_q)` puts T into the formal subgroup, and multiplication by q moves it into the kernel modulo q². Thus `S_k` is congruent to S0 modulo q². The inverse rational maps are integral at S0 at all these primes. It follows that the four E_(t_k) points have exactly the four rows of entry498 at 103,197,227,257. Modulo 13 the fibre is E_* with `#E_*(F13)=16`, `a13=-2`, so its Frobenius discriminant `4-52=-48=2 mod5` remains nonsquare; moreover `a13=-2` makes every such fibre good ordinary at 13. At q, the discriminant is still of valuation one, giving the same transvection. Therefore EVERY surviving member has four mod-five-independent points and full residual `GL2(F5)` image. Its four-point division field has exact degree `187,500,000`.

The point T has infinite order and the rational map `t:B->P1` is nonconstant and finite-to-one, so the sequence takes infinitely many distinct values. The j-invariant `j(E_t)` is also nonconstant in t. Consequently **infinitely many distinct geometric j-invariants** occur: there are infinitely many pairwise non-isomorphic elliptic curves over Q with rank >=4 and these uniform exact mod-five properties. This is a family-existence theorem, NOT BSD for the individual fibres.

At all higher 5-power levels the four chosen classes remain a primitive free `Z/5^n` submodule, and full residual image lifts to full 5-adic image by Serre's theorem (p>=5). Hence their joint division fields have degree

`|GL2(Z/5^n)| * 5^(8n) = 480*5^(12n-4)`.

The selected THREE point towers have degree `480*5^(10n-4)`; their ratio is `5^(2n)`. The density distinction is thus amplified at every level, but a canonical FULL-point field may be larger if actual rank exceeds four.

## 500. An exact degeneration of the fourth section at t=7

The base parameter `T` has `(t,v,w)=(7,-1,4)`. On `E_7`, the four sections specialize to `P=(-2,7),Q=(-4,7),R=(0,-1),S=(-5,4)`. Exact group addition yields

`P+Q=(6,-7)` and `(P+Q)+R=(-5,-4)=-S`, so **`P+Q+R+S=O`**.

More generally `(P+Q)=(6,-t)` and the x-coordinate of `(P+Q)+R` is `(t+v)^2/36-6`. For `P+Q+R+S=O` the x-coordinate must equal `-5`, which forces `(t+v)^2=36`. Coupled with `t²-v²=48`, this gives only `(t,v)=(7,-1)` or `(-7,1)` with the compatible sign of w. At `t=817/56` the reduction determinant entry498 excludes ANY integral dependence modulo five among the four sections. The particular specialization relation at t=7 has disappeared exactly as expected. This is a concrete, exact example of an extra fibrewise relation over the elliptic parameter base; it is not a contradiction to rank-three E7 or to the new generic rank-four sections.

## 501. A universal Selmer Kummer-field theorem and an exact Sha density ratio

**Theorem (unconditional under full GL2 image).** Keep `p>=5`, `R=Z/p^n`, `V=E[p^n]`, and `K=Q(E[p^n])` with full `GL2(R)` Galois image. Let `A` be ANY finite R-submodule of `H1(Q,V)`. Define `F_A` as the field over K cut out by the common kernels of the restricted cocycles `A -> Hom(G_K,V)`; this does not depend on cocycle representatives. Then

`Gal(F_A/K) = Hom_R(A,V)`, and `[F_A:Q]=|GL2(R)|*|A|²`.

**Proof for nonfree A as well.** Inflation–restriction is injective by the central -I argument of497. The image `W` of `G_K` in `Hom_R(A,V) = A^* directsum A^*`, `A^*=Hom_R(A,R)`, is stable under the entire matrix algebra `M2(R)`, hence has form `U directsum U` for some R-submodule `U subset A^*`. The evaluation pairing `A x A^* -> R` is perfect: write A as a sum of cyclic modules `R/(p^{e_i})` and use that `R` is a finite Frobenius/self-injective ring. If U were proper, its annihilator in A would contain a nonzero class. That class would restrict to zero on all G_K, contradicting inflation–restriction. Thus U=A^*. Since `|A^*|=|A|`, the translation group has cardinality |A|². No arbitrary semidirect splitting is asserted when A is nonfree.

Apply this to `A_MW=E(Q)/p^n E(Q)` and `A_Sel=Sel_{p^n}(E/Q)`. Their inclusion gives `F_MW subset F_Sel`, with the Kummer exact sequence

`0 -> A_MW -> A_Sel -> Sha(E/Q)[p^n] -> 0`.

The corresponding exact field-degree and complete-splitting-density identities are

`[F_Sel:F_MW]=|Sha(E/Q)[p^n]|²`,

`delta_Sel,n/delta_MW,n=|Sha(E/Q)[p^n]|^(-2)`.

Here `delta_A,n=1/[F_A:Q]` is the density of good primes splitting fully in F_A; equivalently the torsion is rational there and every indicated cohomology class is locally trivial. Thus `Sha[p^n]=0` IF AND ONLY IF these two finite division fields agree. This provides a precise global-point-versus-Selmer test, without assuming finite total Sha.

At p-adic limit, since Sha[p^infinity] is of cofinite type, for `t_p=corank_Zp Sha[p^infinity]` we obtain

`lim_(n->infinity) (log_p(delta_MW,n/delta_Sel,n))/(2n) = t_p`.

The full-point density similarly has exact normalized exponent r at each n. This recovers the **Selmer rank defect** separately from the Mordell–Weil rank; it does not identify either exponent with the COMPLEX order of `L(E,s)`.

## 502. Positive-density detector of non-point Selmer classes

A further exact consequence of501. If `c in Sel_{p^n}(E/Q)` has image of exact order `p^e` in `Sha[p^n]`, there is a positive-density set of good primes where **all** rational points are locally p^n-divisible and `E[p^n]` is locally rational, but `c` has nonzero local Kummer class. The density among ALL rational primes is

`delta_MW,n*(1-p^(-2e))`.

Indeed over `F_MW`, the relative translation group is `Hom_R(Sha[p^n],V)` by self-injective dual exactness. Evaluation at c is surjective onto `V[p^e]` (extend a homomorphism defined on its cyclic subgroup to all of Sha), a group of cardinality `p^(2e)`. Precisely the fraction `p^(-2e)` gives zero. Chebotarev proves the claim. This does not violate the Selmer local condition: the finite local Kummer subgroup at such a prime can contain nonzero classes not generated by the reductions of global rational points. It therefore **does not force Sha=0**. The criterion is non-effective until the whole global MW image is independently determined, and no rank-equality inference is made.

## 503. Direct original-L checks: a universal fourth p-adic zero, and the failed complex transfer

At the prime 13 every E_(t_k) from499 has good ordinary reduction with trace `a13=-2`. Kato's unconditional rank-order theorem, as quoted in the already audited Burns–Kurihara–Sano Proposition6.1, gives

`ord_(T=0) L_13(E_(t_k),T) >= rank E_(t_k)(Q) >= 4`.

The curve's *complex* L-function satisfies `L(E_(t_k),1)=L'(E_(t_k),1)=0` by the established analytic-rank-zero/one theorem of Gross–Zagier–Kolyvagin applied contrapositively to rank>=4. No unproved extra vanishing `L''=L'''=0` is inferred. The modular form's functional equation determines the parity of its complex order individually, but the root number is not shown constant on this sparse family.

**Attempted bridge and exact failure.** A tempting claim is `ord_complex L(E,s) = ord_cyclotomic_padic L_p(E,T)` for good-ordinary p. Interpolation alone does not establish this: finite-order p-adic characters accumulate in the weight variable, not in the complex variable s. Recovering the fourth complex zero from the four p-adic zeroes would require an unproved general comparison and control of global p-adic height nondegeneracy. The earlier rank-three control at its split multiplicative prime2141 gives a sharper warning: complex order is3 but the p-adic order is at least4 because of the **genuine exceptional zero**; a naive equality without the correct local adjustment is already false. The successful rank-four p=13 calculation removes that local exceptional zero but not the global comparison gap. This attempt does not solve BSD.

A local test on the four E_*=E_(817/56) points makes the height issue concrete. Since `#E_*(F13)=16`, all `[16]P_i` lie in the formal group. Exact rational group-law arithmetic for the parameter `t_form=-x/y` gives

`[t_form([16]P_i)/13 mod13]_(P,Q,R,S)=(5,2,6,2)`.

For the invariant differential `dx/(2y)`, the formal group logarithm is congruent to `t_form` modulo `13²`; dividing by 16 yields

`[log_13(P_i)/13 mod13]=(6,5,2,5)`.

The local logarithm takes values in the ONE-dimensional `Lie(E)(Q13)`; a 4x4 pairing of the simple form `c*log_13(P_i)*log_13(P_j)` has rank at most1 and determinant0, regardless of the four rationally independent points. The genuine cyclotomic p-adic height is global and need not factor in this way. Thus a one-place logarithm determinant cannot provide the higher-rank regulator/nondegeneracy required by a fourth-order p-adic leading-term formula.

## 504. What an actual full-rank proof must now do; no completion claim

The four-point/elliptic-parameter results give infinitely many original E/Q with rigorous rank>=4, a fixed good-ordinary 13-adic fourth-order zero, and a uniform exact Kummer tower. The universal finite-level Selmer Kummer theorem detects the possible p-primary Sha defect as a square field-degree ratio and gives a Chebotarev test for any non-point Selmer class. These are substantial **arithmetic control statements**, not a comparison with `ord_(s=1)L(E,s)`.

Two independent missing steps are explicit. (1) Prove a higher-rank **complex** reciprocity/leading-zero identity showing that four independent rational points force at least four central complex vanishing moments, or prove a reverse bound from analytic data to all global point directions; the established rank 0/1 theorem gives only `a>=2` here. (2) Prove that any surplus complex vanishing arises from independent arithmetic directions and not from a nonsemisimple or nongeometric Selmer/height extension; prior two-variable and Iwasawa countermodels prohibit replacing this by formal determinant/parity arguments. A finite Kummer density and a local p-adic-log vector do not supply either step. Any genuine analytic comparison must use the Hasse–Weil L of E itself and must survive the `t=7` to `t=817/56` rank jump.

No general BSD proof or actual elliptic BSD counterexample is obtained. Do not claim priority or novelty for the infinite arithmetic family without an independent literature search. No spending, downloads, installations, outreach or external submissions occurred. The standard-library verifiers saved alongside this note are `bsd_rank4_fourpoint_kummer_verifier.py` and `bsd_rank4_genus_one_parameter_verifier.py`.

# Independent continuation, 2026-11-21: recovery of timed-out work and entries 505–510

**Recovery.** Entries 497–504 above were already written in the timed-out session. They have been recovered from this same local research note WITHOUT rerunning any earlier numerical calculations. In particular the full-point field of E_7 (rank exactly 3) has degree 7,500,000 at p=5, whereas the four-chosen-point field of E_(817/56) has degree 187,500,000 and the full-point field of that curve has degree at least this large. The abstract statistics of the THREE chosen-point fields agree. The latter curve's total rank and complex analytic rank have NOT been established. Entries 498–500 also supply four mod-5 independent points, an elliptic genus-one parameter family with infinitely many rank-at-least-four fibres, and the exact fourth-section dependence at t=7. Entry 501 proves an exact Selmer/MW field-degree ratio, entry 502 gives the positive-density detector of nonpoint Selmer classes, and entry 503 establishes a separate p-adic order-four lower bound at good-ordinary p=13 without transferring it to the complex variable.

## 505. Recover ALL invariant factors of the p-primary Sha quotient from canonical Chebotarev densities

Under the full-GL2(Z/p^n) hypothesis of 501 for all n, write delta_M,n and delta_S,n for the complete-splitting densities of the full MW and full Selmer Kummer fields. Put h_0=0 and

    h_n=(1/2)*log_p(delta_M,n/delta_S,n)=log_p |Sha(E/Q)[p^n]|.

The cofinite-type p-primary group admits an abstract decomposition

    Sha[p^infty] ~= (Q_p/Z_p)^t directsum (directsum_i Z/p^(e_i)).

This is not a finite-Sha assumption; t may be positive. Counting p^n-torsion gives the exact identity

    h_n = n*t + sum_i min(n,e_i).

Consequently, for d_n=h_n-h_(n-1),

    d_n=t + #{i: e_i>=n},
    t=lim_(n->infty) d_n,
    #{i:e_i=n}=d_n-d_(n+1).

Thus the COMPLETE sequence of full-field density ratios recovers the divisible corank and every finite invariant factor, not merely t. Since the Cassels-Tate pairing on the finite quotient by the divisible radical is alternating and perfect for the elliptic principal polarization at odd p, the finite cyclic factors occur in equal pairs. Writing them as (Z/p^e_j)^2, we get

    log_p(delta_M,n/delta_S,n)=2*n*t + 4*sum_j min(n,e_j).

This supplies a necessary mod-4 congruence for density ratios. It does not impose a complex analytic-rank bound; computing these fields presupposes access to the entire MW and Selmer modules.

## 506. The full-field theorem needs less than GL2: a central scalar plus the full matrix algebra

Let R=Z/p^n, p odd, V=R^2, and G=rho_(E,p^n)(G_Q) in GL2(R). Suppose (i) G contains a central scalar z*I with z-1 a unit of R, and (ii) the R-algebra generated by G is all M2(R). For ANY finite R-submodule A of H1(Q,V), let K=Q(E[p^n]) and F_A/K be cut out by the restrictions of all classes in A. Then

    Gal(F_A/K) ~= Hom_R(A,V),
    [F_A:Q]=|G|*|A|^2.

Proof: Sah's central-element cocycle identity implies H1(G,V)=0, so inflation–restriction embeds A into Hom(G_K,V). Its joint evaluation image W subset Hom_R(A,V) is G-stable and therefore M2(R)-stable. Using the matrix units, W=U directsum U for U subset A^*=Hom_R(A,R). Over the finite self-injective Frobenius ring R, the evaluation pairing A x A^* ->R is perfect. If U is proper, its annihilator is nonzero, yielding a nonzero A-class whose restriction is zero, contradiction. Hence U=A^*, W=Hom_R(A,V). Cardinality follows. No claim of semidirect splitting of Gal(F_A/Q) is necessary. In particular, the full-point and Selmer density identities of 501 hold with |G| in place of |GL2(R)| whenever (i)–(ii) are verified; they do not require globally surjective GL2 image. This enlarges the potential scope of the Kummer method, but the analytic gap is untouched.

## 507. A direct Euler-factor test: splitting-prime terms alone do NOT control L(E/F,s)

For any finite Galois extension F/Q with group G, remove its ramified primes and the bad primes of E. At each remaining prime ell write the elliptic Frobenius eigenvalues alpha_ell,beta_ell with alpha+beta=a_ell, alpha*beta=ell, |alpha|=|beta|=sqrt(ell), and g_ell=Frob_ell in G. For Re(s)>3/2, the genuine (absolutely convergent) Hasse–Weil Euler product over F satisfies

 log L^S(E/F,s)
  = |G| * sum_(ell notin S) sum_(m>=1, g_ell^m=1)
       (alpha_ell^m+beta_ell^m)/(m*ell^(m*s)).           (507.1)

Proof: the regular permutation representation of G has trace |G| when g^m=1 and zero otherwise; the m-th Frobenius trace on V(E) tensor regular is (alpha^m+beta^m)*trace_reg(g^m). Equivalently, an ell of residue degree d contributes |G|/d copies of the local Euler factor over F_(ell^d), giving the same expansion.

The m=1 term of (507.1) involves exactly the primes that split COMPLETELY in F; its density is 1/|G|. But the m=2 term receives contributions from every prime with g_ell^2=1, even when g_ell!=1. Its size at s=1 is borderline: |alpha_ell^2|/ell^2=1/ell, so it cannot be discarded as an analytic error. The entire m>=3 tail, however, is locally uniformly holomorphic for Re(s)>5/6, because the worst m=3 term is O(ell^(3/2-3Re(s))) and its prime sum converges there.

For a quadratic extension F, g_ell^2=1 at EVERY unramified prime, so the m=2 term is unweighted by splitting. Thus even the simplest Artin formalism example proves why a full-point Chebotarev density cannot be converted into the central order of the ORIGINAL L(E,s) by retaining only split-prime first powers. For huge nonabelian Kummer groups there are many nontrivial higher Artin twists; moreover analytic continuation of L(E/F,s) is not assumed for arbitrary such F. Equation (507.1) claims only its absolutely convergent Euler-product region.

## 508. A precise original-L prime-log residue theorem, including the universal -1/2 term

Let E/Q be ANY elliptic curve and S its finite bad-prime set. Define for Re(s)>3/2

    P_E(s)=sum_(ell notin S) a_ell/ell^s.

This prime Dirichlet series has a canonical meromorphically continued DERIVATIVE near s=1, and

    Res_(s=1) P_E'(s) = ord_(s=1)L(E,s) - 1/2.     (508.1)

Proof. Take logarithms of the local Hasse–Weil factors in Re(s)>3/2:

    log L^S(E,s) = P_E(s)+S_2(s)+H_>=3(s),
    S_2(s)=(1/2)*sum_(ell notin S) (alpha_ell^2+beta_ell^2)/ell^(2s).

The tail H_>=3 is holomorphic for Re(s)>5/6, as in 507. Put t=2s-1 and u_ell=alpha_ell/sqrt(ell), v_ell=beta_ell/sqrt(ell); then u*v=1. The GOOD adjoint local Euler factor has normalized eigenvalues u_ell^2, 1, v_ell^2. Its logarithm minus log zeta^S(t) has first-prime term (u_ell^2+v_ell^2)/ell^t, with all higher prime-power terms holomorphic for Re(t)>1/2. Thus

    S_2(s)=(1/2)*(log L^S(Ad E,2s-1)-log zeta^S(2s-1))+H_2(s),

with H_2 holomorphic near s=1. The standard Rankin–Selberg/Petersson formula ensures L^S(Ad E,t) is holomorphic and NONZERO at t=1, for all weight-two cuspidal elliptic newforms. Differentiating the identity gives a meromorphic continuation of P_E'(s), even if P_E(s) itself has a multivalued logarithmic branch. Near s=1, L'/L(E,s) has residue a=ord_(s=1)L(E,s), whereas (d/ds)(-S_2(s)) contributes -1/2 because zeta'/zeta(2s-1)~-1/[2(s-1)]. The other terms are holomorphic. This proves (508.1). Omitting the m=2 term would shift the answer by 1/2; its correction is indispensable.

Combining (508.1) with 506 gives the following EXACT prime-statistics formulation of full rank BSD, whenever the Galois conditions of 506 hold at some p^n:

 BSD(E)  iff
    Res_(s=1) P_E'(s)
       = - (1/(2n))*log_p(|G|*delta_MW,n) - 1/2.    (508.2)

This is a nontrivial analytic re-expression but NOT a proof: ordinary Chebotarev supplies only an unweighted indicator-density law and does not establish the REQUIRED WEIGHTED correlation with the elliptic coefficients a_ell. Formula (508.2) is the precise still-unproved bridge for this method.

The certified rank-three E_7 and E_13 have a=3, so their prime-log residues are 5/2 by (508.1). For E_7, the full-point density from entry 497 gives the RHS of (508.2) also 5/2. For the rank-at-least-four E_(817/56), the full-point density gives a RHS >=7/2; the analytic residue is NOT certified. Any proof of (508.2) for this original curve would imply its analytic order is at least four. Do not substitute the degree of the chosen-THREE-point field: that would yield the wrong predicted rank three for the rank-four control.

Primary source scope: the adjoint L(1) nonvanishing is the standard normalized Petersson norm/Rankin–Selberg theorem, e.g. Hida's lectures `https://www.math.ucla.edu/~hida/205a.1.16f/Lec16F.pdf`, Theorem 5.7, and Shimura's formula. The general BSD target is Clay's official birchswin.pdf; neither source proves (508.2).

## 509. Formal duality countermodel: base-point and Sha densities cannot determine a p-adic zero order

Let p be odd, R=Z_p[[W]] with involution bar(W)=-W. For a>=1 put M_a=(R/W^a)^2. Every M_a is Z_p-free (hence has no finite R-submodule), and

    M_a/W M_a=Z_p^2,
    char_R M_a=(W^(2a)).

Each admits a perfect skew-Hermitian linking pairing to Frac(R)/R. For even a use (x1*bar(y2)-x2*bar(y1))/W^a; for odd a use (x1*bar(y2)+x2*bar(y1))/W^a. Well-definedness follows because W^a kills the coordinates. Both 2x2 coefficient matrices are units and hence the pairings are perfect; conjugate-transposition changes their signs by -1 using bar(W^a)=(-1)^a W^a.

Thus M_1 and M_2 have identical augmentation coinvariants Z_p^2 and compatible perfect skew-Hermitian linkings, but characteristic orders 2 and 4. In a formal algebraic main-conjecture model the same BASE MW/Sha data could coexist with distinct p-adic analytic orders. These are ABSTRACT modules, not actual Selmer modules of elliptic curves. They show that the full p-power base-field Chebotarev densities, even supplemented with these broad duality properties, do not force the crucial augmentation semisimplicity or a complex derivative comparison. This is consistent with earlier countermodels in the original eight-part archive; it is a new direct test against the recovered density proposal, not an elliptic BSD counterexample.

## 510. New continuation target after the recovery

The exact all-curves arithmetic output is the complete full-point/Selmer density tower, subject to the explicit mod-p representation hypotheses. The exact original-complex-L output is the residue (508.1). The only missing connection in this line is the *weighted* prime identity (508.2). The recovered rank-three E_7 is a positive control; the four-point E_(817/56) is the adversarial control because its selected-three-point density is indistinguishable from the rank-three field, while its canonical full-point density changes by at least a factor 25. Arbitrary extension traces and point-lattice modular theta functions fail to provide the weighted correlation automatically. The proven global Kummer theorem is not a proof of (508.2), and a claimed correlation derived solely from Chebotarev would be false reasoning. A future constructive path would require an actual explicit-formula/height identity for the original modular form f_E showing that its regularized prime logarithmic residue equals the exponent of the WHOLE Mordell–Weil Kummer tower, while independently controlling non-point Selmer directions. This is the same nontrivial rank comparison in a sharper form, not a solved step.

The unrestricted rank-BSD objective is still ACTIVE and INCOMPLETE. No external submission, install, code download, or spending has occurred. Older computations, exact rank-three fibres, rank-four independence, and the sign-change counterexample are preserved verbatim in earlier entries.

---

# Independent successor continuation, 2026-11-21: entries 511–519

## 511. At each good prime, the full-point Kummer probability is the p-adic norm of the ORIGINAL local central Euler factor

Let E/Q have rank r, p>=5, full p-adic image GL2(Zp), and a Mordell–Weil basis P_1,...,P_r (r may be zero). Full-image and the item 506 Kummer argument give Gal(Q(E[p^n], [p^n]^-1 E(Q))/Q(E[p^n])) ~= E[p^n]^r at every n. At a good ell!=p, put A_n=rho_(E,p^n)(Frob_ell). Finite-field Kummer theory and Lang's theorem give

 E(F_ell)/p^n E(F_ell) ~= H1(F_ell,E[p^n]) ~= E[p^n]/(A_n-I)E[p^n].

Conditional on A_n, translation coordinates of the r division classes are uniform in E[p^n]^r. Therefore the conditional probability of every P_i being p^n-divisible in E(F_ell) is |coker(A_n-I)|^-r = |E(F_ell)[p^n]|^-r. The inverse-limit conditional probability is |E(F_ell)[p^infty]|^-r = p^(-r v_p(#E(F_ell))). Since det(I-rho_(E,p)(Frob_ell))=#E(F_ell) as an integer, and the ORIGINAL good central local Euler factor is L_ell(E,1)=ell/#E(F_ell), we obtain the exact identity

 Probability(all r locally p^infty divisible | linear Frob) = |#E(F_ell)|_p^r = |L_ell(E,1)|_p^-r.

This is a local original-E arithmetic–analytic connection. It does NOT identify the complex globally continued L(E,1) or its Taylor order with such conditional probabilities.

## 512. Exact all-level natural-density law, Igusa integral and complete enumeration checks

Let D_(p,infty)(E) be the set of good ell!=p for which EVERY rational point of E(Q) reduces into p^n E(F_ell) for EVERY n>=1. For all finite n, Chebotarev gives a natural density delta_n equal to the Haar average over GL2(Z/p^n) of |coker(A-I)|^-r. The intersection D_(p,infty) also has a natural density. Indeed D_n\D_infty is contained in the set of ell with p^(n+1) dividing #E(F_ell): if E(F_ell)[p^infty] has exponent at most p^n, local p^n-divisibility already implies p^m-divisibility for all m>=n. Chebotarev gives the latter tail set density mu{A:v_p(det(I-A))>=n+1}; it tends to 0 because det(I-A) is a nonzero analytic polynomial on GL2(Zp) and its zero set has Haar measure zero. Thus delta_n converges to the true natural density, and

 delta_(p,infty)(r) = integral_(GL2(Zp)) |det(I-A)|_p^r dA.

This expression depends ONLY on p and the number r of point directions under the maximal-image hypothesis.

Write g=|GL2(Fp)|=p(p-1)^2(p+1), N1=(p+1)(p^2-p-1), N0=g-N1-1. Among residual matrices there are N0 with no fixed vectors, N1 with one-dimensional fixed space, and the identity with two. For d=1 matrices, the determinant map is smooth and the lift has valuation 1+v_p(U) for U Haar-uniform in Zp. Its contribution is p^-r(1-p^-1)/(1-p^(-r-1)). For residual identity, write A=I+pB with B Haar Mat2(Zp); the contribution is p^-2r J_r, where

 J_r=int_Mat2(Zp) |det B|_p^r dB
    = ((1-p^-1)(1-p^-2))/((1-p^(-r-1))(1-p^(-r-2))).

The last formula follows from the first-column recursion: the first column is primitive with probability 1-p^-2, giving determinant a uniform p-adic integer; otherwise factor p from the column and recurse with probability p^-2-r. Hence

 delta_(p,infty)(r)=[N0+N1 p^-r(1-p^-1)/(1-p^(-r-1))
 + p^-2r (1-p^-1)(1-p^-2)/((1-p^(-r-1))(1-p^(-r-2)))]/g.

At p=5, exact values:
- r=3: finite level 5: 59556/78125; level 25: 581313941431/762939453125; infinite: 247551/324896 = 0.761939205161...
- r=4: finite level 5: 1485931/1953125; level 25: 362739940817181/476837158203125; infinite: 18565153/24404688 = 0.760720768075...
- Difference infinite(r=3) - infinite(r=4) = 773125/634521888 > 0.

For the rank-three control E_7 these are predictions from its known p=5 maximal images. For the rank-at-least-four E_(817/56), the rank-four value is an UPPER BOUND on its full-point density, conditional on its full 5-adic image, while the selected-three-point event retains the rank-three law. Do not silently assert its rank equals four.

Companion source /mnt/data/bsd_igusa_kummer_density_verifier.py performed exhaustive enumeration over GL2(Z/9) and GL2(Z/25), checking exact level-two rational densities for p=3,5 and r=2,3,4. It also checked p=3,5,7 exact residual counts. Only the Python standard library was used.

## 513. A genuine mod-two original-L bridge from the canonical Selmer division field

Under the residual version of item506, let F_(Sel,p) be the joint field of all Sel_p(E/Q) classes plus E[p], let g=|rho_(E,p)(G_Q)|, and set k_p=(1/2)log_p([F_(Sel,p):Q]/g). Item506 proves k_p=dim_Fp Sel_p. Since the residual representation has no invariants E(Q)[p]=0, the finite Kummer sequence gives k_p=r+dim_Fp Sha[p]. Cofinite type writes Sha[p^infty]=(Qp/Zp)^t_p plus finite reduced part; Cassels–Tate alternation makes the reduced p-torsion dimension even. Therefore k_p=r+t_p mod2. Dokchitser–Dokchitser proved the p-parity theorem for all elliptic curves E/Q and all p (Annals Math 172 (2010), Theorem 1.4, https://annals.math.princeton.edu/2010/172-1/p11), so

 ord_(s=1)L(E,s) = k_p mod2.

Combining with item508's prime-log derivative residue gives the ACTUAL conditional-on-image analytic congruence

 Res_(s=1) P_E'(s)+1/2 = (1/2)log_p([F_(Sel,p):Q]/g) mod2.

This is the parity component of the sought weighted prime comparison and is unconditional once the Galois image hypotheses hold. It is not a new proof of p-parity or BSD: the order of vanishing beyond parity remains unconstrained. For the rank-three E7 with analytic order3 the Selmer-field exponent must be odd. For the rank>=4 control, the 5-Selmer field has not been computed; do not infer exact analytic order.

## 514. Quadratic-twist obstruction to weighted Chebotarev: exact nonzero coefficient

Fix a maximal mod-p Kummer field for r selected independent points, and let Phi(g) be the conjugacy-invariant indicator that all r points are p-divisible at the prime represented by g. Expand Phi in irreducible complex characters of the Kummer group. Its trivial coefficient is delta_(p,1)(r). Consider the quadratic character epsilon(g)=Legendre(det(A(g)),p), which is pulled back from GL2(Fp). Conditional translation averaging reduces its Fourier coefficient to

 c_epsilon=(1/g) sum_(A in GL2(Fp)) Legendre(det A,p) p^(-r dim ker(A-I)).

The signed counts for dim ker=0,1,2 are exactly p,-(p+1),1. Proof: the identity contributes1 to dimension2; the nontrivial unipotent conjugacy class contributes p^2-1, while distinct eigenvalues 1,lambda!=1 contribute p(p+1) per lambda; sum Legendre(lambda) over lambda!=1 equals -1, so the dimension1 signed total is (p^2-1)-p(p+1)=-(p+1). Total Legendre determinant sum on GL2 is0, giving dimension0 signed sum p. Thus

 c_epsilon(r)=[p-(p+1)p^-r+p^-2r]/[p(p-1)^2(p+1)] >0.

At p5: r3 -> 806/78125, r4 -> 20306/1953125. Exact enumeration in the companion verifier independently confirms the stratum signed counts and these fractions.

Because det rho_(E,p)(Frob_ell)=ell modp, epsilon(Frob_ell)=(ell/p) is the quadratic Dirichlet character of Q(sqrt((-1)^((p-1)/2)p)); p=5 gives Q(sqrt5). Hence the weighted original-curve prime series sum a_ell Phi(Frob_ell)/ell^s necessarily has a NONZERO character component c_epsilon *sum a_ell (ell/p)/ell^s, namely the FIRST-prime-power series for L(E^(D),s) of the actual quadratic twist. The decomposition includes other irreducible Artin representations as well. The higher Artin-twisted terms could in principle interact; we make no unsupported assertion of a standalone residue contribution without controlling them. This proves that simply retaining the trivial character / Chebotarev mean cannot isolate the original central rank. The rank-four control's SELECTED three-point field still has the r3 coefficient even though its canonical full-point field has at least four directions.

## 515. Quantitative obstruction to recovering the complex central rank through ever deeper finite-level Chebotarev

Hasse gives |a_ell|<=2 sqrt(ell). Knowing a_ell modulo p^n determines the INTEGER a_ell uniquely for ALL good ell<=X only if p^n>4 sqrt(X) (a sufficient uniform threshold). The complete rank-r point-division field then has degree

 D_n=|GL2(Z/p^n)|p^(2nr)
    =(1-1/p)(1-1/p^2) p^((4+2r)n)
    > (1-1/p)(1-1/p^2) 4^(4+2r) X^(r+2).

This exact growth law shows why a naive prime-by-prime Chebotarev approach at a modulus large enough to recover full Hecke coefficients from Frobenius residues is grossly under-resolved: the number-field degree grows much faster than the number of rational primes up to X. This is NOT an impossibility theorem for clever character sums, trace formulae or effective bounds exploiting extra structure. It identifies the missing UNIFORM-IN-LEVEL cancellation, beyond fixed-level group statistics.

## 516. Another attempted proof fails: the actual Kummer tower has no uniform elliptic height gap

Take any non-torsion P in E(Q) and division points Q_n with [p^n]Q_n=P. Let F_n=Q(E[p^n],Q_n), which lies in the same full point-division tower whose splitting fields are used above. Canonical heights satisfy

 0 < hhat(Q_n)=p^(-2n) hhat(P) -> 0.

Thus in the actual infinite nonabelian Kummer extension union F_n, non-torsion E-points have arbitrarily small positive canonical height. The field does NOT satisfy a uniform positive elliptic Bogomolov lower bound. Therefore one cannot replace the missing Selmer-to-point bridge by assuming an invariant Northcott/height minimum on this tower. This is an ACTUAL elliptic-point counterexample to that specific height-gap premise, not a nonzero Sha construction and not a BSD counterexample. The verified Silverman uniform height lower bound in the original archive pertains instead to certain fixed-K ABELIAN ring-class composita, not this Kummer tower.

## 517. Mertens/adelic product attempt locates an infinite-prime correlation not supplied by Chebotarev

The original central good Euler factor satisfies L_ell(E,1)=ell/#E(F_ell). Multiplying p-adic norms over all rational primes p recovers this rational number by the product formula, but individual p=ell is not covered by the etale prime-to-ell Kummer calculation and must be treated separately (the anomalous case ell|#E(F_ell) is possible). If the complete local point-division probabilities are available at all primes, their pointwise products thus recover #E(F_ell), but the rank-dependent average of each FIXED-p factor does not control the products when p grows with ell.

The analytic object is the ORIGINAL truncated Euler product product_(ell<=X) #E(F_ell)/ell. Sheth, Euler Product Asymptotics for L-functions of Elliptic Curves (2025), https://academic.oup.com/imrn/article/2025/14/rnaf214/8203235, shows that under the Riemann Hypothesis for L(E,s), its logarithmic exponent along X outside an exceptional set is the ANALYTIC rank a(E). Goldfeld's converse result from the original Birch product asymptotic is stronger than weak BSD. Thus a Kummer-based proof would need an arithmetic estimate giving exponent r(E) for the COMBINED and GROWING family of p-local factors, not just the fixed-p Igusa moments in 512. The character obstruction 514 makes precise the additional twisted-L information encountered already at fixed level. No such uniform estimate is obtained here.

## 518. Rank-two generalized Kato classes do not automatically handle the rank-four control

The published Castella–Hsieh criterion (https://web.math.ucsb.edu/~castella/Kato.pdf), in its stated good-ordinary, sign and auxiliary-character scope, establishes nonvanishing of a certain rank-two generalized Kato class implies dimension_Qp Sel(Q,VpE)=2. For E_(817/56), four independent rational points give dim Sel(Q,VpE)>=4 for every p. Hence whenever the theorem's hypotheses are satisfied, that particular generalized Kato class MUST vanish. This is the logically valid contrapositive; it does not assert every generalized class vanishes, or establish analytic order four. Thus a direct reuse of that rank-two class's nonvanishing criterion cannot supply the missing higher-rank converse for the rank-four control. One needs a genuinely higher-rank class or another analytic input, not simply more auxiliary weight-one forms.

## 519. Exact continuation target and status

The strongest new mathematics in this pass is the ALL-LEVEL local-Kummer/Euler-factor conditional identity (511), the closed infinite-level Igusa density with exhaustive finite checks (512), the proved analytic parity congruence through the canonical Selmer field (513), and the rigorously NONZERO quadratic-twist character contamination of the proposed weighted prime transfer (514). Attempts based on uniformly deeper Chebotarev, uniform Kummer-tower height positivity, and unweighted adelic Mertens reconstruction are blocked by 515–517. The rank-four control 817/56 remains rank AT LEAST four, with original complex analytic rank unproved. Both rank-three E7/E13 certificates and the sign-change counterexample remain retained in earlier entries. The restricted GU auxiliary g is still not the original E and its finite-precision inequality does not imply either rank for E.

Unrestricted rank-BSD remains unsolved. A genuinely sufficient new theorem would need to connect the GLOBAL mixed-motive point-extension classes or height regulator to the complete complex central zero multiplicity without importing the rank-two, ordinary, finite-Sha or generalized Perrin-Riou hypotheses as conclusions. No external submissions, installations, third-party code downloads or purchases were performed.

## 520. The unavoidable quadratic-twist term has a provably NONZERO central prime-log residue

Retain 514's quadratic character epsilon=Legendre(det modp), associated to a primitive quadratic Dirichlet character chi_D with D=(-1)^((p-1)/2)p, and define P_(E,chi)(s)=sum_(ell good, ell!=p) a_ell(E)*chi_D(ell)/ell^s in Re(s)>3/2. Because chi_D(ell)^2=1 away from finitely many primes, the second-prime-power term in log L(E^D,s) is IDENTICAL to that for log L(E,s). The adjoint L(Ad E,1) nonvanishing argument of508 therefore gives

 Res_(s=1) P_(E,chi)'(s) = ord_(s=1)L(E^D,s) - 1/2.

The right side is a nonzero half-integer for EVERY E, since the analytic rank of the quadratic twist is a nonnegative integer. Multiplying by the strictly positive coefficient c_epsilon(r) of514 proves that the quadratic character component of the derivative of the Kummer-divisibility-weighted prime series has a NONZERO residue. At p=5,r=3 it is

 (806/78125)*(ord_(s=1)L(E^5,s)-1/2),

whose absolute value is at least 403/78125. The complete weighted series can involve cancellation from OTHER Artin components, and those components' continuations are not granted here. Thus the theorem rules out the naive proposed proof that all nontrivial character components are individually holomorphic or have zero central residue; proving cancellation of all of them would be a genuinely new and demanding analytic statement. For the rank-four control the coefficient for its full rank-four marked subspace is 20306/1953125, versus 806/78125 for the selected three-point subspace. No rank-four complex analytic order is inferred.

# Independent continuation, 2026-11-21: entries 521–527 (finite-sample integrality and new-point Kummer harmonics)

The full target is still rank E(Q) = ord_(s=1)L(E,s) for EVERY elliptic E/Q. The conductor-389 rank-two computation is already accounted for. The rank-three E7 and E13 analytic/algebraic certificates are preserved; the t=817/56 curve has four independent rational points but its exact total rank and complex analytic order remain uncertified. Preserve the distinction between full-MW and merely chosen-three-point Kummer fields. All statements below are independent deductions or adversarial tests, not a general BSD solution or a novelty claim.

## 521. Integer finite samples recover the first trace moment well below the cyclotomic Vandermonde threshold

Let c_a,c'_a be nonnegative integers on -B<=a<=B, with total masses N each, and assume their residue-class counts are identical modulo every m<=M. Write T=sum a*c_a, T'=sum a*c'_a and L_M=lcm(1,...,M). The equality of marginals modulo m implies T=T' mod m, so

  L_M | (T-T'),  |T-T'|<=2BN.

Hence L_M>2BN IMPLIES T=T', even if D_M=sum_(m<=M)phi(m)<=2B and therefore the full distribution is not recoverable by Vandermonde interpolation. This exploits INTEGER sample multiplicities and a fixed total mass. It does not refute the arbitrary-real-distribution threshold supplied by the coordinator.

The same divisibility is polynomially sharp. Let F_M(z)=product_(d=1..M)Phi_d(z), monic of degree D_M. Equality of all residue marginals is equivalent to the signed difference polynomial being divisible by z^m-1 for every m<=M, hence by F_M(z) in Z[z]. Since Phi_1(z)=z-1 and Phi_d(1)=p for d=p^k, 1 for other d>1,

 F_M'(1)=product_(d=2..M)Phi_d(1)=product_(p^k<=M)p = L_M.

Thus any signed kernel has first-moment difference in L_M Z, and F_M itself attains the first nonzero difference, provided enough nonnegative mass is allowed. For M=4, F_4(z)=z^6+z^5+z^4-z^2-z-1. The two 3-point multisets {4,5,6} and {0,1,2} have identical residue counts modulo every m=1,2,3,4 but their first moments differ by 12=L_4. Shifting supports by -3 places them in [-3,3]. The finite-sample bound does not apply there because L_4=12 < 2BN=18.

For good prime traces a_ell with |a_ell|<=B and N primes up to X, this reconstructs sum_(ell<=X) a_ell exactly from the individual MODULUS marginals once L_M>2BN. At X=10^6 take N=78498,B=2000: 2BN=313992000. The least sufficient M is 23, with L_23=5354228880; D_23=172<4001=2B+1. The companion standard-library verifier replays these integers.

## 522. Integer-weighted residue marginals approximate the original complex prime sums

Let ell range over any finite sample of N good primes, and let |a_ell|<=B. Choose nonnegative integer weights w_ell and W=sum w_ell. Given for all m<=M the WEIGHTED marginals C_(m,j)=sum_(a_ell=j mod m)w_ell, the integer weighted moment T_w=sum w_ell*a_ell is determined modulo every m and hence modulo L_M. If L_M>2BW then T_w is uniquely determined (|T_w|<=BW).

For the original Hasse-Weil weighted sum H_E(X)=sum_(ell<=X, good) a_ell/ell, put Q>0 and w_ell=floor(Q/ell). Then

 |H_E(X)-T_w/Q| < B*N/Q.

Thus choosing Q>BN/eps gives precision eps from exact weighted modular marginals. At X=10^6, B=2000,N=78498, Q=156996000 and W=453259745. The threshold 2BW is 1813038980000; the least sufficient M is 29, with L_29=2329089562800. The approximation error is <=1. Choosing w_ell=floor(Q*log(ell)/ell) gives the analogous approximation to sum a_ell*log(ell)/ell with the same absolute error bound, using exact mathematical floors and suitably certified log intervals in any implementation.

Since log L_M=psi(M)~M by the prime number theorem, B=O(X^(1/2)), N~X/log X, and sum_(ell<=X)1/ell ~loglog X imply an UNWEIGHTED sufficient M=(3/2+o(1))*log X and a WEIGHTED fixed-eps sufficient M=(2+o(1))*log X. The exact minimal M jumps at prime powers but has these scales. These are bounds under integer-sample and exact-marginal hypotheses, not an unstable inversion of arbitrary real distributions.

## 523. The improvement does not yet give an analytic rank: required Chebotarev accuracy is integer-level

At most M=O(log X) is needed for a finite exact trace sum, and the individual torsion fields Q(E[m]) have degree at most |GL2(Z/m)|<=m^4=polylog(X), rather than degree X^(2+rank) for recovering traces individually with a single modulus exceeding 4sqrt X. The same comparison with marked Kummer fields gives degree O(m^(4+2r)) in the full-image case for a fixed rank-r subspace. This is a real reduction in the per-field degree.

But CHEBOTAREV'S DENSITY THEOREM does not supply the exact marginal counts, only asymptotics; even effective GRH error bounds have square-root-of-X absolute errors, much larger than 1 or the logarithmic moduli, and do not determine the integer residues needed by CRT. Weighted counts are even more demanding. Thus no full rank from L(E,s) follows. The original prime-log residue identity of entry508 remains the exact analytic target; knowing ALL exact finite trace sums would determine its convergent Dirichlet series and analytic continuation, but that is not a theorem connecting these sums to the MW field-degree exponent.

The input arithmetic rank is still encoded in [F_MW,p^n:Q]=|G_n|p^(2nr), whereas the CRT marginals are projected from its linear torsion quotient and depend on the underlying E, not on which chosen rational-point subspace was marked. Consequently an extra analytic comparison must exploit a genuine extension-sensitive effect.

## 524. Conditional Fourier projection isolates the extension-sensitive Kummer information

Work at p>=3 with full affine Kummer image G_r=V^r semidirect GL2(Fp), V=Fp^2, for r independent Fp-Kummer classes. Write an element (A,t_1,...,t_r), put d(A)=dim_Fp ker(A-I), q_A=p^(-d(A)), and let Phi_r be the indicator that each t_i lies in (A-I)V (equivalently that the associated r rational points are locally p-divisible). Uniform conditional distribution of translations gives

 E(Phi_r | A)=q_A^r.

Define Xi_r=Phi_r-q_A^r. Then E(Xi_r | A)=0. For every class function f of GL2(Fp),

  E_G[Xi_r*f(A)]=0.

In particular Xi_r is orthogonal to the trivial, determinant-quadratic, and EVERY other Artin character inflated from the torsion-field quotient. It is a genuine class function of the full affine group: conjugation translates t by (A-I)v and conjugates A. Its exact Fourier expansion on V^r is

 Xi_r(A,t)=q_A^r * sum_{(lambda_i) in ker(A^t-I)^r, not all0} e_p(sum_i lambda_i dot t_i).

This uses the standard finite-vector-space orthogonality formula for the annihilator of (A-I)V. For d(A)=0 the whole expression vanishes: the extension-sensitive part lives precisely on Frobenius with eigenvalue1. Its exact L2 norm is

 E(Xi_r^2)=E_A[q_A^r(1-q_A^r)]=delta_(p,r)-delta_(p,2r).

Thus removing the torsion-field projection removes entry514's NONZERO quadratic-twist contamination at the level of the finite character expansion. It does NOT imply analytic cancellation of the remaining new Kummer Artin components: a zero unweighted finite-group character average is not a zero of an E-twisted complex L-function.

## 525. Martingale rank increments give a finite Galois test separating the fourth point

Suppose P_1,...,P_r,P_(r+1) are independent modulo p and have the full joint affine Kummer image. Let Phi_i test divisibility of the first i points, Phi_0=1, and define

  M_i=Phi_i-q_A*Phi_(i-1).

The (i-th) Kummer translation coordinate is uniform conditionally on all earlier coordinates and A. Hence

  E(M_i | A,t_1,...,t_(i-1))=0,
  E(M_i^2)=E_A[q_A^i(1-q_A)]=delta_(p,i)-delta_(p,i+1).

Different increments are pairwise orthogonal in L2(G_r). Iterating gives the exact decomposition

  Phi_r=q_A^r + sum_(i=1..r) q_A^(r-i)*M_i.

Each M_i is orthogonal to every Artin character inflated from the field generated by the first i-1 point-division classes. Thus the extra point is seen in an entirely NEW finite-Galois harmonic sector, not by a change in the old torsion-field trace distribution.

For p=5, delta_(5,3)=59556/78125 and delta_(5,4)=1485931/1953125, so adding one independent class decreases the full divisibility density by exactly 2969/1953125. The fourth increment has exact variance

  E(M_4^2)=delta_(5,4)-delta_(5,5)=14844/48828125 >0.

Conditioned on d(A)=1 AND divisibility of the first three points, a fourth INDEPENDENT point is p-divisible with frequency1/5. If it is rationally dependent on those three modulo p, it is automatically divisible whenever they are. This distinguishes the t=817/56 independent fourth point from the t=7 fibre's fourth-section dependence, while retaining the exact identical abstract statistics of their SELECTED first-three-point fields.

All statements hold for a finite Fp-subspace of H1(Q,E[p]), not only rational Kummer classes. A non-point Selmer class independent of the chosen points has the SAME affine increment distribution. Its non-point origin is instead distinguished by comparing the canonical full MW and full Selmer fields as in501. Therefore this harmonic detection alone cannot turn a Selmer direction into a rational point.

## 526. Direct attempt to force the original L central order from M_i fails at a specific spectral step

For Re(s)>3/2 consider the absolutely convergent prime sum

  R_i(E,s)=sum_(ell good) a_ell(E)*M_i(Frob_ell)/ell^s.

Since M_i has zero projection to every irreducible character inflated from the previously marked Kummer field, its complex character expansion involves ONLY irreducibles on which the new translation kernel acts nontrivially. Therefore the ORIGINAL untwisted elliptic L(E,s), as well as determinant quadratic twists factoring through the old field, do NOT appear as direct inflated constituents in this linear character expansion. (One must still provide analytic continuation of every nontrivial Artin-twisted E factor before turning this formal expansion into a central pole identity.)

I attempted to obtain a nonzero rank increment in ord_(s=1)L(E,s) from the positivity E(M_i^2)>0. Squaring M_i restores a positive trivial character coefficient, but also many other irreducible constituents. The weighted coefficients a_ell can have either sign, so M_i^2>=0 does not make a_ell*M_i^2 positive. Consequently neither the rank-one first-moment correlation nor the rank-two second-moment inequality follows from these finite harmonic identities. A general theorem about central E-twisted L-functions of the NEW Artin components, or an extension-sensitive global height/reciprocity pairing, is missing.

This is a genuine two-stage failed proof: the raw point indicator has unavoidable torsion-field quadratic twist contamination (entry514), now removed EXACTLY by conditional harmonic projection; the new projection nevertheless kills the original E factor along with those old twists and leaves the hard new Artin-twisted analytic comparison. It does not establish rank BSD even for the rank-four control.

## 527. Research target after these calculations

The finite-sample CRT theorem gives an exact way to recover aggregate Hecke trace moments from modest logarithmic torsion moduli PROVIDED integer-precision Frobenius marginals are available. The affine harmonic construction gives a canonical way to extract each genuinely new Kummer direction without contaminating its finite character expansion by old torsion-field twists. Combining them would require proving a higher-order, EXTENSION-SENSITIVE weighted Frobenius cancellation that converts the new-point harmonic sector into a central Taylor coefficient of L(E,s) itself, rather than a collection of independent E⊗Artin twists. The existing generic cohomology and trace data do not prove such a comparison; it remains the precise new obligation.

No unrestricted BSD proof/counterexample was obtained. The rank-three sign-change counterexample and rank-four chosen/full-field distinction are preserved. No installs, third-party code downloads, publication, external submission, or spending. Exact numerical sanity checks for 521,522,524,525 are in `bsd_crt_martingale_verifier.py`.

---

# Continuation 2026-11-21, entries 528–537: exact family trace, K3 rank, and a universal plane-complement motive

**Full target is unchanged:** prove/disprove rank E(Q)=ord_(s=1)L(E,s) for every E/Q. The user-supplied sharp lower threshold (3/2)log X for reconstruction of arbitrary integer trace samples is retained. It applies to arbitrary samples and is not a theorem about arithmetic correlations of a fixed E. All results below are internal derivations/finite calculations with published standard inputs; novelty and external validation are not asserted. Previous ranks for t=7,13 and four independent points for t=817/56 are retained; no complex analytic rank is asserted for t=817/56. Original rank-two 389.a1, p=13 q=7 local matrix, and restricted GU auxiliary route stay in their previous scopes.

## 528. Exact finite-field average for E_t and genuine arithmetic cancellation

Put F(x)=(x+2)(x+4)(x-6)=x^3-28x-48 and E_t:y^2=t^2+F(x). For p>7 define A_p(t)=-sum_(x in Fp) chi_p(t^2+F(x)), the raw cubic-character trace (equal to the usual a_p when the cubic is nonsingular). For any c in Fp, sum_t chi_p(t^2+c)=p-1 if c=0 and -1 otherwise. Since F has three distinct Fp roots,

  sum_(t in Fp) A_p(t)=-[3(p-1)+(p-3)(-1)]=-2p.

Thus its raw mean is exactly -2 for every p>7, with no modular residue interpolation or Chebotarev approximation. Finitely many singular t for each p contribute only O(1/p) to the normalized average if one uses the usual smooth-fibre definition. Consequently sum_p -mean(A_p)*log(p)/p^s has residue 2 at s=1. This is a rank-sensitive trace identity of the elliptic surface, NOT of any fixed fibre E_t0. Sample checks p=11,13,17,19,23,29,31,37 were performed with exact Legendre sums.

## 529. Independent full geometric rank of the original elliptic surface

Let S/Q be the minimal elliptic surface over P1_t. The substitution a=y-t,b=y+t gives ab=F(x), hence S is birational to A2_(a,x) and therefore rational. The discriminant is -16(27t^4-2592t^2-25600), with four simple finite zeros, hence four I1 fibres. At t=infinity, z=1/t and X=z^2*x,Y=z^3*y give Y^2=X^3-28z^4*X+z^4-48z^6, whose fibre has Kodaira type IV* (seven components, root rank six). A rational elliptic surface has geometric Picard number ten; Shioda–Tate gives rank E(Qbar(t))=10-2-6=2. The original sections (-2,t),(-4,t) are independent by specializing to the rank-three t=7 control, so rank E(Q(t))=2. This matches entry528 without proving BSD for a fixed fibre.

Primary references: Schuett–Shioda elliptic surfaces (Shioda–Tate), Rosen–Silverman 1998 on rank/average trace of rational elliptic surfaces, Wazir Compositio Math 2004 account.

## 530. An exact K3 calculation after quadratic base change (new complete function-field theorem)

Put t=(u+48/u)/2 and v=(u-48/u)/2, so t^2-v^2=48. Then over Q(u) the elliptic curve becomes

  C: y^2=x^3-28x+v^2.

It has sections P=(-2,t), Q=(-4,t), R0=(0,v), and over Q(sqrt7) Rplus=(2sqrt7,v), Rminus=(-2sqrt7,v). The first three are independent by u=8 specialization to t=7. The horizontal line y=v yields R0+Rplus+Rminus=O. Put D=Rplus-Rminus; it is anti-invariant under sqrt7-conjugation. It is non-torsion: at the IV* fibre at u=infinity (characteristic zero) all geometric torsion injects into the order-three component group because its connected additive and formal parts are torsion-free. At u=8 and the good prime 19, sqrt28 reduces to +/-3; Rplus,Rminus reduce to distinct points (3,1),(16,1) on E7(F19), whose order is 25. Their nonzero difference cannot be torsion of order dividing three. Thus P,Q,R0,D are four independent geometric sections.

The minimal elliptic surface over P1_u has two IV* fibres (u=0,infinity) and eight I1 fibres. The degree-two map u->t is unramified over all bad t-fibres because its only branch t^2=48 is smooth: Delta(t^2=48)=-16*(-87808) not zero. Euler number 2*8+8=24, so this is a K3 surface with b2=22, and its trivial lattice has rank 2+12=14. The four sections give an 18-dimensional geometric Neron-Severi subspace.

At p=31 the discriminant polynomial is squarefree mod31, the two branch points remain smooth, and both IV* fibres keep their type, so the elliptic K3 has good reduction. Let q=31^n and S_q=sum_(u in Fq^*) a_q(C_u), with a_q the raw cubic character sum. Direct finite-field arithmetic and an INDEPENDENT count using the multiplicity 1+chi_q(t^2-48) give

  S_31=-124, S_961=-3720.

For each q, let R_q denote the Frobenius trace on the 12-dimensional geometric lattice generated by nonidentity components of the two IV* fibres. The exact fibre-by-fibre count is

  #S(Fq)=q^2+1+(2+R_q)*q - S_q,

so Tr(Frob_q | H^2(Sbar,Q_l)) = (2+R_q)*q-S_q. The trivial lattice contribution is (2+R_q)*q. The four MW section classes have trace (3+chi_7(31)^n)*q=4q because (7/31)=+1. Therefore the remaining four-dimensional orthogonal Galois constituent W has

  tr(Frob_31|W)= -S_31-4*31=0,
  tr(Frob_31^2|W)=-S_961-4*31^2=-124.

Newton identities give e2=(0^2+124)/2=62. Poincare duality makes the characteristic polynomial reciprocal with constant +/-31^4, and the Weil bounds force plus (the minus polynomial X^4+62X^2-31^4 has roots of unequal moduli). Hence

  P_W(X)=X^4+62X^2+31^4.

If an eigenvalue were 31*zeta for a root of unity zeta, division by 31^2*X^2 would give zeta^2+zeta^-2=-2/31, impossible because a rational algebraic integer must be an integer. Thus W has NO geometric algebraic Tate-class eigenvalues even after finite extension. The cycle class map on NS is injective and specialization of NS at good reduction is injective, so rho(S/Qbar)=rho(S/Fbar_31)=18. Shioda–Tate now gives

  rank C(Qbar(u))=18-14=4,
  rank C(Q(sqrt7)(u))=4,
  rank C(Q(u))=3.

The last equality uses the known spanning sections P,Q,R0,D and conjugation D->-D. This is an exact function-field result, not a rank/analytic-order statement for any special E_t0 over Q. The t=817/56 rank-at-least-four control corresponds to u=7/4 or 192/7, and genuinely gains a fibrewise point beyond the generic rank three.

The p31 arithmetic was independently checked by two exact finite-field methods in bsd_surface_and_complement_verifier.py. Explicit numerical checks alone are not a formal proof of smooth reduction, the fibre classification, or the cycle class theorem; those standard geometric inputs are separately stated above.

## 531. Universal plane-complement construction for the ORIGINAL elliptic motive

Let E/Q be ANY elliptic curve, embedded as its smooth projective Weierstrass plane cubic E -> P2_Q, and U=P2_Q\E. For l-adic coefficients and p any prime, the geometric Gysin sequence of the divisor E gives

 H^0(Ebar,Q_p(1)) --degree 3--> H^2(P2bar,Q_p(2)) -> H^2(Ubar,Q_p(2)) -> H^1(Ebar,Q_p(1)) -> H^3(P2bar,Q_p(2))=0.

The degree-three map is an isomorphism over Qp, and the geometric Kummer sequence gives H^1(Ebar,Q_p(1))=V_p E. Therefore

  H^2_et(Ubar,Q_p(2)) ~= V_p E

for EVERY E/Q. For p !=3 this is integral, H^2_et(Ubar,Zp(2)) ~= TpE; at p=3 there is a short exact lattice correction 0->Z/3->H^2_et(Ubar,Z3(2))->T3E->0. (The latter need not split Galois-equivariantly.) Also H^1(Ubar,Qp)=H^3(Ubar,Qp)=0, so for odd p the Hochschild–Serre spectral sequence and cd_p(G_Q)=2 identify

  H^3_et(U,Qp(2)) ~= H^1(Q,VpE).

The isomorphism is the actual ORIGINAL VpE, not an auxiliary g or an Artin semisimplification.

## 532. The full original Mordell–Weil group is a rational higher Chow group

Bloch localization for the closed smooth divisor E and open U gives

 CH^1(E,1) -> CH^2(P2,1) -> CH^2(U,1) -> CH^1(E,0) -> CH^2(P2,0).

The projective-bundle formula gives CH^1(E,1)=Q^*, CH^2(P2,1)=Q^*, CH^2(P2)=Z and CH^1(E)=Pic(E)=E(Q) plus Z (degree). The first map Q^* -> Q^* is the cube map: by projection formula, the divisor class of E equals 3H. The last map is degree. Hence there is an exact sequence

  0 -> Q^*/(Q^*)^3 -> CH^2(U,1) -> E(Q) ->0.

The first group is killed by three, so

  CH^2(U,1) tensor_Q (meaning tensor_Z Q) ~= E(Q) tensor_Z Q,

and, for p !=3, CH^2(U,1) tensor_Z Zp ~= E(Q) tensor_Z Zp (Zp is flat over Z).

For an affine rational point P=(xP,yP), let LP be the vertical line x=xP*z in P2 and fP=(y/z)-yP on LP. The function has divisor P-O on LP, whose zeros and poles lie entirely in E, so (LP intersect U,fP) represents a higher Chow cycle ZP in CH^2(U,1). Localization sends ZP to [P]-[O] in Pic^0(E)=E(Q). This gives explicit symbols for EVERY rational point, rather than mere existence via Chow rational equivalence.

The Hasse–Weil L-function of H^2(Ubar,Qp(2)) is EXACTLY the original L(E,s), with its specified Galois normalization. Thus this one affine surface contains an exact arithmetic rank model and the exact original Galois motive for ALL E/Q. This is a cohomological/motivic reduction, not rank BSD itself.

## 533. Direct arithmetic zeta identity on the plane complement

Choose an integral smooth Weierstrass cubic E over Z[1/N] where N contains all bad primes, and U_Z=P2_(Z[1/N])\E. For p outside N and all n>=1,

  #U(F_(p^n))=#P2(F_(p^n)) - #E(F_(p^n))
              =p^(2n) + alpha_p^n + beta_p^n.

Hence the exact local zeta factor is

 Z(U/Fp,T)=1/[(1-p^2*T)(1-alpha_p*T)(1-beta_p*T)].

Multiplying the good factors and analytically continuing by modularity gives

  zeta(U_Z,s)=zeta^(N)(s-2)*L^(N)(E,s).

Since zeta^(N)(-1) and the omitted bad elliptic local factors evaluated at s=1 are finite and nonzero,

  ord_(s=1) zeta(U_Z,s)=ord_(s=1)L(E,s).

Therefore unrestricted rank BSD is EQUIVALENT to the concrete all-E statement

 ord_(s=1) zeta(P2_(Z[1/N])\E,s)
    =dim_Q(CH^2(P2_Q\E,1) tensor_Z Q).

This is a **restatement of the missing rank equality**, not its proof. Existing Weil-etale special-value conjectures for arithmetic schemes, e.g. Flach–Morin and the Lichtenbaum–Ramachandran/Flach–Siebel equivalents, do not unconditionally prove this identity for the present non-Tate motive.

## 534. Regulator is the actual Kummer map; exact remaining Selmer obstruction

The étale cycle regulator r_p:CH^2(U,1)->H^3_et(U,Zp(2)) is compatible with the Bloch localization boundary and Gysin. For p>=5 the geometric Tate module and Hochschild–Serre identifications above send r_p(ZP) to the classical global Kummer class delta_p(P) in H^1(Q,TpE), up to the orientation sign. The degree-zero Chern class of P-O on E projects to precisely this cocycle.

Thus the regulator image after Qp coefficients is E(Q) tensor Qp inside H^1(Q,VpE). Applying its finite Bloch–Kato local conditions recovers the usual exact sequence

  0 -> CH^2(U,1) tensor_Z Qp -> H^1_f(Q,VpE) -> Vp Sha(E/Q) ->0.

Here the first map uses the explicit regulator/Kummer identification, and Vp Sha means the rational Tate module of Sha[p^infty], not its finite p-power torsion. This precisely identifies the failure of motivic-regulator essential surjectivity with the divisible Sha obstruction. The previously recorded full MW and full Selmer division-field degrees are another finite-level measure of this same discrepancy. No surjectivity of the regulator onto H_f^1 has been proved.

## 535. Two attempted proofs fail; a higher derived pairing is still missing

A. Plain Tate/Weil trace. The zeta identity and proven CH^2(U,1) rank do not imply their orders agree; that would be a Beilinson/Bloch–Kato–type special-value theorem, exactly the missing BSD comparison. All individual good Euler factors are nonzero at s=1, while for E7 their infinite global product has a zero of certified order three. Summing local zero orders is demonstrably invalid. The Tate conjecture for DIVISORS on a surface does not count the higher motivic CH^2(U,1) classes at the elliptic central critical value.

B. Plain cup pairing. The Kummer classes of rational points are local Tate-isotropic: delta(P)_v cup_Weil delta(Q)_v=0 in H^2(Q_v,Qp(1)) for every place v. The global class is zero by Brauer localization injectivity. Hence their ordinary global étale cup matrix is identically zero even on E7's three independent classes and E_(817/56)'s four classes. Its determinant cannot equal a nonzero Neron–Tate regulator. A Bockstein/derived height, with independently proved nondegeneracy AND comparison to the COMPLEX Taylor order, is required. Existing abstract Selmer/Iwasawa countermodels in the archive show that self-duality plus a characteristic ideal does not supply those inputs automatically.

C. Weights. The pure K3 H^2 has weight2 and cannot directly contain the fibre's elliptic H^1 of weight1 as a pure algebraic correspondence (integer Tate twists shift weight by even numbers). Removing the fibre produces a MIXED/OPEN surface and restores VpE via the exact Gysin quotient. That repairs the representation-theoretic mismatch, but not the global special-value/regulator theorem.

**Current best next proof target:** prove an independent, all-E equality between the central zeta zero order of U_Z=P2_(Z[1/N])\E and the rank of its rational motivic CH^2(U_Q,1). The cycles ZP and the exact H^2(U)(2)=VpE identification show both sides are the correct original E. The relevant arithmetic Selmer deficiency and derived-height obstruction remain explicit. Avoid claiming the proposed all-E special-value assertion from localization, finite-field Tate, density, standard cup products or Weil-etale conjectures: each fails precisely at the unproved arithmetic–analytic bridge. No complete BSD proof or counterexample was produced.

Useful sources checked this continuation: Bloch higher-Chow localization/projective bundle (Friedlander lectures and Bloch 1994), Kummer/Gysin via Milne and general etale theory, Shioda–Tate (Schuett–Shioda), Rosen–Silverman/Nagao (1998), Flach–Morin Weil-etale conjecture (Documenta 2018), Flach–Siebel and Lichtenbaum–Ramachandran arithmetic-surface equivalences (2021/2023). Standalone finite computation: bsd_surface_and_complement_verifier.py; no installs, downloads, spending, submissions, or outreach.

# Independent BSD continuation, 2026-11-21: entries 538–546 (four-section normal function, second K3, function-field analytic bridge, and specialization obstructions)

**Permanent target:** prove or refute rank E(Q)=ord_(s=1)L(E,s) for every elliptic E/Q. This work does not assert a solution. The user's new theorem is retained as an input: for each X, infinitely many distinct rational fibres of the four-section base C have rank >=4 and the identical good local Euler factors at EVERY prime <=X as E_7, despite E_7 having rank exactly3 and analytic rank exactly3. This includes the cited local precision at 2,41,2141 and allows unbounded conductors. The arbitrary finite-trace-sample CRT lower bound (3/2-o(1))log X is also retained, not rederived. Keep first-three marked Kummer fields distinct from the full-Mordell–Weil division field.

## 538. First-order normal-function expansion of the missing fourth-section relation (new exact deduction)

Set C: v²=t²-48, w²=t²-33; choose the branch parameter u=t-v so t=(u+48/u)/2, v=(48/u-u)/2, with w(8)=4. Consider E_t:y²=x³-28x+t²-48 and P=(-2,t), Q=(-4,t), R=(0,v), S=(-5,w). Put D=P+Q+R+S. At u=8 the fibre has t=7,v=-1,w=4 and D=O.

The group law gives P+Q=(6,-t) and B=P+Q+R=(64/u²-6,t-96/u+512/u³). The slope adding S is lambda=(w-y_B)/(1-64/u²). The numerator at u=8 is8, while the denominator has derivative1/4; hence lambda=32/(u-8)+O(1). With z=-x/y at O, z(D)=lambda^{-1}+O(lambda^{-2})=(u-8)/32+O((u-8)²). Since dt/du|_8=1/8, also z(D)=(t-7)/4+O((t-7)²).

For every odd p, these expansions are integral around the chosen smooth branch (their displayed leading coefficients are p-units), so v_p(z(D_c))=v_p(u(c)-8)=v_p(t(c)-7) whenever this is positive. Therefore u(c) congruent8 modulo p^(k+1) implies D_c lies in p^k E_c(Q_p) by the formal logarithm (p>=3). This is an exact local divisibility mechanism for a globally independent fourth point. It is NOT a global Kummer divisibility theorem.

## 539. Function-field BSD inequality gives a genuine analytic rank-four signal for almost every finite-characteristic reduction

Four-section independence over Q(C) follows by specializing at t=817/56, where four points are proven independent. The nonisotrivial elliptic surface over C has a nondegenerate function-field height Gram matrix on these four sections. After a smooth proper spread and removal of finitely many residue primes, intersection classes and their nonzero determinant specialize to the reduced elliptic surface; the rank of its Mordell–Weil subgroup over F_p(C_p) is at least4. The Artin–Tate–Milne inequality for elliptic curves over global function fields of finite characteristic, rank <= ord_(s=1)L(E/F_p(C_p),s), then yields ord_(s=1)L(mathscr E/F_p(C_p),s)>=4 for all but finitely many p. This applies to the RELATIVE finite-characteristic function field, not to the individual E_t/Q. Source with theorem: https://infoscience.epfl.ch/record/307330/files/EPFL_TH10417.pdf Theorem1.3.35(2); Ulmer's notes https://math.arizona.edu/~ulmer/research/papers/2002.pdf §10. The special value comparison is a theorem for the function-field family only; no specialization of its L-order to rational fibres is asserted.

## 540. SECOND K3 base-change rank exactly three over Q(s), four geometrically (new separate all-fibre calculation)

Base change by w²=t²-33, with t=(s+33/s)/2 and w=(s-33/s)/2. The resulting elliptic surface K_33 over P¹_s has two IV* fibres at s=0,infinity and eight I1 fibres (the double cover is branched over smooth original fibres); it is a K3, with b2=22 and trivial-fibre Neron–Severi rank2+2*6=14. Four geometric sections arise from P,Q and the horizontal line y=w with x=-5 and x=(5±sqrt37)/2. Write R_w=(-5,w) and D_w=R_+-R_-. Their constant-field Galois signs separate the fourth direction.

D_w is nontorsion: at t=7,w=4 it is the difference of the two points ((5±sqrt37)/2,4) in E_7(Q(sqrt37)). At rational primes11 and47, both split in Q(sqrt37), both are good for E_7, and #E_7(F_11)=11 and #E_7(F_47)=52. Prime-to-residue-characteristic torsion injectivity at both primes excludes every prime divisor of E_7(Q(sqrt37))_tors; hence the nonzero difference is nontorsion. P,Q are invariant under w-conjugation, R_w and D_w are anti, while D_w is anti under sqrt37-conjugation. Therefore the four directions are independent over Qbar(s), at least rank4.

At p=41 the K3 has good reduction. Define S_q=sum_(s in Fq^times) a_q(E_((s+33/s)/2)), with the raw cubic character-sum trace at singular fibres. Independent exact finite-field algorithms (s parametrization and multiplicity 1+chi_q(t²-33)) give S_41=-184 and S_1681=-5320. The four known MW directions are all defined over F41 because (37/41)=+1. The trace formula #K3(Fq)=q²+1+(2+R_q)q-S_q, with R_q the trace on the 12 nonidentity IV* components, subtracts the trivial 14-dim lattice. The remaining 4-dimensional H² constituent W has trace t1=184-4*41=20, t2=5320-4*41²=-1404, hence e2=(t1²-t2)/2=902. Poincare duality gives eigenvalue pairing lambda <-> 41²/lambda. If determinant were -41^4, an anti-reciprocal quartic would have e2=0, contrary to902, so the determinant is +41^4. Its characteristic polynomial is

  X^4 -20 X^3 +902 X² -33620 X +41^4.

If lambda=41*zeta were an eigenvalue for a root of unity zeta, h=zeta+zeta^-1 would be an algebraic integer satisfying 1681h²-820h-2460=0. The two roots either form a quadratic pair with nonintegral trace20/41, or are rational integers in [-2,2]; direct substitution shows no integer is a root. Thus W contains no root-of-unity Tate eigenvalues and no further algebraic divisor class even after finite residue-field extension. The Picard rank of the geometric reduction is exactly18; NS specialization injectivity gives Picard rank18 in characteristic zero. Shioda–Tate gives rank K_33(Qbar(s))=18-14=4. Constant Galois conjugation kills the D_w sign and fixes the other3, so rank K_33(Q(s))=3. The exact arithmetic is in bsd_second_quadratic_K3_verifier.py; the fibre classifications and Picard theorems are mathematical inputs, not claimed to be proved by software.

## 541. Exact biquadratic rank decomposition isolates one remaining double-twist direction

Let F=Q(t), d1=t²-48, d2=t²-33, K=F(sqrt d1,sqrt d2)=Q(C). K/F is biquadratic. The four rational Galois sign projectors e_chi=(1/4)(1±sigma)(1±tau) on E(K) tensor Q identify its isotypic factors with the corresponding quadratic twists over F. Consequently

 rank E(K)=rank E(F)+rank E^(d1)(F)+rank E^(d2)(F)+rank E^(d1 d2)(F).

Original rational elliptic surface gives rank E(F)=2. First quadratic K3 (previous entry530) gives rank E^(d1)(F)=1. The new second K3 theorem540 gives rank E^(d2)(F)=1. Hence EXACTLY

  rank E(Q(C))=4+rank E^((t²-48)(t²-33))(Q(t)).

The double-twist term is not calculated; it must NOT be called zero without proof. No constant-x section can represent its anti-both sign: a point over K with x=c constant and y=sqrt(d1d2)*h(t) would require h(t)^2=(t²+c³-28c-48)/[(t²-48)(t²-33)]. Because the two denominator quadratics have distinct simple root sets, the numerator can cancel at most one and leaves an odd-order pole, so the rational function cannot be a square. This is a scoped no-constant-x test, not a proof of zero double-twist rank.

At t=7 and817/56 both d1,d2 specialize to rational squares: the biquadratic Galois-character splitting itself collapses and cannot be specialized as four independent character idempotents of a nontrivial extension. This is precisely why the function-field rank decomposition does not give a complex-L rank comparison for E_t/Q. At t=7 the four particular sections satisfy one relation; at t=817/56 they are independent, consistently with specialization.

## 542. Exact harmonic obstruction to isolating an original Q-fibre from the relative analytic signal

Let T=(256,3520) in C(Q) with t(T)=7, and S0=2T with t(S0)=817/56. At p19, C has good reduction and #C(F19)=16; ord(T mod19)=8. The affine fibres of C -> P1_t above F19 have t=0,7,12 with four points each; four points at infinity contribute no affine trace. The raw E_t traces are a_19(E_0)=-4 and a_19(E_7)=a_19(E_12)=-5. Therefore the sum of a_19(E_(t(c))) over affine c in C(F19) is -56 and its average over the full group (assigning zero trace to four points at infinity) is -56/16=-7/2. But the original E_7 has a_19=-5, and E_(817/56) has a_19=-4.

For any finite group C(Fp), Fourier orthogonality gives exactly

  a_p(E_(t(c0))) = (1/|C(Fp)|) sum_(chi in dual(C(Fp))) sum_(c in C(Fp)) a_p(E_(t(c)))*chi(c-c0),

with an explicit zero convention at bad/infinite fibres. At p19 its trivial-character part is -7/2, and nontrivial parts sum to -3/2 for c0=T and -1/2 for c0=S0. The relative four-section rank signal lives in GLOBAL family cohomology/prime averages, not in the trivial Fourier component of the stalk at one rational point. Recovering original L(E_T,s) requires controlling ALL nontrivial character contributions as p varies; neither the four geometric sections nor Chebotarev proves their cancellation. This is a concrete, exact obstruction to the attempted relative-to-fibre analytic transfer.

A sheaf-theoretic localization identity does exist: for the lisse relative H1 local system F=R1 pi_* Ql on the smooth parameter locus C°, and a rational section i_c0:Spec Z[1/N]->C°, the Euler products factor over the closed arithmetic section and its complement, so L(C°,F,s)=L(C°\i_c0,F,s)*L(E_(t(c0)),s), up to finite bad factors. But this is only a factorization of Euler products in their common convergence region; analytic continuation/central zero orders for the HIGHER-DIMENSIONAL total and punctured family L-functions are not supplied by modularity of individual fibres. Their hypothetical special-value comparison would reinsert the missing general motivic BSD theorem. Do not claim this is a proof.

## 543. An adelic recurrence makes fourth-point local smallness coexist with divergent global height

T lies in the real identity component of C(R) and has infinite order. For a finite set S of odd primes and any prescribed precision k, choose a positive integer M killing the image of T in every finite quotient of C(Q_p) modulo p^(k+1), p in S. The infinite-order rotation MT on the compact real identity circle is dense, so infinitely many integers n=1+jM have nT tending to T in C(R) while nT is congruent to T in every specified local quotient. By Silverman specialization, for all but finitely many such n the four sections remain independent over E_(t(nT))(Q).

For D=P+Q+R+S, entry538 makes D_(nT) arbitrarily small in the local formal groups and real elliptic group, and locally divisible by p^k for p in S. Nevertheless, D is a nontorsion function-field section and has positive canonical geometric height. Silverman's height specialization theorem gives hhat_(E_t(nT))(D_nT) / h_C(nT) -> hhat_(E/Q(C))(D)>0 along height-unbounded nT; h_C(nT) asymptotic to n²*hhat_C(T) after a fixed ample degree-one normalization, so the GLOBAL heights of these points diverge to infinity as n->infinity. Thus even simultaneous real/finite-p local disappearance does not yield small global canonical height or a uniform Kummer/Selmer triviality. This is an actual arithmetic family, not an abstract countermodel.

## 544. The first infinitesimal normal-function jet is not a finite Kummer/Selmer class

Over Q[eta]/eta² at u=8+eta, z(D)=eta/32. The infinitesimal formal group is the additive Q-vector space eta*Q. Multiplication by any integer n!=0 is bijective on this tangent group. Consequently the ordinary finite Kummer boundary of the first-order infinitesimal class vanishes for every n, despite the nonzero de Rham tangent eta/32. This blocks the proposed shortcut 'nonzero first geometric derivative implies a new extension-sensitive finite Galois class or complex-L derivative'. The arithmetic information lives in integral specializations and global points, not in the uniquely divisible characteristic-zero tangent alone.

## 545. Exact original-L tail residue and the remaining missing inequality

Define P_E(s)=sum_(ell good) a_ell(E)ell^(-s) in Re(s)>3/2. The earlier published-adjoint-L based identity in entry508 gives Res_(s=1)P_E'(s)=a(E)-1/2. Therefore for any E1,E2 and any fixed X removing the primes ell<=X,

  Res_(s=1) d/ds sum_(ell>X)(a_ell(E2)-a_ell(E1))ell^(-s) = a(E2)-a(E1).

For E1=E_7 with known rank=analytic order3 and any 4-independent specialization E2 on C having exactly the same first-X Euler factors, the desired full BSD implication would require the right side >=1, and equality if its total rank were exactly4. No proof of that SIGN or magnitude from the four sections, the normal-function jet, relative finite-field analytic ranks, or the finite character sums has been obtained. This is a precise original-L weighted-prime target; the entire relevant information is in the uncontrolled high-prime tail, whose conductor grows across the selected family. No assumption of a uniform finite-Euler rank detector is made.

## 546. Exact status and next direct target

The strongest new positive theorem is the SECOND K3 geometric and rational function-field rank calculation540 and the exact biquadratic decomposition541; 538 supplies a nonvanishing first geometric normal-function derivative, 539 an unconditional relative function-field analytic rank-four bound, 542 an explicit obstruction to projecting that bound onto the original Q-fibre at p19, and543–544 show why finite local and infinitesimal geometric data still do not give the arithmetic regulator or the complex central order. The user-supplied stronger prime-by-prime matching remains intact. The next original-E task is to derive a global arithmetic–analytic comparison controlling the weighted tail residue in545, not to assign rank4 or analytic4 to E_(817/56) by guesswork. The general BSD rank equality remains OPEN; no counterexample to BSD is asserted. No installs, third-party downloads, spending, publication or outreach.

## 547. Exact completion of BSD in rank four for the K3 second base change over F41(s)

The newly proved K3 second-base ranks in540 give, at p41, four F41-rational independent sections and geometric Picard number18. The published Tate conjecture for K3 surfaces over finite fields of characteristic at least5 (Charles 2016; Madapusi Pera) implies the Tate conjecture for this explicit K3. The Artin–Tate–Milne equivalence for elliptic surfaces over finite fields therefore gives the equality

  rank K_33(F41(s)) = ord_(s=1)L(K_33/F41(s),s) = 4.

The relevant L is the FUNCTION-FIELD L of the original 2-to-1 base-changed elliptic family, not L(E_t/Q,s). For a fixed rational fibre E_t/Q no analytic rank conclusion follows from this identity. The original rank-3 E_7 and rank-at-least-4 E_(817/56) remain as before. Sources: https://annals.math.princeton.edu/2016/184-2/p04 ; https://arxiv.org/abs/1301.6326 and standard Artin–Tate–Milne elliptic-surface BSD equivalence.

An instructive adversarial reduction-prime check: at p31, the same second-K3 weighted point counts yield S_31=-52, S_961=-3944 and residual W traces t1=-10,t2=100,e2=0. An exact additive convolution of H(x³-28x-48) with the quadratic character on GF(31³), calculated by an original modular NTT with prime93001>2*31³, gives S_29791=-87412 and residual t3=27830. These determine determinant -31^4 and polynomial (X²-31²)(X²+10X+31²). Hence the reduction at31 has two EXTRA Frobenius Tate eigenvalues ±31 and cannot certify characteristic-zero Picard=18, whereas p41 does. The p31 result is exact finite arithmetic and is reproduced by bsd_K3_second_base_NTT.py, with preinstalled NumPy only and no downloaded code. This is a genuine adversarial test of naïvely choosing one good prime for a Picard upper bound; it is not a counterexample to BSD.

## 548. Nonexistence of a continuous real interpolation of the local Euler factors (rigorous new obstruction)

Let T=(256,3520) on C:y²=(x-36)(x-96)(x+96). It lies in the real identity component and is nontorsion. At p19, C has good reduction, #C(F19)=16 and the reduction of T has exact order8. The two residues T,2T have t-values 7 and817/56, with mod19 traces a_19(E_7)=-5, a_19(E_(817/56))=-4 (even though both curves are nonsingular mod19). The subgroup generated by 8T is dense in the real identity circle. Thus both subsequences (1+8m)T and (2+8m)T admit infinite real subsequences converging to T, while their mod19 reductions remain respectively T and2T. Therefore the function c -> a_19(E_(t(c))) on the rational points of C has two different limits (-5 and-4) at the SAME real point T. It admits no continuous, much less holomorphic, extension to a real neighborhood of T. In particular, the analytic Gauss–Manin/period variation in c does not extend the arithmetic Euler coefficient functions, and differentiating a putative holomorphic family of L(E_t,s) in the complex parameter is unjustified. This is unconditional, not contingent on rank BSD.

## 549. Precise next full-target attempt

The exact original-curve prime-residue identity from545 says any proof that a(E_(t(c)))>=4 for every four-independent specialization c must show a nonnegative/positive central residue of the tail after matching E_7 at finitely many primes. The relative K3/finite-function-field Tate proof gives analytic rank4 in a DIFFERENT function field and cannot be transferred through the arithmetic parameter; local Euler coefficients do not even vary continuously in c in real topology (548). The de Rham first jet of the vanishing fourth-section relation is nonzero but uniquely divisible, hence invisible to finite Kummer cohomology (544), and the global canonical height can grow while the jet tends to zero at finitely many places (543). What is still needed is a true arithmetic–analytic regulator or high-rank reciprocity theorem for the ORIGINAL Q-elliptic H1 motive, relating its full global point lattice to the COMPLEX central Taylor order. Neither the present exact K3 theorem, Tate for K3s, finite prime matching, or point-family normal function supplies this implication.

## 550. Rankin–Selberg detects large-prime separation of the two ORIGINAL modular forms, despite arbitrary finite Euler matching

Fix E_1=E_7:y²=x³−28x+1 and E_2=E_(817/56):y²=x³−28x+516961/3136, with three and at least four independent rational points respectively. At their common good primes let λ_i(ℓ)=a_ℓ(E_i)/sqrt(ℓ) and d_ℓ=λ_2(ℓ)−λ_1(ℓ). Hasse gives |d_ℓ|≤4.

The discriminant of the displayed rational E_2 model is Δ_2=−6352166814299/(2^8*7^4), while c4=1344. The numerator q=6352166814299 is prime (e.g. an exact n−1/Pocklington certificate or a deterministic 64-bit primality test). Thus E_2 has I_1 multiplicative reduction at q. E_1 has Δ_1=2^4*41*2141 and good reduction at q. Consequently their rational Tate representations and modular forms are neither isogenous nor Dirichlet-character twists of one another: twisting an unramified local representation by a one-dimensional character cannot create nonzero unipotent monodromy, as E_2 has at q. Both E_i are non-CM because their rational j-invariants are not integers; in fact v_q(j(E_2))=−1 and E_1 has v_41(j(E_1))=−1.

For fixed forms, the unconditional Rankin–Selberg prime-number theorem gives as Y→∞

   Σ_(ℓ≤Y) λ_i(ℓ) log ℓ = o(Y),
   Σ_(ℓ≤Y) λ_i(ℓ)^2 log ℓ = Y+o(Y),
   Σ_(ℓ≤Y) λ_1(ℓ) λ_2(ℓ) log ℓ = o(Y).

The first uses GL2 PNT, the self-convolution has simple pole at unitary s=1, and the mixed convolution has no pole. Thus

   Σ_(ℓ≤Y) d_ℓ logℓ = o(Y),
   Σ_(ℓ≤Y) d_ℓ² logℓ = 2Y+o(Y).

Since x²≤4|x| on [−4,4], Σ |d_ℓ|logℓ≥Y/2+o(Y). Vanishing first moment gives Σ max(±d_ℓ,0)logℓ≥Y/4+o(Y). Each positive part ≤4, hence

   liminf_Y #{ℓ≤Y:a_ℓ(E_2)>a_ℓ(E_1)}/π(Y) ≥1/16,
   liminf_Y #{ℓ≤Y:a_ℓ(E_2)<a_ℓ(E_1)}/π(Y) ≥1/16.

This proves a positive-density two-sided trace discrepancy for the ORIGINAL elliptic newforms, even if their first-X Euler factors agree (which the user's theorem produces for infinitely many other E_2 after fixing X). No BSD rank equality is presumed. For a varying E_2=E_2(X), the o(Y) thresholds and implied constants depend on the chosen curve/conductor; there is NO uniform conclusion at Y comparable to X.

Sources for the known automorphic prime-number theorems: Jianya Liu and Yangbo Ye, 'The Prime Number Theorem for Rankin-Selberg L-Functions', https://www.kurims.kyoto-u.ac.jp/~kyodo/kokyuroku/contents/pdf/1511-6.pdf; Liu–Ye, Selberg orthogonality corollaries, https://citeseerx.ist.psu.edu/document?doi=459ce5f3d7b23cc0d1eb907b3706fb683fdd7d4d&repid=rep1&type=pdf. These are classical/known theorems; the two-sided 1/16 bound is an elementary application, not a novelty assertion.

## 551. Disagreement occurs in BOTH directions in EVERY fixed arithmetic progression

The preceding conclusion strengthens as follows for this particular pair. Let M≥1 be any fixed integer and a be any residue coprime to M. Both E_i are non-CM and their associated automorphic GL2 representations π_i have no nontrivial Dirichlet self-twist. Moreover π_2 is not π_1⊗χ for ANY Dirichlet character χ, by the mismatched nonzero monodromy at q of550.

For every Dirichlet character χ modulo M, the Rankin–Selberg twists L(s,π_i×π_i^∨⊗χ) have a pole at s=1 precisely if χ=1, while the cross twists L(s,π_1×π_2^∨⊗χ) have none. The GL2 twists L(s,π_i⊗χ) are entire at unitary s=1. The established PNT, followed by Dirichlet orthogonality, therefore yields (all sums over common-good ℓ≡a mod M)

  Σ_(ℓ≤Y) d_ℓ logℓ = o(Y),
  Σ_(ℓ≤Y) d_ℓ² logℓ = (2/φ(M))Y+o(Y),
  Σ_(ℓ≤Y) logℓ = (1/φ(M))Y+o(Y).

As in550 the sign-balanced first moment and second moment imply each of the two sets {ℓ≡a(M):a_ℓ(E_2)>a_ℓ(E_1)} and {ℓ≡a(M):a_ℓ(E_2)<a_ℓ(E_1)} has lower natural density at least 1/(16 φ(M)) among all rational primes, equivalently lower relative density at least1/16 among primes in the progression. The proof requires M fixed before Y→∞, so does not permit M growing with conductor or with the matching cutoff X. This remains a theorem on the original coefficients, not a central-L rank inequality. The PNT follows by twisting the usual Rankin–Selberg convolutions with the finite Dirichlet characters.

## 552. A second arithmetic–analytic proof attempt fails at the SIGNED central residue

For E_1,E_2 define in Re(s)>3/2 the first-prime difference D(s)=Σ_(ℓ good) (a_ℓ(E_2)−a_ℓ(E_1))ℓ^(−s). The analytic continuation of the differentiated prime series from entry545 satisfies exactly

  Res_(s=1)D'(s)=ord_(s=1)L(E_2,s)−ord_(s=1)L(E_1,s)
                    =ord_(s=1)L(E_2,s)−3.

Finite small-prime matching only alters D by a finite Dirichlet polynomial, which has no residue at s=1. The Rankin–Selberg theorem550–551 gives an unconditional and strong two-sided high-prime discrepancy (including in every fixed arithmetic progression), but it controls ∑ d_ℓ²logℓ and ∑ d_ℓ logℓ where d_ℓ=(a_2−a_1)/sqrtℓ. Neither controls the *signed*, analytically continued series D'(s) near s=1. In fact its absolutely convergent prime Dirichlet expansion is restricted to Re(s)>3/2; continuation into the center requires the full automorphic functional equation, and no positivity for its residue follows from the positive Rankin–Selberg second moment. The mixed Rankin–Selberg L-function has no pole at unitary s=1 since the forms are distinct, irrespective of whether the MW ranks are 3 and >=4: that convolution detects equality of semisimple automorphic representations, not the point extension classes.

For E_2=E_(817/56), BSD would require Res D' >=1, and more precisely Res D'=rank E_2(Q)−3. No such sign inequality has been proved by550–551 or by the K3 base-change/Tate, normal-function or finite local methods. It remains possible, logically from present bounds, that the central order of E_2 is 2, 4, 6,... when its root number is even; deciding the actual order is separate and has not been claimed. This is an explicit failed second approach in the same run, not a BSD counterexample or a completion claim.

## 553. A Sturm-bound conductor lower bound forced by the user's arbitrarily long Euler-factor matching

Let N_1=N(E_7) be fixed and N_2=N(E_2) for any member of the user's four-independent specialization family. Assume the Euler factors match at ALL primes ℓ≤X (including the specified bad local factors). Then the normalized weight-two elliptic newforms f_1,f_2 satisfy a_n(f_1)=a_n(f_2) for every positive integer n≤X by Euler-product multiplicativity. They are distinct because a Q-isogeny to E_7 would preserve rank and because the user has proved the second curve's rank≥4 while rank E_7=3; alternatively different j/known conductor at individual controls suffice.

Both forms belong to S_2(Γ_0(L)), L=lcm(N_1,N_2), via the standard inclusions when N_i|L. Sturm's theorem says the first B=floor([SL2(Z):Γ_0(L)]/6) coefficients determine any weight-two form at this level. Since f_1!=f_2 but coefficients through X agree, necessarily B>X. The index formula gives the unconditional quantitative constraint

   floor((L/6)*prod_(ℓ|L)(1+1/ℓ)) > X,
   equivalently L*prod_(ℓ|L)(1+1/ℓ) >= 6(X+1).

Since N_1 is fixed, L≤N_1 N_2 and the Euler factor product is O(loglog(3L)), this implies N_2 ≫_(N_1) X/loglog(3X) as X→∞. For the fixed second control E_(817/56), N_2 is fixed, so there is a finite cutoff after which equality of all initial factors is impossible; the user's infinitely many matching specializations MUST have growing conductor, as explicitly allowed. The bound is far weaker than their CRT construction's possible growth, but it is an exact original-modular-form obstruction to fixed-conductor uniformity.

Source: LMFDB reviewed Sturm bound https://www.lmfdb.org/knowledge/show/cmf.sturm_bound ; also original theorem/further improvements https://doi.org/10.1016/j.jnt.2020.07.003. This uses no BSD rank comparison and cannot supply the missing central order; Sturm controls identity of modular forms, not multiplicity of their central zeros.

## 554. Full BSD target remains after TWO rigorously tested original-L approaches

The Rankin–Selberg approach550–552 controls the first and second prime moments of normalized traces, with two-sided positive density of disagreement even in each fixed arithmetic progression. It does NOT control the sign of the meromorphically continued logarithmic-derivative residue Res D'(s)=ord L(E_2,1)-3. The Sturm approach553 forces conductor growth when prime Euler factors match to arbitrarily large cutoffs; it does NOT convert the fourth rational point into a complex central zero. Both approaches operate on the ORIGINAL weight-two forms, not an auxiliary congruence form, and neither assumes BSD, but the required all-E arithmetic–analytic bridge is still open. Retain the previous K3/plane-complement and normal-function calculations and all counterexamples without inferring an all-E rank equality.

---

# Independent BSD continuation — 2026-11-21, entries 555–566: identical 2-Selmer classes, quadratic-twist Bocksteins, persistent Selmer lifts, and explicit 2-coverings

**Full target remains** `rank E(Q) = ord_(s=1) L(E,s)` for **every** elliptic curve E/Q, or a rigorous elliptic-curve counterexample. No such universal proof/counterexample is obtained. These entries use the user's exact four twist controls as given; we independently checked the algebraic identities stated below, but did not rerun the user's 2-Selmer, cubic-field rank, independent-point, or interval L-value certificates. The preexisting sign-change counterexample, original-E Kummer fields, higher-rank points, K3 counts, and all prior refutations are retained.

## 555. Exact inputs; S3 2-division field and two squareclass norms

Let E0:y²=x³−28x+1, and E^(D):y²=x³−28D²x+D³. The 2-division polynomial is f(X)=X³−28X+1, irreducible over Q (no rational root), with discr(f)=87781=41*2141 nonsquare. Thus Gal(Q(E0[2])/Q)=S3=GL2(F2). Because [-1] acts trivially on 2-torsion, E^(D)[2] is naturally the **same** G_Q-module M=E0[2] for every D. The user's two squareclasses alpha1=144+23 theta and alpha2=239+23 theta in K=Q(theta), f(theta)=0, have

  Norm(a+b theta)=a³−28ab²−b³,
  Norm(alpha1)=840889=917², Norm(alpha2)=10099684=3178².

For D=−23 these are the 2-Kummer images of (144,917),(239,3178). The user establishes that for D=−31 the same classes form the whole Sha[2], while for D=−23 they are genuine global point classes; the embedded Sel2 group and its local subspaces coincide and have dimension two. User supplies rank/complex order (0,0) at D=−31 and (2,2) at D=−23; other controls D=73 rank/order1 and D=1 rank/order3 are retained. Local squareclass match: −23≡−31≡1 mod8, and both are quadratic residues at 41 and 2141. The relative quadratic twist character has discriminant 713=23*31.

## 556. Quadratic-twist Bockstein identity at 4-division — proved

For chi_D:G_Q→F2, define the action on the underlying abstract E0[4] via rho_D(g)=(-1)^chi_D(g)rho_0(g). The exact sequence 0→M→E^(D)[4] --[2]→M→0 gives connecting beta_D:H¹(Q,M)→H²(Q,M). For any cocycle c and any 4-torsion cochain lift \tilde c,

  (delta_D \tilde c - delta_1 \tilde c)(g,h)
    = [(-1)^chi_D(g)−1]rho_0(g)\tilde c(h)
    = 2 chi_D(g)rho_0(g)\tilde c(h) in E[2].

Modulo the canonical identification 2E[4]≅M this equals chi_D(g)g*c(h). Therefore

  beta_D(c)=beta_1(c)+chi_D cup c  in H²(Q,M).

The sign of 2 is immaterial modulo4. A cyclic order-two toy example with E[4]=Z/4, trivial original action, quadratic twisted action−1 and c(g)=1 mod2 gives connecting values 1 vs0 in F2, verifying the cochain convention. This is a cohomological *difference*, not a claim of a Sel4 lift.

## 557. All 2-Selmer classes for these S3 curves have *global* 4-division lifts — proved no-go

Compute H¹(S3,M)=0. With normal C3, since |C3| is odd its H¹ vanishes; M^C3=0 because a 3-cycle permutes all three nonzero elements of M. Inflation–restriction gives the result. An exact GF2 row reduction of all normalized 1-cocycle equations gives dim Z¹=2, dim B¹=2, dim H¹=0.

Moreover Sha¹(Q,M)=0: if a globally locally-trivial M-cocycle restricted nontrivially to the kernel of the S3 representation, Chebotarev gives a finite good place splitting in the 2-division field at which the cocycle is nonzero and unramified, contradicting local triviality. Hence it inflates from H¹(S3,M)=0. The Weil self-duality M*=Hom(M,mu2)≅M and Poitou–Tate duality then give Sha²(Q,M)=0, i.e. H²(Q,M) injects into product_v H²(Q_v,M).

For c∈Sel2(E^(D)), every localization c_v comes from a point P_v∈E^(D)(Q_v)/2, which lifts under the local 4-Kummer map. Thus beta_D(c)_v=0 for all v. The H² localization injection gives beta_D(c)=0 globally. Consequently every Sel2 class lifts to **H¹(Q,E^(D)[4])**, for EVERY quadratic twist, but the lift need not satisfy the 4-Selmer local conditions. In particular chi_713 cup c=0 globally for all common c. No analytic-rank conclusion follows. The subtle Cassels–Tate obstruction is to an *everywhere finite* lift, not a raw Galois H¹ lift. Existing work on variation of Cassels pairings under quadratic twist confirms the distinction: A. Morgan, *Hasse principle for Kummer varieties in the case of generic 2-torsion*, Proc. LMS (2025), https://doi.org/10.1112/plms.70066.

## 558. Persistent Selmer subspace and its exact sequence — proved for every E/Q

For any elliptic A/Q and any prime p let A_n=Sel_(p^n)(A/Q), with maps A_(n+1)→A_n induced by [p] on E[p^(n+1)], and I_p(A)=intersection_(n≥1) image(A_n→A_1). The finite sets A_n form a finitely branching tree; König's lemma identifies I_p with the image of lim A_n→A_1.

The Kummer sequences 0→A(Q)/p^n A(Q)→A_n→Sha(A)[p^n]→0 are compatible, with surjective reduction maps on the point quotients and multiplication p on Sha[p^n]. Taking inverse limits stays exact on the left, giving 0→completion_p A(Q)→lim A_n→T_p Sha→0. The p-primary Sha group is of cofinite type and decomposes as (Qp/Zp)^t ⊕ finite, noncanonically. Its Tate module maps onto exactly Sha_div[p] in Sha[p]. Every point Kummer class lifts through every level. Hence

  0→A(Q)/p A(Q)→I_p(A)→Sha(A)[p^infinity]_div[p]→0,
  dim_Fp I_p(A)=rank A(Q)+dim_Fp A(Q)[p]+corank_Zp Sha[p^infinity].

This is a theorem about actual global Selmer lifting, not about existence of a global H¹(4) lift. It is the exact arithmetic invariant missing from the raw 2-Selmer data.

## 559. Exact Selmer towers for −23 and −31, with the sharp finite-exponent caveat

Both twists have no rational 2-torsion. For D=−23, rank2 and Sel2 dimension2 give Sha[2]=0 and therefore Sha[2^infinity]=0. Thus Sel_(2^n)(E^(−23))≅(Z/2^n)^2, |Sel|=2^(2n), I_2 dimension2. For D=−31, L(E^(−31),1)≠0 (user's rigorous interval) implies rank0 and **finite full Sha** by Gross–Zagier–Kolyvagin. Its Sha[2] dimension is2, and finite perfect alternating Cassels–Tate duality forces

  Sha(E^(−31))[2^infinity]≅(Z/2^e)^2 for one integer e≥1.

Hence |Sel_(2^n)(E^(−31))|=2^(2min(n,e)), and I_2(E^(−31))=0. The two Selmer towers can be abstractly identical, including transition maps, for every n≤e; they diverge at n=e+1. The 2-Selmer Cassels pairing in the rank-zero curve is nondegenerate if e=1, but is the zero pairing if e≥2; the rank-two curve's is always zero because both classes come from points. Thus neither raw global 4-Bockstein nor even a single 4-Selmer/Cassels test is **guaranteed** to discriminate them without determining the exponent e. No value for e is asserted here. Perfect alternating pairing classification is standard; radical(image Sel4→Sel2) comparison is in Fisher–Schaefer–Stoll, *The yoga of the Cassels–Tate pairing* and Smith, *4-Selmer and 8-class ranks*.

## 560. Inert support primes 23 and 31 are invisible to ALL local 2-power Galois H¹

The cubic f has no root modulo either 23 or31, so at both primes the residual Frobenius has order3 on M=E0[2]. The residual module has NO local invariants. This remains true after quadratic twisting: inertia from [-1] acts trivially mod2, and Frobenius still has no invariant mod2 vector. Therefore for all D, all n≥1,

  H⁰(Q_ell,E^(D)[2^n])=0 for ell=23,31,
  H²(Q_ell,E^(D)[2^n])=0 by Weil self-duality/local duality,
  H¹(Q_ell,E^(D)[2^n])=0 by the local Euler characteristic (ell !=2).

Thus the ramified support primes of the ratio character chi_713 contribute no *local cohomology obstruction* at any 2-power torsion level, although the GLOBAL Galois representation and the Selmer towers of the two twists differ. This is an exact reason why no local first-descent test at the support primes can detect the rank distinction. The global variation of the Cassels pairing under quadratic twist has to use genuine second descent/global gluing, not just these local cohomology groups.

## 561. Explicit intersection-of-two-quadrics 2-covering for every norm-square alpha=a+b theta

Let N(alpha)=m² and η=u+vθ+wθ². Reduce η² using θ³=28θ−1:

 A=u²−2vw, B=2uv+56vw−w², C=v²+2uw+28w².
 Q0=aA−bC, Q1=aB+bA+28bC, Q2=aC+bB.

Then αη²=Q0+Q1θ+Q2θ². The projective complete intersection

  C_(α,D): Q2(u,v,w)=0, Q1(u,v,w)+D T²=0 in P³

has the degree-four map to the ORIGINAL E^(D):

  (u:v:w:T) |→ (x=Q0/T², y=m N(η)/T³).

Indeed x−Dθ=α(η/T)², so Norm(x−Dθ)=x³−28D²x+D³=(m Nη/T³)². The projective curve is the genus-one 2-cover attached to the squareclass α (over algebraic closure, the norm-compatible square-root choices form four points). This is not an auxiliary unrelated elliptic curve.

For the symmetric 3×3 matrices of Q1,Q2 the exact *polynomial identity* is

  det(λ Q2 + μ Q1) = −N(α)(λ³−28 λ μ²−μ³).

For the full 4×4 pencil of Q2 and Q1+D T², the determinant is −D Nα μ(λ³−28λμ²−μ³). The discriminant double-cover has affine equation Z²=D m² f(−λ); X=−Dλ,Y=(D/m)Z takes it to E^(D). This explicitly proves that the 2-cover's Jacobian is E^(D), up to the standard pencil construction.

For α1=144+23θ,m=917 and α2=239+23θ,m=3178, the projective point (1:0:0:1) lies on C_(α,−23) and maps to (a,m). For D=−31 these exact curves represent the two supplied nonzero elements of Sha[2]: everywhere locally soluble yet rationally pointless. The latter global insolubility is input from the user's proved 2-descent, not an inference from failure of the displayed obvious point.

## 562. Binary-quartic elimination and exact invariant identities

Parametrize Q2=0 using W=b s+a t and

 u=−[a s²+56b st+(28a−b)t²], v=2sW, w=2tW.

Then Q1(u,v,w)=F_(a,b)(s,t), with binary-quartic coefficients c_i (for s^(4−i)t^i):

 c0=−3a²b+112b³,
 c1=−4a³+224ab²−8b³,
 c2=168a²b−18ab²,
 c3=112a³−12a²b,
 c4=−4a³+784a²b+56ab²+b³.

The 2-cover is now the genus-one quartic `(−D)T²=F_(a,b)(s,t)`. The exact classical binary-quartic invariant calculation gives, for every a,b,

  I=12c0c4−3c1c3+c2²=1344 N(α)^2,
  J=72c0c2c4+9c1c2c3−27c0c3²−27c1²c4−2c2³
     =1728 N(α)^3.

For the scaled quartic q=−F/D, its Jacobian in the conventional model `Y²=X³−27I(q)X−27J(q)` is isomorphic to E^(D) via the rational scaling factor 6m/D. The two actual quartics are

 F1=−68080s⁴+5022152s³t+78752736s²t²+328707072st³+366245639t⁴,
 F2=−2578645s⁴−26384468s³t+218439786s²t²+1513249532st³+982490499t⁴.

At D=−23, s=a,t=−b,T=−Nα gives a rational point on each quartic, mapping to (a,m). At D=−31, each quartic equals `31 T²=F_i` and is everywhere locally soluble but has no rational point by the supplied Sha certificate. All these integer and determinant identities were checked exactly by standalone code `bsd_inert_twist_quadrics.py`; no third-party downloads or installations.

## 563. Exact *analytic* limitation: every genus-one 2-cover has the SAME H¹ L-function as its Jacobian

For any genus-one torsor C under an elliptic curve E/Q, choose a geometric isomorphism C_(Qbar)≅E_(Qbar). Galois descent changes this trivialization by translations in E(Qbar), but translations act trivially on H¹_et(E_(Qbar),Q_ell). Hence

  H¹_et(C_(Qbar),Q_ell)≅H¹_et(E_(Qbar),Q_ell) as G_Q-modules,
  L(H¹(C),s)=L(E,s), including the bad local WD factors.

In particular each nonsoluble C_(α_i,−31) has exactly the original `L(E^(−31),s)` and a rigorously nonzero value at1, although no rational point. The trivial torsor E^(−31) has a rational identity and the same L-function. This is a **counterexample to a proposed proof that central nonvanishing detects rational solubility of each 2-cover separately**; it is NOT a counterexample to BSD, since these nonsoluble genus-one curves are not elliptic curves over Q. A successful analytic bridge must see global Selmer/point *arrangements* or derived regulators, not the H¹ L-function of an individual torsor.

## 564. Direct original-L route by Waldspurger, tested on the two twist controls

For −23 and −31 the local quadratic characters match at every bad prime of E0: both ≡1 mod8, and both Legendre symbols are +1 at 41 and2141; the associated negative fundamental discriminants are −23 and−31. This makes them eligible for a common *local test-vector packet* in the Waldspurger correspondence for the original weight-two newform f_E0. In any matched half-integral weight eigenform satisfying the Waldspurger comparison for these indices, the coefficient-square identity has the schematic exact shape `|c_h(|D|)|² = C_h(D)√|D| L(E^(D),1)` with C_h(D)>0 when the specified local factors are nonzero. Thus the user-supplied L(E^(−31),1)>0 and L(E^(−23),1)=0 require `c_h(31)≠0`, `c_h(23)=0` for a correctly chosen nonvanishing packet vector. The exact h and its coefficients were NOT constructed in this continuation; the numerical L intervals and analytic rank2 at −23 are user certificates. See Waldspurger's theorem as summarized in Ono, *Rank zero quadratic twists*, and Purkait, *Explicit application of Waldspurger's theorem* (2013): https://doi.org/10.1112/S1461157013000144.

This IS a global analytic statistic distinguishing the identical local 2-Selmer cases. But it tests central VALUE only; c_h(23)=0 does not distinguish complex analytic orders2,4,... . No identity from c_h to the persistent Selmer space I_2 was proved. The obvious proposed identity to a single finite Cassels pairing is also unavailable: when e≥2 the rank-zero curve's Sel2 Cassels pairing vanishes just as the rank-two one's does, despite c_h(31) nonzero.

## 565. Another attempted bridge fails: quadratic characters cannot vary nontrivially in an analytic quadratic family

Suppose R is an integral characteristic-zero algebra of analytic functions on a connected parameter domain and a continuous family of Galois characters χ(g)∈R^× satisfies χ(g)^2=1 for EVERY g. Then `(χ(g)−1)(χ(g)+1)=0` in the integral domain, so χ(g)=+1 or−1 as a constant analytic function. Thus the whole family is constant. More generally, if infinitely many quadratic specializations accumulate in an analytic disk, the analytic identity theorem forces χ(g)^2−1 identically zero for every g, again giving no nonconstant family. Hence there is no way to obtain a derivative in **D** of the Waldspurger coefficient by interpolating genuine quadratic characters through a single analytic branch. Deformations χ_D(1+ηκ) over dual numbers are not quadratic in characteristic zero; their derivative is a cyclotomic/weight cohomological derivative and requires a separate period and height comparison. This prevents a naive shortcut from a square-root central-value formula to L''(E^(−23),1).

An independent first-order Heegner route also stops: for analytic rank2 E^(−23), every Heegner base change satisfying the Gross–Zagier setup has L'(E^(−23)/K,1)=0, since L(E^(−23),s) already vanishes twice and the quadratic twist factor is entire. Gross–Zagier therefore gives canonical height zero for the ordinary Heegner trace, hence torsion. The two nontorsion rational points cannot be generated by that unmodified first-derivative construction. Derived/global higher-rank cycles would be needed, with rational point origin and nonvanishing independently proved.

## 566. Exact continuation target and limitations

There are now three precise layers for the SAME original E^(D):

  (1) *Finite 2-Selmer/local virtual units:* identical for D=−23 and D=−31; even global 4-Bocksteins vanish on all those classes (entries555–557).
  (2) *Persistent global Selmer lifting:* the dimension is2 versus0, and is realized by actual rational points versus a finite Sha hyperbolic pair (entries558–560). Explicit intersections of quadrics and binary quartics realize every class and its original Jacobian (entries561–562).
  (3) *Complex analytic central L-function:* L(E^(−31),1)>0 while L(E^(−23),1)=0 and L''(E^(−23),1)>0 by the user's intervals. Waldspurger distinguishes the central VALUE through a global half-integral coefficient but the second derivative/rank comparison is still missing. Individual 2-cover H¹ L-functions cannot distinguish rational solubility (entries563–565).

A promising *precise* next arithmetic calculation is the Cassels–Tate pairing / 4-Selmer image for the two explicit `31 T²=F_i(s,t)` coverings; this determines whether the finite Sha exponent e is1 or>1. It is a finite arithmetic improvement, not the universal BSD conclusion. The exact full-target missing theorem remains a derived regulator or automorphic comparison forcing `ord_(s=1)L(A,s)=dim(I_p(A))−corank Sha[p∞]−dim A(Q)[p]` for every elliptic A/Q (which is simply the full BSD equality in precise Selmer language). Do not import a conjectural equality as a theorem, and do not replace the original all-E/Q target by the auxiliary genus-one or half-integral-weight problem. No installation, download, spending or outside contact occurred.

## 567. Discriminant identity and the common 2-division field inside the quadric pencil

A further exact computation for the quartics of562 is

  4 I(F)^3 − J(F)^2
    = (4*1344^3 − 1728²) N(α)^6
    = 2^12 * 3^3 * (41*2141) * N(α)^6.

Thus their classical discriminant is nonzero (D≠0,Nα≠0) and its only fixed prime factors, before scaling by D and the norm, come from discr f=87781. The quartic pencil determinant from561 has a rational singular-quadric parameter μ=0 and three parameters cut out by f(λ)=0. The S3 Galois action on those three parameters is exactly the common E^(D)[2] action. This explains directly from the **explicit 2-cover geometry** why the 2-torsion field is independent of D while the corresponding 2-covering's rational solubility is not. The quartic discriminant and pencil identities are purely algebraic and were verified exactly by the same local script, with no source-dependent numerical claims.

---

# November 21, 2026 — new exact second descent and prime-twist extension (entries 568–576)

**Full target remains:** for every elliptic curve E/Q, prove rank E(Q) = ord_{s=1} L(E,s), or produce a verified counterexample. These entries are exact arithmetic results / conditional analytic bridges, not that universal theorem. Source of the two shared Selmer classes and analytic-rank intervals: user-supplied coordinator certificates. Fisher's actual theorem is https://link.springer.com/article/10.1007/s40993-022-00376-z (Theorem 3.1); BFH is https://wstein.org/papers/bib/bump-friedberg-hoffstein-nonvanishing.pdf (introduction theorem parts (i),(ii)). The separate work here is original exact algebra and its local computations; novelty and external acceptance unestablished.

## 568. Construct the full triple of binary-quartic 2-coverings

For K=Q(theta), theta^3-28theta+1=0, the Selmer classes corresponding to the two actual E^(-23) points (144,917),(239,3178) are alpha1=144+23theta, alpha2=239+23theta. Their sum P+Q=(4586/25,-231959/125), yielding alpha3=4586+575theta, norm 231959^2. Direct K-arithmetic gives

  alpha1*alpha2*alpha3=(12551+2737theta)^2.

This third class is the sum of the first two in H^1(Q,E[2]). The three are the complete nonzero common 2-Selmer classes for twists D=-23,-31, by the user's already-certified Selmer identification. Their concrete quartic models g_i for D=-31 are F_(a,b)/(31 m_i^2) where N(a+btheta)=m_i^2 and

  F_(a,b)(s,t) = (-3a²b+112b³)s⁴ +(-4a³+224ab²−8b³)s³t
                +(168a²b−18ab²)s²t² +(112a³−12a²b)st³
                +(-4a³+784a²b+56ab²+b³)t⁴.

All g_i have I=1344/31², J=1728/31³. The associated Fisher cubic algebra has varphi=(12/31)theta and z(g_i)=alpha_i eta_i², with eta1=(576−184theta)/(31*917), eta2=(478−92theta)/(31*1589), eta3=(18344−4600theta)/(31*231959). The exact cubic square root needed by Fisher is m=(12551+2737theta)eta1 eta2 eta3. Each displayed identity was checked over Q(theta) exactly. Do not replace z(g_i) merely by its squareclass: Fisher's coefficient formula requires the exact representatives.

## 569. Completed Cassels–Tate second descent for D=-31

Apply Fisher Theorem 3.1 to g1,g2,g3. If H1(s,t) is the quadratic Hessian-derived form for g1, and gamma(s,t) is the varphi² coefficient of (z2 z3/m) H1, exact calculation gives

  gamma(s,t)=−(62/3)² * Q(s,t)/d,
  d=1438439174552471,
  Q(s,t)=9990323700 s²+64402927670 st+87197738503 t².

The squareclass of g2(1,0) is A=−2578645*31. On the first covering the local condition g1(s,t) square is equivalent to 31 F1(s,t) square, with

  F1(s,t)=−68080s⁴+5022152s³t+78752736s²t²+328707072st³+366245639t⁴.

The Fisher pairing is product_v (A,−d Q(s_v,t_v))_v. Exact local Hilbert symbols using explicit local points are: negative at finite p=5,7,13,17,227,1319; positive at p=2,3,23,31,41,131,2141,2549; real symbol negative. All other primes trivial by Fisher Remark3.3 (good smooth quartic, A unit, gamma content and discriminant units). Six finite negatives multiply to positive; with the real negative the pairing is -1.

The common Sel2 has dimension 2, E^-31 has rank0 and E^-31(Q)[2]=0 (user's exact arithmetic certificate). The nonzero pairing on generators is nondegenerate; its radical is the image of Sel4->Sel2. Hence that image is zero, so Sha(E^-31)[2^infinity] has exponent2 and cardinality4: exactly (Z/2)^2. This improves earlier (Z/2^e)^2 with unspecified e. It does not prove the *refined* BSD analytic leading coefficient formula or general rank equality.

Computational source and local choices: `/mnt/data/bsd_second_descent_fisher_31.py`; executed successfully, standard-library exact rationals.

## 570. Five further explicit prime twists with identical first Selmer space, all rank0

For q prime, q=7 (mod8), inert in the S3 cubic K, and with q square modulo 41 and 2141, the local Sel2 conditions outside q and the old bad places agree with D=-31. At the new q and the old 31, H¹(Q_l,E[2])=0 when the cubic Frobenius is a 3-cycle, including for ramified quadratic twists. This is finite local Euler characteristic + self-duality + absence of invariants. At 2,41,2141 local squareclass matching supplies local curve isomorphisms. Thus the embedded Sel2 is the same fixed two-dimensional subspace.

For D=-q, the quartics scale by g_i(-q)=(31/q)g_i(-31), the cubic invariants z_i scale by (31/q)^2, H1 scales by (31/q)^2, its square root m scales by (31/q)^3, and Fisher gamma scales by (31/q)^3. This gives local Hilbert representatives

  A_q=−2578645*q, B_q(s,t)=−31*q*d*Q(s,t),

with q F1(s,t) square at the chosen local point.

Exact computations give nondegenerate pairing, algebraic rank0 and 2-primary Sha=(Z/2)^2 for q=631,647,1231,1439,1663. Negative finite local places respectively:
  631 : 5,13,23,131
  647 : 7,131,227,2549
  1231: 5,7,17,131,227,2549
  1439: 5,17,131,1319
  1663: 17,23,131,1319.
At infinity always -; each finite list has even length. No complex analytic rank was certified for these five.

**Crucial counterexample to a shortcut:** H¹(Q_q,E[2])=0 at the new inert ramified prime, but the Fisher Hilbert symbol at q may be -1, depending on q. Zero local Selmer space does NOT make its Brauer contribution trivially +1.

Computation `/mnt/data/bsd_uniform_twist_second_descent.py` executed successfully.

## 571. Infinite prime twists with rank0 and nonzero two-primary Sha: a Chebotarev theorem

Let S={2,3,5,7,13,17,23,31,41,131,227,1319,2141,2549}, and M=8*product_{odd p in S} p. Let F1(X)=F1(X,1), Q(X)=Q(X,1), C=−2578645*31*d. At q0=631 (prime, q0∉S) exact arithmetic gives:

  x³−28x+1 irreducible modulo631;
  F1(X) has exactly one simple root r=484 modulo631;
  C=400 mod631, Q(484)=9 mod631,
  (C*Q(484) / 631)=+1;
  Res(F1,Q)=562 mod631; discriminant(F1)=124 mod631.

Let H/Q be a finite Galois compositum of Q(zeta_M), the splitting fields of x³−28x+1 and F1, and the splitting field of the polynomial obtained by adjoining the roots sqrt(C*Q(r_i)) for all four roots r_i of F1. q0=631 is unramified in H: prime631 divides none of M, discriminants or resultant and C is unit. Its Frobenius class is therefore defined.

By Chebotarev, infinitely many primes q have Frobenius conjugate to that at631. All such q satisfy q=631 modM, are inert in the cubic K, have F1 modq with exactly one simple root r_q, and have C*Q(r_q) square modq. At each fixed p∈S, the D=-q curve and Fisher symbol have the same local squareclass data as D=-631 (for p=31 compare with -631, NOT the ramified reference -31). At all p outside S and q the Fisher symbol is trivial by good reduction / Fisher Remark3.3; in particular q=631 is not a hidden exceptional prime when q differs from631.

At the new prime q, choose a Q_q-local parameter s near the unique simple root r_q of F1 with v_q(F1(s,1))=1 and q*F1(s,1) a square. Since Q(r_q) is a unit, evaluating the Hilbert symbol yields exactly (C*Q(r_q)/q)=+1. Therefore the global Cassels pairing is the same -1 as at q=631. It is nondegenerate on the fixed two-dimensional Sel2. Hence for every such q,

  rank E^(-q)(Q)=0, Sel2(E^(-q))=(Z/2)^2,
  Sha(E^(-q))[2^infinity]=(Z/2)^2.

This defines a positive-natural-density set of primes (at least one nonempty Frobenius conjugacy class in a finite Galois group). It is an actual infinite arithmetic-rank theorem, NOT an unconditional complex analytic-rank-zero theorem. Neither full Sha finiteness nor exact BSD rank equality for all q is established. No novelty claim relative to the entire literature is made.

Exact one-prime witness verifier: `/mnt/data/bsd_chebotarev_prime_twist_witness.py` executed successfully without packages. It checks 631, cubic inertness, unique quartic root, character sign, and resultant congruence. Analytic nonvanishing of the twists in this *nonabelian Chebotarev-defined prime class* remains open in this project.

## 572. BFH gives separate infinitely many rank-BSD-equality quadratic fields, not yet a bridge to the prime class

Bump–Friedberg–Hoffstein (Invent. Math. 102 (1990), introduction theorem(i),(ii)) for weight-two E0 and any finite set of prescribed splitting primes S produces D<0 with L(E^D,1)≠0 and D>0 with L'(E^D,1)≠0, because E0 has root number -1 and the fixed primes split. As S increases (exclude earlier quadratic fields using a new inert-prime demand), these provide infinitely many fields K=Q(sqrt D). Gross–Zagier–Kolyvagin gives algebraic ranks0/1 and finite Sha for the auxiliary twists, so E0/K has rank/analytic order3 (D<0) or4 (D>0). For explicit D=-23 with rank/order2 on the twist, E0/Q(sqrt -23) has rank/analytic order5. The theorem does not assert D is a *prime* in our positive-density nonabelian Chebotarev class; in particular, one cannot silently combine it with entry571 to conclude analytic rank0 for those prime twists.

Exact uncompleted analytic derivative formulas:
  L^(3)(E0/K,1) = L^(3)(E0,1)*L(E^D,1)  for ord twist0;
  L^(4)(E0/K,1) = 4 L^(3)(E0,1)*L'(E^D,1)  for ord twist1;
  L^(5)(E0/Q(sqrt -23),1) = 10 L^(3)(E0,1)*L''(E^(-23),1)  for ord twist2.
All are nonzero under respective coordinator/primary-source hypotheses.

## 573. A regulator identity with the exact two-power index

Let K=Q(sqrt D), r=rank E(Q), r_D=rank E^D(Q), and phi:E^D(K)->E(K), phi(X,Y)=(X/D,Y/(D sqrt D)). Take lattices L=E(K)/tors, Lplus=E(Q)/tors, Lminus=phi(E^D(Q))/tors. The involution acts + on Lplus and - on Lminus; their canonical heights are orthogonal and the inherited absolute height form on each equals its standard Q height. Every point satisfies 2P=(P+tau P)+(P−tau P), so Lplus+Lminus has finite index m=[L:(Lplus+Lminus)] a power of2, with m<=2^(r+r_D), although torsion quotients must be handled carefully for the exact numerical bound. The equality of lattice determinants gives

  Reg(E/K)=Reg(E/Q)*Reg(E^D/Q)/m²

for the absolute canonical-height normalizations and the same rank conventions. For K=Q(sqrt -23), ranks 3+2=5, and combining Artin-factorization of leading L-values gives

 [L^(5)(E/K,1)/5!] / Reg(E/K)
 = m² * [L^(3)(E,1)/3! / Reg(E/Q)]
        * [L''(E^(-23),1)/2! / Reg(E^(-23)/Q)].

This is unconditional given the known rank/order5 and actual point bases; it does NOT prove the BSD refined rationality or predict m without arithmetic saturation. It gives an exact higher complex derivative/real regulator comparison on the same curve over K.

## 574. Odd-primary Sha persists through BFH quadratic base changes

For odd p, restriction/corestriction and Shapiro decompose the p-primary Selmer complexes of E/K into the plus part for E/Q and minus part for E^D/Q. Consequently

  Sha(E/K)[p^infinity] ~= Sha(E/Q)[p^infinity] ⊕ Sha(E^D/Q)[p^infinity]

as p-primary groups (up to canonical ± identifications). For the BFH twists with analytic rank0 or1, the twist Sha is finite. Thus for every odd p,

  T_p Sha(E/K) ~= T_p Sha(E/Q).

In particular, the infinitely many quadratic K with verified rank equality3 or4 DO NOT alone imply finiteness of Sha(E/Q), and do not prove the general rank equality. A universal bridge must control this unchanged obstruction, rather than just exploiting many low-rank quadratic twists.

## 575. Source check and exact next analytic obligation

Fisher2022 Theorem3.1 is exactly the quartic gamma/Hilbert formula used, with Remark3.3 establishing finite support. The 2026 Chida–Wakatsuki prime-twist nonvanishing theorems in Research in Number Theory apply to explicit weight8/level2 and weight4/level6 newforms, not to this non-CM weight2 elliptic newform. Ono–Skinner1998 Corollary1 can produce prime twist nonvanishing from an additional half-integral-weight Fourier coefficient attaining the global minimum 2-adic valuation at a specified prime in the chosen congruence/number-of-prime-factors family; the existence of that special minimal coefficient for our desired nonabelian Frobenius class has not been proved. BFH's unrestricted signed twists with finitely prescribed splitting do not ensure the squarefree discriminant has one prime factor or that this prime's Frob is in entry571's specified nonabelian class.

**Next target:** prove L(E^(-q),1)!=0 for one or infinitely many q in entry571's arithmetic Chebotarev family by a genuinely applicable Waldspurger / modular-symbol / analytic nonvanishing argument. This would give actual BSD rank equality for those q and for E0 over the corresponding quadratic fields. It would STILL not establish unrestricted BSD for all E/Q. Alternative unrestricted routes must supply a new theorem controlling all higher analytic central orders and point/Sha realizations, not merely their finite 2-Selmer data.

No installs, third-party code downloads, external publication, submission, or spending occurred. All stored computations are local and reproducible with the Python standard library.

## 576. Opposite second-descent Chebotarev classes with EXACTLY the same finite local squareclasses

The finite Chebotarev sign tau(q) from571 takes BOTH values within the same congruence class q=631 (mod M). Here M=1161644919817261523793240 (8 times all odd fixed exceptional primes from571). Two new primes and full primality certificates:

  qplus=8131514438720830666553311=631+7*M,
  qminus=11616449198172615237933031=631+10*M.

qplus−1 has factorization 2·3·5·7·67·51217·2822707·3997582207; the Lucas full-factorization witness is 6. qminus−1 has factorization 2·3·5·7·11·1201·18013·1878641·123733861; Lucas witness is 7. Every displayed factor is prime (checked with the deterministic seven-base Miller–Rabin test for n<2^64); for each q, g^(q−1)=1 mod q and gcd(g^((q−1)/p)−1,q)=1 for every p | q−1. Thus these large q are *rigorously* prime, not merely probable primes.

The cubic f=x³−28x+1 is irreducible mod both primes. At qplus, the quartic F1 has unique simple root rplus=4143130282725631647269129; the Legendre character (C Q(rplus)/qplus)=+1. At qminus, the quartic has unique simple root rminus=1500973064531336180020977 and (C Q(rminus)/qminus)=−1. All statements were checked by exact modular polynomial exponentiation and Euclidean gcd (not by enumerating field elements).

For ANY such prime q in the fixed congruence class with f inert, F1 having a unique simple root r_q and Q(r_q) nonzero, the global Cassels pairing equals **−(C Q(r_q)/q)**. Proof: all fixed-place Hilbert symbols agree with q=631, their product including infinity is -1; all other places outside q are unramified and contribute +1 by Fisher Remark3.3; the q-place symbol is the stated Legendre sign. In particular,

  tau(q)=+1 => pairing -1 => Sel4->Sel2 zero; rank 0, Sha[2^infty]=(Z/2)^2.
  tau(q)=-1 => pairing +1 => Sel4->Sel2 onto; both nonzero Sel2 generators admit level-4 Selmer lifts.

In the latter case NO rank-2 claim follows; the lifts could be Sha[4] classes. The two prime witnesses are unramified Frobenius classes in the same finite Galois governing extension H/Q, with the SAME image in the cyclotomic quotient Q(zeta_M), but differing in the Kummer sign over the quartic fixed root. Chebotarev gives positive natural density of primes realizing EACH class. The result is a positive-density dichotomy in a **specified two-dimensional embedded 2-Selmer subspace** with identical local squareclasses at every fixed bad place, but opposite 4-Selmer persistence.

Stand-alone reproducible certificate: `/mnt/data/bsd_two_chebotarev_second_descent_classes.py`, executed successfully, pure Python standard library, including full Lucas primality and polynomial finite-field gcd certificates. No claims of original publication/novelty are made.

The analytic rank remains unproved for both families (except q31 from the user's independent rigorous central interval). Even in the rank-0, finite-Sha2 family, complex order may be any even nonnegative integer a priori. Precisely this unproved implication is a form of the **rank-zero converse** and remains indispensable to unrestricted BSD. The Kummer/CT finite data cannot be substituted for an analytic nonvanishing theorem.

## 577. Exact all-curves restriction on the BFH-basechange strategy

For *any* elliptic E/Q and any quadratic K/Q with character chi_D, the odd-p Galois module decomposition of Ind_{G_K}^{G_Q} E[p^n] is E[p^n]⊕E^D[p^n]; Shapiro plus local Kummer conditions gives an isomorphism of entire odd-p Selmer groups, and hence of Sha[p^infty]. In particular if a BFH twist E^D has analytic rank 0 or1, its Sha is finite by the known Gross–Zagier–Kolyvagin implication; nevertheless T_p Sha(E/K) ~= T_p Sha(E/Q) for every odd p. Thus infinitely many quadratic-base-change rank-equality certificates can coexist with the full unresolved Sha obstruction on the original E. The Artin L-factorization gives the additive rank discrepancy delta(E/K)=delta(E)+delta(E^D)=delta(E) on these BFH fields. This proves that choosing arbitrarily many low-rank auxiliary quadratic extensions does not eliminate any existing rank-discrepancy problem for E itself.

**Analytic target for the explicit Chebotarev arithmetic family:** establish L(E^(-q),1)!=0 on the tau=+1 classes (or at least one q), via a valid half-integral-weight/Heegner or main-conjecture theorem. The BFH theorem is a signed twist nonvanishing theorem with finitely prescribed splitting but not this *prime-support, nonabelian Chebotarev-class* nonvanishing assertion; the prime-twist results of Kriz–Li require a rational 2-torsion point, absent for E0. Even such analytic nonvanishing in the family would not prove unrestricted BSD for every E/Q.

## 578. Exact quartic cubic-resolvent identification and S4 proof

Let F(X)=−68080X⁴+5022152X³+78752736X²+328707072X+366245639, and write its monic normalization as X⁴+bX³+cX²+dX+e. Its standard cubic resolvent is

  R(Y)=Y³−cY²+(b d−4e)Y+(4 c e−d²−b²e).

Exact rational polynomial calculation gives

  R(c/3 − (840889/17020)*theta)
    = (−840889/17020)^3 * (theta³−28theta+1).

Consequently the resolvent cubic field of F is exactly Q(theta), the E0[2] field. The quartic F is irreducible modulo13: gcd(F,X^13−X)=gcd(F,X^(13²)−X)=1 in F13[X], checked by modular exponentiation. Its discriminant equals 2^12*7^12*131^12*41*2141, nonsquare. Its resolvent is irreducible with Galois group S3. The quartic Galois group is S4. Under its natural quotient S4->S3 the odd-order 3-cycles are precisely elements mapping to a 3-cycle in S3. Therefore for every prime q outside the finitely ramified set,

  x³−28x+1 irreducible modulo q  <=>  F(X) factors (degree1)*(irreducible degree3) mod q.

Hence the unique quartic fixed root required by the Fisher q-local formula is *automatically guaranteed* by cubic inertness. A separate quartic Frobenius restriction is unnecessary. Exact witness verifier `/mnt/data/bsd_quartic_resolvent_frobenius.py` executed successfully with standard-library fractions and F13 polynomial gcd.

## 579. Exact natural densities of the opposite 4-descent classes

Set M=1161644919817261523793240 and phi(M)=205488150364374958080000. Let H0 be the compositum of Q(zeta_M) and the S4 splitting field of F. The intersection of the latter with the abelian cyclotomic field is its maximal abelian subextension Q(sqrt(41*2141)): the abelianization S4^ab=C2, and the quadratic discriminant field has conductor 41*2141 dividing M. Thus

  Gal(H0/Q)=S4 ×_{sign=C2} (Z/M)^times, of size 12*phi(M).

For a fixed arithmetic Frobenius a=631 modM, its quadratic discriminant sign is +1. The possible S4 components are the 12 even permutations; 8 are 3-cycles (quartic type1+3), and all eight are conjugate in H0 because an odd S4 conjugator can be paired with a determinant-negative cyclotomic element. Thus the base Chebotarev set q=631 modM and cubic inert has density 8/(12phi(M))=2/(3phi(M)).

Let H/H0 adjoin all sqrt(C Q(r_i)) for the four roots of F, where C=−2578645*31*d. For a Frobenius element over a 3-cycle, exactly one quartic root r_i is fixed; define tau=+1 or−1 from the action on sqrt(C Q(r_i)). This defines a conjugacy-invariant sign on such elements. The *two explicit Lucas-certified primes* from576 map to the same conjugacy class in H0 but have opposite tau signs. After conjugating lifts to the same base element g0, their ratio lies in N=Gal(H/H0) and negates the radical at its unique fixed root. Therefore the resulting character N->C2 is nontrivial, so precisely half the fiber over every such g0 gives tau+, and half tau−.

Chebotarev gives the exact two equal natural densities

  delta(tau=+) = delta(tau=−) = 1/(3 phi(M))
               = 1/616464451093124874240000.

These are densities among ALL rational primes, NOT conditional proportions among q=631 modM. Conditional on that congruence and cubic inertness the two signs have probability1/2 each. For tau+, Fisher pairing is nondegenerate and rational rank=0, 2-Sha=(Z/2)^2. For tau− the entire 2-Selmer space lifts to Sel4, but rank0/1/2 versus higher-Sha remains undetermined. No complex analytic-rank density has been inferred from this arithmetic Chebotarev theorem.

The two prime primality certificates in `/mnt/data/bsd_two_chebotarev_second_descent_classes.py` were checked via full (q-1) factorization into deterministic-verified small primes and explicit Lucas witnesses, as well as exact finite polynomial gcds and Legendre symbols. The result is a **complete, reproducible finite-Galois and second-descent computation**; it has not had external peer review and is not claimed novel.

## 580. Exact original-newform modular-symbol reduction of the central twist value

Let f=f_E0 be the normalized weight-two newform of E0, conductor N, and for a good prime q set

  lambda_f(r) = 2 pi i * integral_(r -> i infinity) f(z) dz.

The Hecke operator T_q on weight-two forms gives
  T_q f(z) = q f(qz) + (1/q) sum_{a=0}^{q-1} f((z+a)/q).
Integrating from 0 to i infinity and using T_q f=a_q f yields the exact Hecke period identity

  sum_{a=0}^{q-1} lambda_f(a/q) = (a_q−1) lambda_f(0).

For the base curve E0 of analytic rank3, lambda_f(0)=−L(E0,1)=0, so the sum over a=1..q-1 also vanishes. If q=3 mod4 and chi=chi_(-q) is the primitive odd quadratic character modulo q, then

  S_q=sum_{a=1}^{q−1} chi(a) lambda_f(a/q)
     = −2 sum_{chi(a)=−1} lambda_f(a/q).

On the other hand, the additive Gauss-sum evaluation of Fourier terms gives

  S_q=−tau(chi) L(E0 ⊗ chi,1)=−tau(chi) L(E^(-q),1),

where tau(chi)=sum chi(a)exp(2pi i a/q), tau(chi)^2=−q. Combining,

  L(E^(-q),1) = (2/tau(chi)) sum_{1<=a<q,chi(a)=−1} lambda_f(a/q).

This is an EXACT finite formula for the central value of the original twisted elliptic L-function in terms of modular symbols of the un-twisted E0 form. In particular the original base central vanishing forces a factor2 in the integral modular-symbol sum, though identifying its 2-adic valuation requires a fixed saturated period lattice and normalization. For q31 the half-sum is nonzero by the user's interval; for q23 it is zero by the certified rank2. To deduce analytic rank0 for the tau+ Chebotarev family it would suffice to prove a suitable integral normalization of the *half-sum* is nonzero mod2 (or directly over Q) on that family. We do NOT have this congruence, and the Cassels pairing theorem does not imply it. The exact missing implication is explicit rather than a generic appeal to Chebotarev.

## 581. Status of a newly located October 2026 preprint: not a verified imported theorem

The public OpenAI preprint `Goldfeld's analytic density conjecture and the 2-converse for elliptic curves` (September/October 2026, https://github.com/openai/math/...) claims that, for every E/Q, corank_{Z2} Sel_{2^infinity}=0 or1 forces complex analytic rank equal that corank. If this claim survives independent mathematical verification, the tau+ arithmetic Chebotarev class from579 has Selmer corank0 and would therefore have L(E^(-q),1)!=0, producing actual rank-BSD examples. The corresponding documents have NOT been independently reviewed in this project, and their proof depends on long novel binary twist interpolation and uniform integral two-adic specialization estimates. We read their introduction, 2-adic interpolation and irreducible residual proof sections, not the full chain; no claim of proof validity, peer review, or established theorem follows. Furthermore, the density statement for ALL squarefree twists (if correct) would still not directly give analytic nonvanishing along a specified prime-supported subfamily, which has density0 among squarefree integers. Do not import this preprint's claim as a solved implication without verifying the critical proofs. Published established sources retained: Fisher2022 for CT pairing and BFH1990 for some low-rank quadratic twists, with their exact scopes.

Next full BSD target: a universal, independently justified extension-sensitive analytic comparison controlling the COMPLEX order of vanishing for all E/Q, beyond ordinary root-sign/parity and first 2-adic Selmer data; no such implication was proved here.

## 582. Exact 2-saturation of the two rational points on the rank-two twist

For E^(-23): y²=x³−28·23²x−23³, P=(144,917) and Q=(239,3178), the common 2-Selmer group from the user's certificate is F2² and is spanned by the explicit nontrivial 2-Kummer classes alpha1=144+23theta and alpha2=239+23theta. Rank E^(-23)(Q)=2, E^(-23)(Q)[2]=0; the Kummer exact sequence then shows Sha(E^(-23))[2]=0 and E^(-23)(Q)/2E^(-23)(Q) ~= Sel2. The Kummer images of P and Q are a basis, hence P,Q are independent modulo2 and generate the saturated 2-adic Mordell–Weil lattice. In particular

 [E^(-23)(Q)_free : ZP+ZQ] is ODD.

The regulator R(P,Q)=det of the Neron–Tate height pairings of P,Q equals the full rank-two regulator multiplied by the SQUARE of an odd integer; its 2-adic valuation agrees with the saturated regulator's valuation. This is a genuine additional arithmetic constraint needed to test the 2-part of any second-complex-derivative BSD leading-term formula, and is stronger than mere independence modulo7. It does not prove any analytic comparison.

## 583. What the opposite 4-descent family forces, and what it does not

For q in the tau− family of579, Sel2 dimension2 and the Cassels pairing on it is zero. Hence Sel4->Sel2 is surjective. The rational Mordell–Weil rank is at most2. If rank=0, every one of the two generators of Sha[2] is divisible by2 in Sha, so Sha[4] contains (Z/4)^2 (or a larger compatible 2-primary group); this follows directly from the finite Kummer exact sequence, without assuming Sha finite. If rank=2 then Sha[2∞]=0. Rank1 with divisible 2-primary Sha cannot be excluded from merely this finite-level calculation without a separate finiteness/parity-of-algebraic-rank input; the proved *2-Selmer corank parity* does not by itself equal rational rank parity when Sha has positive divisible corank. Consequently no rank2 or analytic-rank2 claim is made for tau−. In the tau+ family, nondegenerate CT *does* prove rank0, finite 2-primary Sha of order4 and 2-infinite Selmer corank0.

The root number of all q≡631 modM is +1: E0 has root number−1 by its certified complex order3; D=−q is negative, prime to the conductor, and all fixed bad primes split in Q(sqrt−q), so the twist root number is −(−1)=+1. Their complex analytic orders are even, but the tau+ 2-Selmer corank0 does not give complex order0 via any independently validated theorem used here. Exact analytic rank0 on tau+ remains the substantive missing implication.

All symbolic and exact certificates in this continuation are stored in:
  /mnt/data/bsd_second_descent_fisher_31.py
  /mnt/data/bsd_uniform_twist_second_descent.py
  /mnt/data/bsd_chebotarev_prime_twist_witness.py
  /mnt/data/bsd_two_chebotarev_second_descent_classes.py
  /mnt/data/bsd_quartic_resolvent_frobenius.py

Every listed script was executed successfully. This note is cumulative; entries1–567 are preserved above, and the exact general all-E/Q BSD target remains open.

## 584. Exact prime-twist Chebotarev diagonal and the adjoint L-value

CURRENT TURN 2026-11-21. This pass uses the established prime classes from entries568–583 and no density-one theorem for ALL squarefree twists. Fix E0:y²=x³−28x+1 with newform f=sum a_n q^n, conductor N0. Retain the Fisher +/− prime classes q≡631 (mod M), q inert in the 2-division cubic, and tau(q)=Legendre(C Q(r_q),q) where F(r_q)=0 is the unique quartic root. For tau+, the supplied Fisher theorem gives rank E0^(−q)(Q)=0 and Sha[2^∞]=(Z/2)^2; analytic nonvanishing is STILL UNKNOWN for the unbounded prime family. Define B divisible by 8N0 and all primes ramified in the Fisher radical field H, form F=H Q(zeta_B), and fix a conjugacy class C in Gal(F/Q) refining a *positive Fisher sign* and one residue a mod B, density delta_C>0. For any fixed integer n, define m_C(n) as the Chebotarev mean of chi_(−q)(n) supported on that class divided by pi(X). Quadratic reciprocity (q≡3 mod4) and ramification disjointness imply

 m_C(n)/delta_C = h_B(n) = product_(ell|B)epsilon_ell^v_ell(n) if every v_ell(n) outside B is EVEN; =0 otherwise,

where epsilon_ell=chi_(−q)(ell) is constant on the residue class. The formula for fixed n is exact. It DOES NOT justify interchanging the limit q→∞ with a length-~q approximate functional equation.

The diagonal Dirichlet series D_C(s)=sum_(n≥1) a_n h_B(n)n^(−s), initially Re(s)>3/2, has the exact Euler product

 D_C(s) = [L^(B)(Ad E0,2s−1) / zeta^(B)(4s−2)] * product_(ell|B)L_ell(E0,epsilon_ell,s).

At good ell∤B the proof is the identity

 sum_(j≥0) a_(ell^(2j)) ell^(−2js) = (1+ell^(1−2s))/[(1+ell^(1−2s))²−a_ell² ell^(−2s)] = (1−ell^(2−4s))*L_ell(Ad E0,2s−1).

At bad ell∈B use the ordinary actual bad Euler factors (no good-place recurrence is imported). Rankin–Selberg/Petersson gives L(Ad E0,1)>0; zeta^(B)(2)>0; each local real elliptic factor at1 is positive, so D_C(1)>0. This is a rigorous positive DIAGONAL contribution specific to the thin prime Chebotarev class, not a proof of positive first moment.

## 585. Exact analytic off-diagonal requirement and a conditional prime nonvanishing theorem

For q∤N0, q≡3 mod4 and root number +, conductor N_q=N0 q², the weight-two functional equation gives the *exact* approximate functional equation at the central point (an exponential Mellin cutoff, not an approximation):

 L(E0^(−q),1) = 2 sum_(n≥1) a_n chi_(−q)(n)/n * exp(−2*pi*n/(q*sqrt(N0))).

Let psi≥0 smooth compact support in(1,2), not identically0. Define the explicit off-diagonal

 R_C(X)=sum_(q prime) psi(q/X) 1_(Frob_q in C) sum_(n≥1) (a_n/n) [chi_(−q)(n)−h_B(n)] exp(−2*pi*n/(q*sqrt(N0))).

If R_C(X)=o(X/log X), then weighted Chebotarev and the positive diagonal imply

 sum_(q prime)psi(q/X)1_C(q)L(E0^(−q),1) ~ 2delta_C D_C(1) (integral_1^2 psi(t)dt) X/log X >0.

Thus that ONE precise estimate would yield infinitely many primes in the Fisher rank-zero family also of analytic rank0, proving BSD for them. No such error estimate is established here. Ordinary termwise Chebotarev at fixed n is not uniform for n on the twist-conductor scale n~q. A generic quadratic large sieve does not supply the needed o(X/log X) at this length without additional arithmetic cancellation.

The smoothed fixed diagonal A_B(T)=sum_n a_n h_B(n)e^(−n/T)/n has the unconditional stronger asymptotic A_B(T)=D_C(1)+O_eta(T^(−eta)) for 0<eta<1/4. Proof by Mellin inversion A_B(T)=(1/2pi i)int_(c)Gamma(z)T^z D_C(1+z) dz, shifting to Re z=−eta; cross only the Gamma pole at0. On Re z≥−eta, Ad argument Re(1+2z)>1/2 with entire automorphic adjoint L, zeta denominator argument Re(2+4z)>1 and hence no poles or zeros, and all finite local factors are regular (poles at Re(1+z)=1/2), while Gamma decays exponentially. This rigorously removes smoothing as a diagonal issue, not the long offdiagonal issue.

## 586. Fisher radical field has Galois group W(D4), independently detected at p=277

Use the quartic F(X)=−68080X^4+5022152X³+78752736X²+328707072X+366245639, quadratic Q(X)=9990323700X²+64402927670X+87197738503, and integer C=−2578645*31*1438439174552471 from the previous exact Fisher pairing. Let H0 be splitting field of F; its group is S4 by entry573; let H=H0(sqrt(CQ(r_i)) for four roots r_i).

The exact integer resultant Res(F,Q) is a positive perfect square with sqrt = 618760813690370886881104080. Therefore product_i Q(r_i) is rational square (divide by leading(F)^2); product_i C Q(r_i) is also rational square. Thus Gal(H/H0) embeds in V0={e in F2^4: sum e_i=0}, order8.

At prime277, F splits with FOUR distinct roots r=(52,59,74,188); Q(r) mod277=(187,271,91,257), and Legendre(C,277)=+1. Their radical signs are (+,−,+,−). The prime is unramified for these radicals, so Frob277 over the identity quartic permutation gives a nontrivial 2-coordinate sign flip. Since Gal(H/H0) is S4-stable, it contains the six S4 conjugates of that pair flip; they generate all V0. Hence Gal(H/H0)=V0 and Gal(H/Q), which embeds in W(D4)=V0⋊S4, has its whole order192 and is W(D4).

The S4 commutators on V0 generate V0, so Gal(H/Q)^ab is the sign C2 of S4; thus the ONLY nontrivial abelian subfield is Q(sqrt(41*2141)). For a fixed compatible cyclotomic q=a mod B, the group of the compositum has order 96phi(B), and the eight 3cycles each have eight lifts, split four-to-four by the radical sign at the unique fixed root. Each sign-specific density is 32/(96phi(B))=1/(3phi(B)), independently of the original huge prime witnesses. The p277 certificate and the group calculations were checked by /mnt/data/bsd_fisher_d4_artin_verifier.py .

## 587. Fisher second-descent sign is an exact fixed Artin representation trace

Let L=Q(r), F(r)=0, and let psi be the quadratic character of the extension L(sqrt(CQ(r)))/L. The induced 4D finite-image representation rho_F=Ind_(G_L)^(G_Q)psi is the defining signed-permutation representation of W(D4). At any unramified rational prime q of quartic Frobenius cycle type (1,3), exactly one of its four basis lines is fixed. Hence

 Tr rho_F(Frob_q) = Legendre(CQ(r_q),q) = tau(q) in {+1,−1}.

Artin formalism gives L(s,rho_F)=L_L(s,psi), an ordinary finite-order quadratic Hecke L-function over the quartic number field L. That fixed Artin L-function is nonzero at s=1 and does not, by itself, decide whether the moving original elliptic twist L(E0^(−q),1) vanishes. This is an exact representation of the local **arithmetic Fisher sign**, not a BSD analytic comparison.

## 588. Exact orthogonality to EVERY fixed quadratic Dirichlet character

Let C0 be the set of Frobenius elements having quartic 3cycle and q=a mod B, without fixing Fisher sign, where B contains all ramified primes of H. On each one of the eight 3cycles, the eight sign vectors V0 give tau=+1 four times and tau=−1 four times. All abelian characters of Gal(H/Q), including cyclotomic restrictions, are trivial on V0.

For ANY fixed integer n>0, one gets

 lim_(X→∞) (1/pi(X)) sum_(q≤X, Frob_q∈C0) tau(q)*chi_(−q)(n) = 0.

If the quadratic field of squarefree part of n is contained in Q(zeta_B), its character is constant on the q mod B condition; the tau sum cancels. If not, the quadratic field is ramified at some prime outside B, disjoint from H Q(zeta_B), and Chebotarev averages its extra sign to zero. This is a rigorous statement for each **fixed n**. It is NOT a uniform statement for n growing with q.

Consequently the fixed-coefficient diagonal averages of the central approximate functional equation are exactly the same in Fisher tau+ and tau− thin prime classes; their positive diagonal constant is delta_C D_C(1) for both. The signed difference of first moments is

 sum_(q~X, quartic3cycle, q=a modB) tau(q) L(E0^(−q),1)psi(q/X),

and has no coefficientwise Chebotarev main term. Any successful signed first-moment comparison must therefore exploit n~q correlations/offdiagonal terms. This corrects the notion that the Fisher sign alone should force an easily visible difference in low Fourier coefficients.

## 589. The 2-adic digit of the Artin trace detects precisely the second-descent sign

For quartic 3cycles the 4D Artin trace is tau(q)=±1. Thus

 tau(q) mod2 =1 always;   (1−tau(q))/2 mod2 = 1 iff tau(q)=−1, else0.

The first mod2 trace digit is blind to the Fisher sign, but the mod4 trace determines it. This parallels the actual elliptic arithmetic controls: they have the SAME embedded 2-Selmer classes while 4-descent separates them. This is an EXACT arithmetic observation. It does NOT establish a congruence of mod4 Artin-trace digits with the normalized Waldspurger coefficient; such a congruence would be the missing arithmetic-to-analytic input.

If g is a weight3/2 Waldspurger form and theta=1+2sum_(m≥1)q^(m²), then G=g*theta has weight2 and G≡g mod2 coefficientwise; but theta≠1 mod4. For example the q² coefficient is altered by 2b_g(1). Therefore one cannot automatically identify b_g(q)/2 mod2 (needed if b_g(q) is even) with coefficients of an integral-weight form through the same theta multiplication. Moreover half-integral weight T_(ell²) Hecke recurrences preserve each squarefree index class, so b_g(31)≠0 does not force b_g(631)≠0.

The limited finite criterion of entry585 remains conditional: one must compute an appropriately saturated Waldspurger coefficient mod2 and its finite-Galois class function, then find a joint Frobenius class with Fisher tau+ and nonzero coefficient. Nonzero complex b_g(31) does NOT establish its mod2 nonvanishing. Any other claim needs a fresh actual coefficient computation.

## 590. Normal-subgroup barrier for semisimple residual two-dimensional modular data

Let G=W(D4)=V0⋊S4 and let z=(1111,id), the central simultaneous sign flip. Every nontrivial normal subgroup K of G contains z. Indeed, if K∩V0 is nonzero it is S4-stable and contains z: an even nonzero 4-bit vector has weight2 (whose S4 orbit spans V0) or weight4 (z). If K∩V0=0, normality makes K centralize V0, but the S4 action on V0 is faithful, so K⊂V0, contradiction.

The Sylow2 subgroup of G is NONABELIAN (it contains a Sylow D8 from the S4 factor). Each GL2(F_(2^f)) has an abelian elementary-2 Sylow subgroup (upper unipotents). Therefore the compositum F_sem of any FINITE collection of ordinary two-dimensional semisimplified mod2 Galois representation fields and any cyclotomic field has abelian Sylow2. The group G cannot be a quotient of Gal(F_sem/Q), so H is NOT contained in F_sem. The intersection J=H∩F_sem is proper Galois. Its normal kernel Gal(H/J) is nontrivial and must contain z. Hence there is an automorphism of H F_sem acting by z on H and trivially on F_sem.

At quartic 3cycle Frobenius, multiplication by z flips tau while retaining all semisimple 2D residual Galois data and every fixed congruence in F_sem. Therefore NO FINITE SET of such semisimplified residual traces and abelian characters can distinguish the two Fisher signs on all primes of the selected type; Chebotarev gives paired positive-density classes with the same data but opposite tau. This does not rule out a mod2 coefficient of an arbitrary NON-EIGEN modular form: generalized Hecke eigenvectors may involve nilpotent congruence/extension information not captured by finite collections of semisimple 2D residual traces. In particular, DO NOT automatically apply this barrier to g*theta without proving its requisite Hecke semisimplicity.

## 591. Source check and actual remaining all-E/Q target

Chida–Wakatsuki, Research in Number Theory (published 16 June2026), proves prime-discriminant nonvanishing for SPECIFIC modular forms of weights8 level2 and4 level6. The published Theorems1.2–1.3 do NOT cover this weight2 elliptic newform E0; no transfer of their theorem is asserted. Likewise ordinary Goldfeld-density results over all squarefree twists say nothing about this thin prime subclass. The OpenAI 2026 general 2-converse preprint claims a solution to low corank but the project's direct partial reading did not independently verify its novel integral interpolation; it is NOT imported as an established fact here.

The strongest current closed finite arithmetic result remains tau+ : MW rank0, full 2-primary Sha=(Z/2)^2, exact W(D4) Fisher-sign Artin representation; tau− : same 2-Selmer, vanishing Cassels pairing, 4-Selmer lifts, rank not decided. The strongest fresh analytic result is strictly positive, power-saving calculable first-moment DIAGONAL constant for each exact thin prime class. The missing implication is the long offdiagonal cancellation or a valid finite residual Waldspurger nonvanishing congruence for the same tau+ class. Neither is proved. General BSD rank equality for ALL elliptic curves over Q remains open.

Files produced this pass (standard library, executed): /mnt/data/bsd_fisher_d4_artin_verifier.py and /mnt/data/bsd_fisher_artin_orthogonality.py . All earlier exact arithmetic certificates and counterexamples remain unmodified.

---

# CONTINUATION 2026-11-21 — EXACT TWIST L-VALUES, KATO CONTROL, AND FISHER-SIGN REPRESENTATION OBSTRUCTIONS

The original full target remains: for *every* elliptic curve E/Q prove or refute rank E(Q)=ord_(s=1)L(E,s). These entries do not claim that conclusion. Retain all supplied rigorous central intervals and exact Fisher calculations from entries555–591, including −23 point origin, −31 nondegenerate 2-Cassels pairing, and −1303 degenerate 2-Cassels pairing with analytic rank zero. Earlier candidate numerical ratios were not assumed exact until the integrality argument below.

## 592. Certified algebraic-integral quadratic-twist values: A31=A631=...=24, A1303=864

Let E0:y²=x³−28x+1. Its minimal discriminant is Δ=16·87781=2^4·41·2141, and its conductor N=2²·41·2141=351124: Tate's algorithm at 2, using y'=y−1 and local coefficients (a1,a2,a3,a4,a6)=(0,0,2,−28,0), gives Kodaira IV and conductor exponent2; at41 and2141 the type is I1. E0 has no rational 2-isogeny because X³−28X+1 is irreducible over Q (rational roots must be ±1, neither works). By Mazur's prime-isogeny theorem, every other possible isogeny degree is in {3,5,7,11,13,17,19,37,43,67,163}. For each such degree ℓ we have a good Frobenius prime p with a_p²−4p a nonsquare modulo ℓ:

 ℓ: 3 5 7 11 13 17 19 37 43 67 163
 p: 5 3 11 3 5 3 11 5 17 5 11
 a_p: −1 −3 1 −3 −1 −3 1 −1 −4 −1 1.

Hence E0 has no nontrivial Q-rational cyclic isogeny; its isogeny class contains one Q-isomorphism class, so it is the X0(N)-optimal curve. Cremona's computations prove the optimal Manin constant to be c0(E0)=1 for conductors below400000 (https://johncremona.github.io/ecdata/ , Table8). This is explicit published computational input, not an independently reconstructed modular parametrization.

Wiersema–Wuthrich, *Integrality of twisted L-values of elliptic curves*, Documenta Mathematica 27 (2022), Theorem2(b), https://ems.press/journals/dm/articles/13131892 : if c0=1 and a primitive quadratic χ has conductor prime to every additive bad prime of E0 (only2 here), then its normalized motivic value L(E0,χ,1)*cond(χ)/(τ(χ)Ω_χ(E0)) is in Z. For χ_{−q} with q≡7 mod8, q∤2·41·2141, the Gauss sum and imaginary period imply, up to the fixed sign, A_q=√q L(E0^(−q),1)/|Ω_−(E0)|∈Z.

Three real roots e1>e2>e3 of x³−28x+1 give a rigorous period formula
  |Ω_−| = 2 K((e1−e2)/(e1−e3))/√(e1−e3)
             = π/[√(e1−e3)*AGM(1,√((e2−e3)/(e1−e3)))].
Interval arithmetic yields |Ω_−|=1.137250612476591962412818992540... . The standard-library script `/mnt/data/bsd_twist_exact_values_verifier.py` uses signed integer bisection of the roots, rigorously bounded alternating arctan series for π, floor/ceil fixed-point interval arithmetic (scale 10^45), and arithmetic-geometric mean lower/upper bounds to enclose Ω_−. It then combines the USER-SUPPLIED independently certified L-value enclosures with √q to give:

 q=31:     A_q in (23.9997564,24.0002460)
 q=631:    A_q in (23.9998328,24.0000537)
 q=647:    A_q in (23.9998111,24.0002586)
 q=1231:   A_q in (23.9998089,24.0004260)
 q=1439:   A_q in (23.9986552,24.0013240)
 q=1663:   A_q in (23.9677014,24.0322465)
 q=1303:   A_q in (863.9996422,864.0002772).

Because A_q is an integer, these certify the EXACT equalities
 A_31=A_631=A_647=A_1231=A_1439=A_1663=24, A_1303=864.
In particular A_1303/A_31=36 is now an exact theorem, superseding entry593's numerical candidacy. No appeal to refined BSD or to arithmetic Sha sizes entered this argument. The script does not re-evaluate the expensive original Mellin intervals: they remain explicit user-supplied hypotheses/certificates; it rigorously verifies the *integer deduction* from them.

## 593. Exact refined-BSD analytic slots, and verified 2-part equality in six cases

For q≡7 mod8, D=−q is a local square at2, so E^(−q) has the same Kodaira IV and split c2=3 as E0. Its original I1 primes41,2141 remain I1 (q matches prescribed local squareclasses there). At q the ramified twist of a good curve is I0*, and c_q=1 because q is inert in the cubic 2-division field (the three geometric 2-torsion nonidentity points form one Frobenius orbit). The product of finite Tamagawa numbers is therefore3.

The twist still has three real cubic roots; its total real Néron period is 2|Ω_−(E0)|/√q, because its real locus has two components. Direct reductions at good small primes3,5,7,11 show that rational torsion is trivial in each of the seven listed cases (their finite-field point counts have gcd1; exact script supplied). Thus
  L(E^(−q),1)/(Ω(E^(−q))·prod_v c_v) = A_q/6,
  = 4 for q=31,631,647,1231,1439,1663;
  = 144 for q=1303.
These are exact numbers on the **analytic side of the refined rank-zero BSD formula**; equality with |Sha| is a separate arithmetic assertion. The Fisher second descent (previous entries) proved |Sha[2∞]|=4 for every one of the six + cases. Consequently the 2-primary valuation of the refined BSD formula is verified unconditionally on all six cases: v2(A_q/6)=v2|Sha|=2.
For q1303 the exact analytic slot 144=2^4·3² and finite rank-zero Sha[2∞]=(Z/2^e)^2 with e≥2. The 2-primary refined formula predicts e=2 (Sha2 size16), and the 3-primary refined formula predicts 3-group size9; neither is asserted proved. An 8-descent and 3-descent remain separate finite arithmetic tests.

## 594. Full p-adic GL2 images from a single I1 prime, and Kato bounds away from the new additive prime

Lemma: Let H be a closed subgroup of GL₂(Z_p) with irreducible residual action, surjective determinant and containing every element I+tN (t∈Z_p) of one nonzero rank-one nilpotent matrix N. The residual irreducibility supplies h∈H moving the fixed line of N. The two one-parameter unipotent subgroups U_N(Z_p), U_(hNh⁻¹)(Z_p) are opposite full root subgroups in a basis of their fixed lines and generate SL₂(Z_p). Full determinant then gives H=GL₂(Z_p).

Every E0^(−q) in the list has no rational ℓ-isogeny, because twisting by a scalar quadratic character preserves subspaces of E0[ℓ]. Thus E0^(−q)[p] is irreducible for every p. At primes41,2141 the minimal discriminant valuation is1 and the local twist character is unramified/split. Tate uniformization gives full Z_p tame-transvection inertia from either multiplicative prime ℓ≠p; at p=41 use ℓ=2141, and at p=2141 use ℓ=41. The cyclotomic determinant is onto Z_p^×. Thus the whole p-adic image is GL₂(Z_p) for every odd p (indeed the same reasoning extends to2, without using it in Kato's theorem).

Kato's rank-zero upper bound, as explicitly stated for all p>2 with E good/multiplicative at p and full p-adic image in Sage's Sha_tate documentation (https://doc.sagemath.org/html/en/reference/arithmetic_curves/sage/schemes/elliptic_curves/sha_tate.html), gives
  v_p |Sha(E^(−q))| ≤ v_p[L(E^(−q),1)|E(Q)_tors|²/(Ω·prod c_v)]
for p>2 not equal to the new additive prime q. Because the seven twists have analytic rank0, Sha is finite by Gross–Zagier–Kolyvagin. Hence:
- For q=31,631,647,1231,1439,1663, Sha[p∞]=0 for EVERY odd p≠q.
- For q=1303, Sha[p∞]=0 for EVERY p≥5 with p≠1303; and |Sha[3∞]|≤9, so its 3-primary part is either 0 or (Z/3)² by finite alternating Cassels–Tate duality.
The q-primary part remains UNSUPPLIED by this Kato result because E^(−q) has additive reduction at p=q. In particular the full refined BSD formula is not obtained. This is a genuine reduction of the arithmetic 3-descent question at1303 to one bit (whether Sha[3] is zero).

## 595. The four-dimensional Fisher Artin representation is dimension-minimal in characteristic zero

Retain G=W(D4)=V0⋊S4 with V0={(ε1,...,ε4)∈F₂⁴: Σ εi=0} and central z=(1111). The four signed radicals of the Fisher quartic form its standard faithful 4-dimensional signed-permutation representation ρ_F; at quartic 3cycles, Tr ρ_F(Frob_q)=τ(q) (entries586–587).

Theorem: Over ANY characteristic-zero field, every finite-dimensional G-representation on which z acts nontrivially has dimension at least4. Proof: after scalar extension to algebraic closure, restrict to the abelian group V0 and decompose into one-dimensional ±1 characters. Its character group V0^* is F₂⁴ / <1111>. Under the S4 action, the eight characters have orbits: trivial orbit size1; three pair-subset characters orbit size3; four singleton-subset characters orbit size4. Evaluation on z is +1 for the first two orbits (representatives have even subset cardinality) and −1 precisely for the size4 singleton orbit (odd subset cardinality). The multiset of V0-weight characters of any G-representation is S4-stable, so z can act nontrivially only if all four singleton characters occur, requiring dimension≥4. The constructed ρ_F attains equality.

Consequently NO direct sum of honest characteristic-zero 1D,2D or3D finite-image Artin representations can capture the Fisher sign; a 4D Artin constituent or genuine nonsemisimple deformation structure is necessary. This is an exact group-theoretic obstruction, not a theorem about the original elliptic L-function.

## 596. Even first- and second-order one-variable mod-two 2D deformations miss the central Fisher sign

Take k a characteristic-two field and the natural V=k² representation of S3=GL₂(F₂), pulled back from S4→S3. Let A=k[ε]/(ε²), and suppose ρ~:G→GL₂(A) reduces to this representation modulo ε. For v∈V0 write ρ~(v)=I+ε L(v), so L:V0→End_k(V) is k-linear and S4-equivariant. Let v=x12=e1+e2, z=e1+e2+e3+e4, and h=(13)(24) in the Klein-four kernel of S4→S3. Then h v h⁻¹=x34=v+z, but ρ~(h) reduces to the identity. Conjugation therefore acts trivially on first-order matrices and gives L(v+z)=L(v), hence L(z)=0. In particular ρ~(z)=I modε². Thus a first-order 2D modular/Galois deformation of this residual type cannot distinguish the two radical signs.

There is a further one-parameter strengthening. Over k[ε]/(ε³), reduce modulo ε² and use S4-equivariance. An elementary calculation (standard-library checker `bsd_wd4_residual_verifier.py`) shows that Hom_(k[S4])(V0,End_k(V)) is one-dimensional. With basis b0=(1100),b1=(1010),b2=(1001), a nonzero generator sends them to
   T0=[[1,1],[0,1]], T1=[[1,0],[1,1]], T2=[[0,1],[1,0]],
up to a common scalar. All three satisfy Ti²=I. But for a group element v of order2, (I+ε L(v)+ε² B(v))²=I+ε² L(v)² moduloε³, forcing L(v)²=0. The unique nonzero L is impossible: L|V0 must be0. Then ρ~(v)=I+ε² B(v), while ρ~(h)=I+O(ε). Since z=[h,v], its image is I moduloε³. Thus even a one-parameter length-three dual-number lift does not see z.

Scope caution: This does NOT rule out higher-order deformations, several independent nilpotent weight parameters, dimensions≥4, or genuine modular Hecke algebras with extension/nilpotent structures. Indeed the preceding obstruction predicts the extra structure needed to detect the sign. It is not a reason to declare an analytic nonvanishing proof impossible.

## 597. The precise arithmetic–analytic target after the new exact controls

The prime q=1303 has same embedded Sel₂ and vanishing first Cassels pairing as q=−23 (with points) but analytic rank0, whereas q=31 and631 have nondegenerate first Cassels pairing and analytic rank0. The exact values now satisfy A_1303=36 A_31 and A_631=A_31, not merely approximately. If a single Waldspurger packet with identical nonzero local factors supports these fundamental discriminants, the general Waldspurger square relation gives |b(1303)/b(31)|=6 and |b(631)/b(31)|=1 for its half-integral Fourier coefficients, after consistent normalization. Such a packet must first be constructed/verified; no mod-two congruence between b(q) and the 4-dimensional Fisher Artin trace follows automatically. The dimension-minimal and low-order deformation obstruction shows why using only ordinary semisimplified 2D residual Galois traces does not suffice. A genuinely 4D or higher nilpotent integral modular realization, or a uniform long prime-twist first-moment estimate on a fixed W(D4) Frobenius class, is still required to prove infinitely many nonzero central values in the precise Fisher prime family.

The integrality theorem does give an unconditional quantization for ALL primitive q≡7 mod8 away from 2·41·2141:
  L(E^(−q),1) either 0 or has |L(E^(−q),1)|≥|Ω_−|/√q,
with nonnegativity at root-number-positive twists supplied by the Waldspurger square formula. This gap does not overcome the existing off-diagonal cancellation problem. Nothing here proves or refutes unrestricted BSD rank equality for all E/Q.

New files (no installations): `/mnt/data/bsd_twist_exact_values_verifier.py` (exact fixed-point rational interval arithmetic and finite Galois Frobenius checks), `/mnt/data/bsd_wd4_residual_verifier.py` (complete F2 linear map enumeration, W(D4) character orbits). Existing scripts and original records retained unchanged.

## 598. Exact finite higher-descent discriminator for the q=1303 control

The user supplied a rigorous nonzero central L value for E^(−1303) and a zero Cassels pairing on the common rank-two Sel₂ space, while the original q=−23 control has the SAME Sel₂ and first pairing but rank2. Rankzero of E^(−1303) and finiteness of Sha give Sha[2∞]=(Z/2^e)^2 for e≥2. Its Sel₄ is therefore (Z/4)^2. Let u,v be any primitive symplectic basis for Sha[4] (equivalently, the Sel₄ group since E(Q)=0), and consider the original Cassels–Tate pairing restricted to this subgroup, NOT just the first Cassels pairing on Sel₂.

In the standard symplectic presentation of (Z/2^e)^2 the pairing of its generators is 1/2^e modulo Z. The 4-torsion generators are 2^(e−2) times the original basis, so their pairing is
   2^(e−4) mod Z.
Consequently the exponent of the IMAGE of the pairing Sha[4]×Sha[4]→Q/Z is
  4 if e=2; 2 if e=3; 1 if e≥4.
This is invariant under changing the primitive basis because the symplectic determinant of a basis change is odd. Therefore one verified 4-Selmer-level pairing with value of exact order4 would prove e=2 and hence Sha(E^(−1303))[2∞] exactly (Z/4)^2. This is an explicit finite arithmetic target and is potentially simpler than separately enumerating Sel₈→Sel₄. Conversely, a vanishing 4-level pairing would imply e≥4, not e=2. The original first pairing vanishes for EVERY e≥2 and cannot decide.

The exact analytic slot A_1303/6=144 has 2-adic valuation4, so e=2 is exactly the case in which the 2-primary refined BSD valuation holds. No theorem identified that valuation with the 4-level Cassels pairing in this run, and no actual 4-lift quadrics were fabricated. Analytic rank equality zero for this curve is already proved from the user's L interval; the higher-descent question is about the refined coefficient/Sha, not a missing rank-zero converse.

## 599. Compact quartic field and its norm-square structure (2026-11-21)

New user-supplied reduced 2-covering quartics are G1=(-16,-24,24,8,-1), G2=(-4,16,12,-28,3), G3=(-4,8,60,64,15), coefficient order s^4,s^3t,s^2t^2,st^3,t^4. The first two changes of variables M1=[[-115,29],[12,-11]], M2=[[107,-132],[3,26]] satisfy the exact polynomial identities F_i(M_i(s,t))=m_i^4G_i(s,t), m1=917, m2=3178 (independently checked by symbolic integer expansion). The third identity is retained from the user's certificate, without fabricating the omitted large F3 coefficients. The new user-supplied local Cassels pairing is the Legendre symbol of r(3r+1) at q, where r is the unique root of G1(X,1) modulo a cubic-inert good prime q; q=31,631,... give -1 and q=1303,983,1567,... give +1. The user also supplies exact rank0 and rank2 analytic/rational certificates for the fourteen eligible primes q<=1663.

Put G(X)=-16X^4-24X^3+24X^2+8X-1 and L=Q(r), G(r)=0. Its exact discriminant is 2^12*41*2141. The Vieta norm identities are
 Norm_L/Q(r)=G(0)/(-16)=1/16,
 Norm_L/Q(3r+1)=3^4 G(-1/3)/(-16)=25/16,
 Norm_L/Q(r(3r+1))=25/256=(5/16)^2.
Here G(-1/3)=-25/81. Thus the product of four radical conjugates sqrt(r_i(3r_i+1)) is rational up to sign, and the relative radical Galois group sits in the even sign vectors V0={(x1,x2,x3,x4) in F2^4:sum x_i=0}. The quartic has S4 Galois group by the prior exact quartic-resolvent and mod-13 irreducibility checks. At p=277 its four roots are r=123,141,174,253, and their respective Legendre signs of r(3r+1) are (-1,+1,+1,-1). This supplies a nontrivial pair-flip. The S4 orbit of the flip spans V0, so the full radical Galois group has order 2^3*24=192, i.e. W(D4). This is an independent SMALL-COEFFICIENT reconstruction of the earlier huge Fisher field result, not a new BSD case.

## 600. Extraspecial 2-group and finite theta representation

Inside W(D4)=V0 rt S4, let V4 = {1,(12)(34),(13)(24),(14)(23)} be the Klein-four kernel of S4 -> S3. Let K=V0 rt V4 (order32) and z=(1,1,1,1) in V0. For each h in V4 and v in V0, the commutator [(0,h),(v,1)] equals h(v)+v in F2^4 and belongs to {0,z}. The common V4-fixed subspace in V0 is exactly <z>, and the action of V4 induces a perfect bilinear pairing V4 x (V0/<z>) -> <z>. It follows directly that
 Z(K)=[K,K]=<z> of order2,
 K/Z(K)=(F2)^4,
 every square in K belongs to <z>.
Thus K is extraspecial of order32. Because V0 is an elementary abelian subgroup of order8, it has plus type 2_+^{1+4}. The standard 4-dimensional signed-permutation representation of W(D4) restricts irreducibly to K with z acting by -I4. More generally any char-0 representation with z=-1 has dimension >=4, since the four characters of V0 evaluating -1 on z are a single V4-orbit, hence must occur together. Ind_V0^K chi, for any one such chi, is irreducible dimension4 and realizes the finite Heisenberg/Schrodinger representation. This identifies a specific finite theta group attached to the simplified second-descent data; no global theta lift linking it to the central elliptic L-value has been constructed.

## 601. Exact Artin and original-elliptic tensor local factors

Define psi on G_L by the quadratic extension L(sqrt(r(3r+1)))/L. The four-dimensional Artin representation rho_F=Ind_{G_L}^{G_Q}psi is the signed-permutation representation just described. For an unramified prime q where G(X) has quartic factorization type (1,3), let r_q be its unique root modulo q and tau_q=(r_q(3r_q+1)/q) in {+/-1}. The signed Frobenius permutation consists of one fixed coordinate with eigenvalue tau_q and a 3-cycle whose three signs have product tau_q, since all four signs have product1. Therefore its EXACT polynomial is
 det(T-rho_F(Frob_q))=(T-tau_q)(T^3-tau_q).
In particular tr rho_F(Frob_q)=tau_q. For the original E0:y^2=x^3-28x+1 let a_q=alpha_q+beta_q and alpha_q beta_q=q. Then at good unramified q of type(1,3), with t=q^{-s},
 L_q(E0 tensor rho_F,s)^{-1}
  =[1-tau_q a_q t+q t^2]
   *[1-tau_q(a_q^3-3qa_q)t^3+q^3t^6].
This gives a FIXED degree-eight Artin-twisted L-function whose Euler factors involve BOTH the original elliptic Frobenius coefficient and the Fisher sign. Artin induction identifies its global L-series with L(E0/L tensor psi,s), with matching local factors including the ramified places. It does not equal the varying prime-quadratic twist L(E0^(-q),s): the latter's local factor at the very ramified prime q is 1. Thus trying to identify the Fisher sign with a local Euler coefficient of E0^(-q) at q is demonstrably false; the desired arithmetic-analytic relation must be global or an additional congruence.

## 602. Exact second-descent+Hecke-trace countertest on original twists

Pure standard-library point counting establishes:
 (q, Fisher tau_q, a_q(E0), a_q mod8, algebraic rank, analytic rank)
 (1303,+1,71,7,0,0),
 (983,+1,-17,7,2,2),
 (1567,+1,47,7,2,2).
The analytic and algebraic rank certificates are the user's supplied prior rigorous results; this pass independently recomputed the Fisher signs and original E0 Hecke traces. The three q have identical first Cassels pairing, common prescribed local twist squareclasses at 2,41,2141, and the same a_q(E0) modulo8. Nevertheless E0^(-1303) has nonzero central value while E0^(-983),E0^(-1567) have double central zeros. This is an ACTUAL elliptic counterexample to any purported criterion for central nonvanishing depending only on the first Cassels pairing, original local squareclasses, and a_q(E0) mod8. It is not a counterexample to BSD. The comparison (q31,tau=-1,a31=-7) vs (q359,tau=+1,a359=9) also shows that a_q mod16 alone does not determine the Fisher sign.

## 603. Candidate integral Waldspurger--Heisenberg congruence, exact predicted mod-four digit

Choose and VERIFY (not yet done) a single weight-3/2 Waldspurger packet g for the fixed original E0 covering the fundamental discriminants D=-q in the prescribed local sector; choose a coefficient prime above2, a saturated coefficient lattice, and scale so b(31)=1. Under a matching local Waldspurger normalization with the same local factor across q, the supplied exact normalized central values imply b(31)=+-1, b(631)=+-1, b(1303)=+-6, and b(q)=0 for q in {23,359,863,911,983,1567,1607}. These are RELATIVE coefficient predictions subject to the common-packet matching, not unconditional Fourier coefficient claims. Together with the compact Fisher signs, all available controls agree with the candidate congruence
 b(q) == (1-tau_q)/2  (mod2),
 equivalently 2*b(q)+tr rho_F(Frob_q) == 1 (mod4),
 at quartic type(1,3) q in the fixed local sector.
If a valid integral coefficient packet exists and this congruence is proved, then b(q) is odd at every tau_q=-1 prime and Waldspurger gives central nonvanishing for the full positive-density NONABELIAN Fisher Chebotarev class, without a density-one squarefree argument. This is a direct all-prime arithmetic-to-analytic sufficient bridge. It is NOT proved: merely identifying the common finite Heisenberg representation does not construct the global modular congruence. Ken Ono's published method produces nonvanishing for twists by products of an EVEN number of selected primes; it does not directly deliver this one-prime conclusion. The coefficient-lattice and local test-vector issues remain essential. The tau=+1 class contains BOTH rank-zero and rank-two controls, so no stronger converse b(q)=0 iff tau_q=+1 is possible.

## 604. Failed local fourth-power-residue shortcut for q=1303 and exact cohomological boundary

One attempted replacement for the 4-Selmer-level Cassels--Tate calculation was to refine the Legendre value tau_q=+1 to an order-four residue character of r_q(3r_q+1), hoping to detect exponent e of Sha(E0^(-1303))[2^infty]=(Z/2^e)^2, e>=2. It fails at the finite-field level: every eligible q is 7 mod8, so v_2(q-1)=1, and because q^2+q+1 is odd, also v_2(q^3-1)=1. Hence neither F_q^times nor the inert cubic residue field F_(q^3)^times has any order-four character; a canonical quartic-residue refinement of the Fisher unit symbol does not exist there. This does NOT exclude unramified order-four characters of Q_q^times (which can evaluate a uniformizer), nor deeper global 4-coverings. In fact at such a cubic-inert prime q, E0^(-q)[2] has no local Galois invariants; every E0^(-q)[2^n] has no invariants, and Weil self-duality and the local Euler-characteristic formula for q !=2 yield H^1(Q_q,E0^(-q)[2^n])=0 for all n. Therefore higher arithmetic distinction cannot be obtained just by adding a new 2-power local Selmer dimension at q. A genuine 4-cover Cassels pairing, global lifting datum, or modular theta congruence is required. For q1303, the previously identified exact finite test remains: a nontrivial 4-Cassels pairing of order4 on Sel4 would prove e=2; its numerical central value alone cannot prove that.

The full unrestricted BSD statement remains open; all these results concern the precise mechanism separating a thin prime-twist arithmetic family from the central complex L-value of the SAME original elliptic curves. No external submission, third-party downloads, installs, or expenditure occurred. Script: `/mnt/data/bsd_reduced_quartic_heisenberg.py` executes all norm/discriminant, Galois subgroup, finite sign and Hecke-trace checks using standard-library Python.

## 605. A new single-seed Frobenius nonvanishing theorem: no global Fisher/Hecke field-intersection search is needed

This refines older candidate585. Let H_c be the compact W(D4) radical field of G1(X,1) and sqrt(r_i(3r_i+1)) (entry599), and let B be an integer encoding only the FIXED local twist-squareclass filters at 2,41,2141 (and other genuinely needed fixed places). Important new ramification improvement: H_c is unramified outside {2,5,41,2141}. Indeed disc(G1)=2^12*41*2141, and at odd l outside these four primes the root r is integral and the algebraic unit d=r(3r+1) has norm 25/256, an l-adic unit. The quartic field is unramified and the quadratic radical of a local unit is unramified or split. In particular 31 is UNRAMIFIED in H_c, unlike the older large coefficient construction whose ad hoc scalar C contained a factor31.

THEOREM (conditional only on a concrete primitive integral Waldspurger coefficient). Suppose a single fixed weight-3/2 cusp form g=sum b(n)q^n with coefficients in the integers of a number field, local packet matched to E0 and the negative fundamental discriminants in the q≡7 mod8 sector, has level prime to31 and b(31) a unit at some prime ideal pfrak|2. Suppose its Waldspurger comparison at all primes in one fixed local sector has nonzero local factors and says b(q) !=0 iff L(E0^(-q),1) !=0. Then there is a POSITIVE-DENSITY set of prime q in the NONABELIAN Fisher sign-negative (nondegenerate Cassels pairing) family such that L(E0^(-q),1) !=0, and thus both algebraic and analytic ranks are zero.

PROOF: multiply g by unary theta θ=1+2sum_(m>=1)q^(m²), obtaining an algebraic-integral-coefficient, integral-weight-2 modular form G=gθ on a fixed congruence subgroup. Mod pfrak, G≡g coefficientwise, so a_31(G)=b(31) !=0 mod pfrak. Standard mod2 Hecke finite-Galois theory gives a finite Galois extension F_g/Q and a conjugacy class function φ on its Galois group whose value at Frob_q is a_q(G) mod pfrak, for primes away from a fixed finite set; this must be checked/implemented for the specific g but is a standard integral-weight modular input. Fix the compositum F_g H_c Q(ζ_B), and choose sigma=Frob_31 in it (well-defined because 31 is unramified in each factor under the level and B assumptions). Its projections simultaneously retain the local squareclasses, the Fisher sign tau_31=-1 (r31=3, r(3r+1)=30=-1 mod31), and φ(sigma)!=0. Chebotarev supplies a POSITIVE-DENSITY set of primes with Frobenius conjugate to sigma. Every such q satisfies the Fisher rank-zero certificate and has b(q)!=0 mod pfrak, hence L(E0^(-q),1)!=0. This is a genuine finite-seed criterion for infinitely many primes and DOES NOT presume that squarefree density-one results cover prime supports. It also needs no global congruence b(q)≡(1−tau_q)/2 for every class: a single nonzero seed gives its own compatible class automatically.

Exact missing gate: the project has proved b(31)!=0 via the original L interval, but has NOT constructed the matched integral Waldspurger packet and proved b(31) is a 2-adic UNIT in its primitive coefficient lattice. The equality A31=24 alone does not normalize that coefficient at2: the local Waldspurger constant and integrality index matter. If b(31) is divisible by2, multiplying g by θ only preserves coefficients MOD 2, and the above reduction does not apply. The fixed packet must also be chosen with level prime to31. Nonzero is not the same as unit. The earlier global finite-field compatibility puzzle is replaced by a SINGLE specific primitive-coefficient verification.

## 606. Conditional equivalence of Waldspurger coefficient valuation and the 2-primary Sha exponent in rank zero

Retain a rank-zero twist E0^(-q) with trivial rational torsion, the same Tamagawa product3, 2-Selmer dimension2, and finite Sha. The finite 2-primary group is (Z/2^e)^2 with e>=1, so v2|Sha|=2e. Let A_q=sqrt(q)*L(E0^(-q),1)/Omega_- and assume the 2-PRIMARY PART of the refined rank-zero BSD coefficient formula for this particular q, not all BSD. As the exact analytic slot is A_q/6, this assertion gives v2(A_q)=1+2e. The baseline q31 has A31=24 and e31=1. If the fixed Waldspurger packet also has matching unvarying local factors so that b(q)^2/b(31)^2=A_q/A31, then
  v2(b(q)/b(31)) = e−1.
Thus b(q)/b31 is a 2-adic unit precisely when e=1 (the first Cassels pairing is nondegenerate), while q1303 with e>=2 has an even relative coefficient. This explains the numerically observed parity table and pinpoints the conjectural arithmetic-analytic comparison it encodes. It is conditional on BOTH the exact Waldspurger local normalization and the 2-primary refined BSD formula; it is NOT an independent proof of either. In particular it cannot be used circularly to prove b31 a 2-adic unit. It also does not assert that a primitive integral g exists with the chosen b31 normalization.

## 607. Direct failure of the one-prime fourth-power residue higher-descent shortcut

For every eligible q≡7 mod8, v2(q−1)=1 and v2(q³−1)=1. Therefore units in both F_q and F_(q³) have no order-four multiplicative characters. The 4-Selmer and 8-Selmer behavior of the q1303 rank-zero twist cannot be read from a universal fourth-power-residue symbol of r_q(3r_q+1) at q. At cubic-inert q the local 2^n-torsion G_Qq-invariants of E0^(-q) vanish: reducing any nonzero invariant to order2 contradicts the irreducible local cubic Frobenius. Weil self-duality and the local Euler-characteristic formula for q!=2 then give H1(Q_q,E0^(-q)[2^n])=0 for every n>=1. This does not make the q-term of the Fisher Hilbert symbol vanish (choice of local point and global Brauer invariant still matters). It says a proper 4-Cassels pairing calculation necessarily involves a GLOBAL lift/construction, rather than just a new local order-four residue character on the inert cubic residue field. The exact unresolved q1303 test from entry598 remains the order-four value of the Cassels pairing on its actual 4-Selmer classes.

## 608. A much denser compact Chebotarev family, using only the truly bad local modulus

All THREE small quartics G1,G2,G3 have the SAME discriminant 2^12*41*2141, checked by the exact Sylvester resultant. Let B=8*41*2141=702248, phi(B)=4*40*2140=342400. The compact W(D4) field H_c of entry599 has abelianization C2 and maximal abelian subfield the quadratic discriminant field Q(sqrt(41*2141)); this is contained in Q(zeta_B). Therefore the compositum of H_c and Q(zeta_B) has Galois group the fiber product W(D4) x_C2 (Z/B)^times of order (192/2)*phi(B)=96 phi(B). This is exact; the 5-adic ramification of H_c does not enlarge its abelianization.

Fix any residue a mod B with positive 41*2141 discriminant character, and impose the cubic-inert (S3 3-cycle) condition. In the fiber of W(D4) over the selected cyclotomic residue, there are 12*8=96 elements. Exactly 8*8=64 project to a quartic 3-cycle (type1+3); among the eight even radical sign vectors for each such cycle, precisely four give tau=-1 at its unique fixed root and four give tau=+1. Hence both signs occur with *exact natural prime density*
  32 / (96 phi(B)) = 1/(3 phi(B)) = 1/1,027,200.
This is a sizable strengthening of the older arithmetic Chebotarev construction which fixed a huge modulus M just to maintain all old local symbol choices. IMPORTANT SCOPE: the density theorem itself is unconditional. Turning every prime counted here into a curve with exactly the COMMON Sel2 and one-prime Fisher pairing still relies on the user's NEW simplified admissibility theorem asserting that q≡7 mod8, the prescribed squareclasses at41,2141, and cubic inertness are sufficient to eliminate all other local Hilbert symbols (including the primes that divided old changes of variables). If additional fixed-place conditions are in fact needed, replace B by their common modulus; the same group calculation applies after checking the new cyclotomic intersection, and the original huge-M family remains preserved. Choose a=31 mod B for the one-seed analytic route605: q31 is unramified in the compact field, has tau=-1 and satisfies the original bad-place conditions. The precise remaining analytic input is still a 2-adically primitive coefficient b(31) of the MATCHED integral Waldspurger eigenform; the new density does not prove that unit condition.

## 609. Three tiny binary quartics are the original E^(−q) 2-coverings: complete invariant and rank criterion

For a binary quartic G(s,t)=a s⁴+b s³t+c s²t²+d st³+e t⁴, define I=12ae−3bd+c² and J=72ace+9bcd−27ad²−27eb²−2c³. Exact arithmetic gives for EACH G1,G2,G3 supplied in this turn
 I(G_i)=1344, J(G_i)=1728,
 discriminant(G_i)=[4I³−J²]/27=2^12*41*2141.
For qG_i, the invariants become I'=1344q² and J'=1728q³. The standard Jacobian of a binary quartic y²=qG_i is Y²=X³−27I'X−27J'; changing X=36x,Y=216y makes it EXACTLY
 E^(−q): y²=x³−28q² x−q³.
This proves all three small quartic covering curves have the original elliptic quadratic twist as their Jacobian, without recovering the huge coefficient equations or using an unknown isogeny. The three nonzero 2-Selmer classes are those specified by the user. Under the given two-dimensional Sel2 hypothesis with E^(−q)(Q)[2]=0, the rational rank is exactly2 if ANY TWO independent one of these three quartics qG_i(s,t)=z² have nonzero rational projective solutions: these two rational points make the two Selmer classes Kummer, so the rank is at least2; Sel2 dimension2 bounds it above by2. Conversely when rank2 every Sel2 class is Kummer and all three quartics have rational points. Thus the rank2 arithmetic problem on this family has an exact two-covering solubility criterion, not merely a heuristic local signal.

As an exact check of the user's new reduced certificates at q=1567:
 G2(255,124)=1567*3102²,
 G3(−447,349)=1567*6063².
Therefore the 2-covering equations z²=1567*G_i have rational points with z=1567*3102 or z=1567*6063, respectively. Their Selmer classes are independent, so rank E^(−1567)(Q)=2 independently of its analytic L'' certificate. The analytic rank2 certificate remains an independent input. This reduction is available for every admissible q, but a rational point on one quartic is not guaranteed by the vanishing of the first Cassels pairing, as q1303 shows.

## 610. The minimum order of a Cassels--Tate dual obstruction for q=1303

Suppose, as established for the analytic-rank-zero E0^(-1303), that the finite 2-primary Sha is symplectically (Z/2^e)^2, e>=2. Let alpha be any nonzero element of Sha[2]. Choose a symplectic basis (x,y), with <x,y>=1/2^e in Q/Z, and alpha=2^(e-1)(a x+b y), at least one of a,b odd. For beta=cx+dy, <alpha,beta>=(ad−bc)/2 modZ. This is nonzero iff ad−bc is odd. In that case at least one of c,d is odd, hence beta has EXACT order2^e; conversely such beta exists by choosing complementary primitive coordinates. Thus every nonzero alpha in Sha[2] pairs nontrivially with some full-order class beta, and NO element of order<2^e pairs nontrivially with alpha. This is the exact higher Cassels/Brauer-Manin distinction: at q1303 the first pairing restricted to Sha[2] vanishes, but an obstruction from a higher class must exist because full Sha is finite/nondegenerate. The minimal possible order of a detecting dual class is2^e, unknown beyond e>=2; for q31 e=1, first 2-Selmer classes suffice. This does not itself construct beta or calculate e; it proves why repeated low-level pairing computations may keep vanishing before the first genuinely detecting level. The user-supplied rational rank0 and analytic rank0 for q1303 and rank2 for q983/1567 remain independent controls.

## 611. Quantization of the Waldspurger relative coefficient (conditional on rational packet)

Assume a fixed, correctly locally matched weight3/2 form g has RATIONAL coefficients at the relevant fundamental discriminants, with b(31)!=0, and that the Waldspurger local factor is constant across the admissible q. Then A_q/A31=(b(q)/b31)^2. The published integrality theorem and exact baseline give A31=24 and A_q in Z for all such q. Write b(q)/b31=u/v in lowest terms. Since A_q=24u²/v² is integral, v² divides24 and hence v=1 or2. Consequently A_q/6=(2u/v)² is an INTEGER square and all admissible analytic rank-zero values are of form 6k_q². This is a square-quantization statement CONDITIONAL on the rational and equal-local-factor packet (not derived just from Wiersema--Wuthrich integrality). The exact controls give k31=k631=...=2 and k1303=12, and k=0 for analytic rank-two primes. The possibility v=2 corresponds to an odd k and would prevent choosing b31 a 2-adic unit in the full integral coefficient module. Excluding v=2 uniformly is exactly the extra 2-adic primitivity problem of entry605; it is not supplied by the ordinary integrality theorem or by the first Cassels pairing. Under the additional 2-part refined BSD formula at rank zero, v2(b(q)/b31)=e_q−1, as established in entry606. The theorem is not being used to prove BSD circularly.

## 612. The compact Fisher Artin representation contains the original E0[2] as its middle residual graded piece

Let E0:y²=x³−28x+1, with cubic f(X)=X³−28X+1, discriminant 87781=41·2141, and let H be the project’s compact W(D4) Fisher radical field from the small binary quartic G1. The rational signed-permutation representation rho_F of W(D4) on Q^4 reduces in characteristic2 to the ordinary permutation representation V=F2^4 of S4 because all signs become +1. Let L0=F2·(1,1,1,1) and H0={(x1,...,x4):sum xi=0}. In characteristic2 L0⊂H0. The invariant filtration 0⊂L0⊂H0⊂V has successive dimensions 1,2,1. The middle H0/L0 is the natural 2D representation of S4/V4=S3, and the cubic resolvent of the quartic is precisely Q(E0[2]), hence H0/L0≅E0[2] as G_Q representations. The outer pieces are trivial. Therefore tr rho_F(Frob_l)≡a_l(E0) mod2 away from the two ramification sets. At quartic type(1,3), tr rho_F(Frob_q)=tau_q=+/-1, so (1−tr)/2 mod2 is exactly the Fisher sign bit. This is a characteristic-zero MOD-FOUR secondary trace invariant, not an established analytic or modular-symbol congruence.

## 613. Exact local elimination of the apparent Fisher ramification at 5

The old radical r(3r+1) has total norm25/256, suggesting apparent prime5 support. Modulo5 G1(X,1) factors as −(X+2)(X³+2X²+2X−2), with the cubic irreducible. The linear root lifts to r≡108 mod125; r(3r+1)/25 is a 5-adic unit congruent4 mod5, hence square in Q5. Over the unramified cubic local factor, the remaining three radical conjugates have square residue norm to F5, hence each is a square in F125 and locally in the field (the residue norm F125^×→F5^× detects quadratic character). Thus there is NO ramification at5. Since the quartic discriminant is 2¹²·41·2141 and the radical has no other odd valuation, the normal Galois closure H is ramified only at the finite set {2,41,2141}. This is a local computation, not a proof of any central L-value assertion.

## 614. Class-number 12 discriminant field and the unramified cubic E0[2] extension

Set F=Q(sqrt87781). Since f has Galois group S3 and squarefree discriminant, its splitting field M=Q(E0[2]) contains F, has Gal(M/F)=C3 and is unramified at every finite place over F: inertia at41 and2141 is generated by a transposition, disjoint from A3, and no other prime ramifies. M is totally real. The fundamental unit epsilon=74354370+250961 sqrt87781 has norm−1. Exact continued-fraction/Pell verification and the Dirichlet character period sums, with max partial sum184, bound L(1,chi_87781) between 1.52206596 and 1.52625839; the regulator is 18.8175001857623... and the class-number formula bounds 11.97<h(F)<12.05, thus h(F)=12. Genus theory shows the 2-rank is one, so Cl(F)≅C12. Hence M/F is the unique everywhere unramified cyclic cubic extension. This is verified by /mnt/data/bsd_real_quadratic_residual_cert.py, standard library only. A class-group Artin induction from this totally real M is even at infinity, not the odd representation of a holomorphic weight-one modular form.

## 615. Two copies of actual E0[2] in the extraspecial 32-group and the central Fisher sign

Inside Gal(H/Q)=V0⋊S4, the kernel of the map to Gal(M/Q)≅S3 is K=V0⋊V4, an extraspecial 2-group of plus type and order32. Its center and derived subgroup are <z> with z=1111. The quotient K/<z> is four-dimensional over F2, and as an S3-module is E0[2]⊕E0[2]. Take sign vectors u=1100,v=1010 and V4 elements a=(12)(34), b=(13)(24). The commutators [a,v]=[b,u]=z, [a,u]=[b,v]=1, with all within each of V0,V4 trivial, exhibit the perfect crossed symplectic pairing, equivalent to the Weil pairing on the two E0[2] factors. This is an ABSTRACT S3-module and central-extension identification. It does not prove H is the actual joint splitting field of the two particular global Selmer cocycles alpha1=144+23theta and alpha2=239+23theta: cocycle and local-trivialization matching remains unproved. It does not force BSD.

## 616. Monic quartic, class number one and unique quadratic ray-class field

Put u=2r in G1(r,1)=−16r⁴−24r³+24r²+8r−1. Its monic polynomial is P(u)=u⁴+3u³−6u²−4u+1, with exact squarefree discriminant 87781. Let L=Q(u); O_L=Z[u], all four embeddings real, and 2 is inert since P mod2=u⁴+u³+1 is irreducible. Minkowski gives norm bound (3/32)sqrt87781<28. Every prime ideal within the bound is principal: degree-one primes at3,5,11,19,23 have integral generators u+1,u−1,u²−3,1+2u,u+2 of absolute norms3,5,11,19,23; the degree-three prime above3 is the complementary factor of (3); (2) is principal norm16; 7 has degree2 factors norm49 and 13,17 have degree4. Thus h(L)=1.

The Fisher radicand d=u(3u+2) has norm25 and is totally positive in all four real embeddings. It is 2-integral and has only even valuations at odd primes; at5 the quadratic extension splits by the explicit local computation in613. The relative quadratic discriminant therefore divides4O_L. The ray group (O_L/4)^× has cardinality4^4−2^4=240. Global units −1,−u,−1−u+u²,−1+2u² generate subgroup with successive sizes2,30,60,120 as verified by exact mod4 multiplication. Since class number1, the ray class group modulo4 has order<=2. Since L(sqrt d)/L is nontrivial of conductor dividing4, its ray group is exactly C2 and L(sqrt d) is the unique nontrivial quadratic ray class extension. /mnt/data/bsd_fisher_quartic_rayclass_verifier.py executes all number-field integer/finitary assertions (class field reciprocity is the standard theoretical input).

## 617. Single mod-four coefficient formula for the Fisher bit; all 14 controls checked

For alpha∈O_L with odd norm, alpha^15≡1 mod2 because the residue field is F16. Let e(alpha) be the coefficient of u in (alpha^15−1)/2 mod2 (equivalently reduce alpha^15 mod4, subtract1, divide by2). The map alpha↦(−1)^e(alpha) is a multiplicative character of (O_L/4)^×, trivial on the four global units above, nontrivial at 1+2u, and hence the unique quadratic ray-class character. Let q be eligible, u_q=2r_q the unique root of P modq, and choose integral alpha_q=a+bu+cu²+du³ generating the degree-one ideal (q,u−u_q) (possible by h(L)=1). Then
 tau_q=(r_q(3r_q+1)/q)=(u_q(3u_q+2)/q)=(−1)^e(alpha_q).
The formula is invariant under multiplying alpha_q by a global unit.

Exact small norm±q generators, signs, q:
23:(−2,−3,1,1):+; 31:(0,−2,−4,−1):−; 359:(−1,7,1,−3):+; 631:(−5,−3,7,−2):−; 647:(−1,−3,3,0):−; 863:(2,6,4,−1):+; 911:(8,−4,−1,0):+; 983:(−2,9,0,0):+; 1231:(−4,3,1,−1):−; 1303:(−3,5,14,2):+; 1439:(−2,8,7,−5):−; 1567:(3,−5,−14,−1):+; 1607:(−3,0,13,−7):+; 1663:(1,−6,−1,−1):−. Each listed generator has norm±q, vanishes in the corresponding root residue, and reproduces the original Legendre symbol. All14 match the supplied analytic integers via I_q≡12e(alpha_q) mod24. THIS LAST CONGRUENCE IS VERIFIED ONLY AT THE 14 CONTROLS; IT IS NOT PROVED FOR ALL q. Proving it would give exact analytic nonvanishing on the entire Fisher-negative prime family, but no such arithmetic-to-analytic theorem has been proved. See the verifier above.

## 618. The real quadratic class group has NO abelian Fisher-sign character

The discriminant subfield F=Q(sqrt87781) has Gal(H/F)=V0⋊A4. Its abelianization is C3: the A4 commutator span [A4,V0] equals all V0 (3-cycles move weight-two sign vectors and the resulting differences span), while A4^ab=C3. Therefore the maximal abelian extension of F inside H is exactly the original unramified cubic M/F. In particular, the central Fisher sign flip z belongs to [Gal(H/F),Gal(H/F)] and is invisible to EVERY abelian Hecke character of F, even though Cl(F)=C12. Over the NONNORMAL quartic L, by contrast, it is detected by a unique quadratic ray-class character mod4. This invalidates the attempted direct real-quadratic class-group/dihedral-character proof of analytic nonvanishing, without saying anything against a more elaborate nonabelian automorphic comparison.

## 619. No characteristic-two trace factoring only through H sees z

For any finite-dimensional representation rho of W(D4) over a field k of characteristic2, the normal elementary abelian 2-subgroup V0 acts trivially on every simple composition factor (the only simple module of a finite p-group in characteristic p is trivial). Trace is additive through composition factors, so tr rho(gz)=tr rho(g) for all g; indeed traces factor through the S4 quotient. At quartic Frobenius type(1,3), multiplying by z flips tau. Therefore (1−tau)/2 mod2 is NOT the trace of any characteristic2 representation factoring exclusively through H. This does NOT exclude a modular coefficient field strictly larger than H, a nonsemisimple Hecke-algebra coefficient, or a mod4 secondary trace. It rules out the naive mod2 trace identification within the 192-element field alone.

## 620. A genuinely new eligible q=3583 arithmetic control and countertest

Exact sieve/primality and finite polynomial checks give q=3583 prime, q≡7 mod8, chi_(−q)(41)=chi_(−q)(2141)=+1, f(X)=X³−28X+1 irreducible modq, and G1(X,1) has unique simple root r_q=1325. Its Legendre radicand r_q(3r_q+1)≡1190 modq is a nonsquare, so tau=-1. In the monic quartic field L the corresponding degree-one prime is (q,u−2650); alpha_q=5−10u−11u²+9u³ has exact norm−3583 and the ray-class sign from entry617 is −1. Under the project's locally checked admissibility/2-Selmer/fisher-pairing criterion, this supplies an additional arithmetic rank-zero twist E^(−3583). NO original complex central L-value computation for q3583 has been completed here. Exact point count gives a_3583(E0)=−17≡7 mod8, while a_1303(E0)=71≡7 mod8 and tau1303=+1. Therefore the Fisher pairing sign is not determined by the original Hecke coefficient mod8, even in the shared cubic-inert/bad-local-squareclass sector. Script /mnt/data/bsd_fisher_rayclass_prime_pairs.py verifies q3583's conditions without any third-party packages.

## 621. Two opposite Fisher signs in the same full cyclotomic residue class

Let B=8·41·2141=702248. Exact primality and polynomial factorization-(1,3) checks yield the following pairs of primes, with exactly the same residue modB but opposite Fisher signs:
 - q=8427607 (q modB=631,tau=−1) versus q=30899543 (q modB=631,tau=+1);
 - q=2108047 (q modB=1303,tau=+1) versus q=35815951 (q modB=1303,tau=−1).
For each q, choose the unique root of P(u) modq and compute the sign of u(3u+2) by Euler's criterion. The cubic quotient is irreducible over F_q: exact Frobenius x^q modulo it and gcd(x^q−x,H3) give1. Deterministic 64-bit Miller--Rabin verifies all four primalities. All tests appear in /mnt/data/bsd_fisher_rayclass_prime_pairs.py and pass. The examples establish directly that no condition solely on the prescribed residue class mod B fixes the second-descent Fisher sign.

## 622. Evenness rules out the naive holomorphic weight-one lift

M=Q(E0[2]) is totally real and M/F is unramified cyclic C3. For any nontrivial order3 class-group character psi of F, its induced 2D Artin representation sigma=Ind_(G_F)^(G_Q) psi is even at infinity: sigma(c)=I2, det sigma(c)=+1, because complex conjugation fixes the totally real splitting field M. Holomorphic weight-one newforms have ODD 2D Artin representations (det of complex conjugation −1), as in Deligne--Serre; hence sigma cannot arise from any holomorphic weight-one eigenform in characteristic zero. The natural automorphic description is dihedral weight-zero Maaß, not a weight-one holomorphic theta newform. Mod2 residual isomorphism to E0[2] still holds, but it cannot be upgraded to an equality of characteristic-zero holomorphic L-functions by this shortcut. Source for the precise oddness statement: https://jvoight.github.io/articles/cmfs-mf-101222-scrubbed.pdf section11.

## 623. Universal Fisher-bit congruence impossible from only semisimple 2D mod-two Galois data

Let Fss be a finite compositum of fields cut out by two-dimensional representations into GL2(F_(2^f)), and A any finite cyclotomic extension. Each GL2(F_(2^f)) has elementary abelian Sylow2 (upper unipotent, of order2^f). Therefore Gal(Fss A/Q), a subgroup of products of such groups and an abelian group, has abelian Sylow2; every quotient inherits this property. The Fisher group W(D4) has a nonabelian extraspecial subgroup of order32 and hence nonabelian Sylow2. Thus H cannot be contained in Fss A. Put J=H∩Fss A, a proper Galois subfield. Its normal kernel Gal(H/J) is nontrivial, hence contains the central z by the explicit W(D4) normal-subgroup lemma from earlier entry590 (check: every nonzero S4-invariant subspace of V0 contains z; a normal subgroup disjoint from V0 would centralize V0, whose S4-action is faithful). Both h and hz can be paired with the SAME element of Gal(Fss A/Q) over J, and by Chebotarev occur at positive-density prime classes with identical Fss and cyclotomic Frobenius and opposite Fisher signs. Therefore no Frobenian function determined solely by these semisimple 2D mod-two fields can agree with (1−tau_q)/2 at ALL eligible prime twists. This NO-GO DOES NOT exclude a larger nonsemisimple mod2 Hecke algebra with nonabelian 2-Sylow, or a mod4 integral/extension-sensitive comparison. The previous conjectural congruence at14 controls is not promoted to a universal identity. The single-prime nonvanishing seed method from entry605 only needs a nonzero coefficient in ONE joint class and survives this obstruction.

## 624. First-order square-zero deformation cannot supply the secondary central sign

Let R be any characteristic-two local Artin ring with maximal ideal m, m²=0 and residue field k. Suppose a 2D representation rho:W(D4)→GL2(R) reduces to the natural irreducible E0[2] representation of S4/V4=S3. For v∈V0 write rho(v)=I+A(v), A(v)∈M2(m), so A is additive because m²=0. For h in the normal V4 (kernel of S4→S3), rho(h)≡I modm; hence conjugation by rho(h) is trivial on matrices I+A(v) modulo m². But choose h=(13)(24), v=1100; h(v)=v+z. Equivariance therefore forces A(v+z)=A(v), and A(z)=0. Thus rho(z)=I. This extends the prior dual-number countertest to arbitrary square-zero coefficient ideals: a first-order 2D deformation of the actual residual E0[2] cannot see the Fisher central bit. Higher-order multi-parameter nilpotents or a 4D representation remain possible and unconstructed. This is a formal representation-theoretic obstruction, not a counterexample to BSD.

### Updated full-target conclusion

The new quartic field/ray class theorem and arithmetic sign computation remove the previous 192-element technical bottleneck: the Fisher obstruction is a single mod4 digit of a principal prime generator in a totally real quartic class-number-one field. It is NOT a proof that the normalized complex central value I_q/12 has that parity. The three obstacles now have clean proofs: the real-quadratic abelian class group is blind to z; semisimple 2D mod2 Galois trace data cannot detect it throughout the eligible family; first-order 2D residual deformations cannot detect it either. A stronger nonsemisimple Hecke comparison, an exact primitive integral weight3/2 coefficient at q31, or a genuinely new prime-twist analytic estimate could bridge the arithmetic sign to complex L(E0^(-q),1). In particular q3583 is a concrete NEW arithmetic rank-zero candidate awaiting an independent rigorous complex L-value certificate. The unrestricted goal rank E(Q)=ord_(s=1)L(E,s) for all E/Q remains incomplete. No external contacts, submissions, installations, downloads or spending were performed.

---

## 625. A general noncongruence theorem for elliptic Néron-period characters (new successor proof)

**Scope and verified background.** Let E/Q be the X_0(N)-optimal elliptic quotient of J_0(N) with E(Q)[2]=0, and take the strong Weil parametrization phi:X_0(N)->E, phi(infinity)=O. The optimality/connected-kernel hypothesis is important: it makes phi_*:H_1(X_0(N),Z)->H_1(E,Z) surjective, by the integral homology exact sequence for a quotient of complex tori with connected kernel. A general isogenous nonoptimal curve does not automatically have this same saturated image. Let l:H_1(E,Z)->Z be any primitive integral functional, and define chi:Gamma_0(N)->Z/2 by composing the class of a modular path from z to gamma z with phi_*, then l modulo2. Surjectivity makes chi nonzero.

**Theorem.** ker(chi) is never a congruence subgroup.

**Proof.** Since phi^* omega_E is a holomorphic differential on the compact modular curve, chi kills all parabolic elements stabilizing cusps (and all finite-order elliptic stabilizers). Its kernel K, an index-two subgroup of Gamma_0(N), has the SAME cusp widths, possibly with duplicated cusps. The least common multiple is N because cusp 0 has width N. The Fricke--Wohlfahrt theorem (geometric level = congruence level for a congruence subgroup of PSL_2(Z)) would give Gamma(N) subset K if K were congruence. The cusp translation T=[1,1;0,1] also belongs to K. Since Gamma_1(N)/Gamma(N) is generated by the image of T, Gamma_1(N) subset K.

The resulting unramified connected degree-two cover of X_0(N) would factor through X_1(N)->X_0(N). Its order-two Picard line bundle lies in the Shimura subgroup Sigma=ker(J_0(N)->J_1(N)). As the character was the pullback under phi of an order-two character of E(C), the same line bundle lies in phi^vee(E[2]) embedded into J_0(N)[2]. Thus Sigma[2] intersects phi^vee(E[2]) nontrivially. The Shimura subgroup is the multiplicative-type Cartier dual of a CONSTANT quotient of the diamond group; at exponent two it is a product of mu_2, whose geometric points are all rational over Q. The nonzero intersection therefore gives E(Q)[2]!=0, contradiction. This proves the theorem.

This is valid for EVERY X_0-optimal elliptic curve with E(Q)[2]=0. For a two-dimensional F_2 Galois module, reducibility is equivalent to the existence of an invariant F_2-line, and GL_1(F_2) is trivial; therefore E(Q)[2]=0 is E[2] irreducibility, not a strictly weaker hypothesis. In particular, for every positive integer m, ker(chi modulo 2^m) also cannot be congruence, since it lies in the noncongruence kernel of chi modulo 2; if the smaller kernel contained Gamma(M), so would the larger kernel.

**Integral Neron normalization, not a guessed sign period.** Let c_E be the Manin constant, omega_E the Neron differential and Omega_E^- the ABSOLUTE value of the period on a primitive anti-invariant cycle. Let c_infty=#pi_0(E(R)), equal2 when the discriminant is positive and1 when negative. The correct primitive integral functional on a closed modular loop gamma is

  l^-(gamma) = (2 c_E / c_infty) Im(2 pi i integral_gamma f_E(z) dz) / Omega_E^-.

For E0:y²=x³−28x+1, c_infty=2; the existing optimal/Manin certificate states c_E=1. Thus the primitive imaginary character is Im(2pi i integral_gamma f)/Omega_E^- reduced mod2, and is genuinely nonzero. In the one-real-component case, omitting the 2/c_infty factor can make an alleged mod2 period coordinate nonintegral or nonprimitive. The general theorem requires the actual primitive integral period functional; it is NOT a theorem about arbitrarily normalized rational modular symbols.

Source checks: Wohlfahrt's theorem in TIFR Lectures on Modular Functions, ch.2, Thm.9, https://mathweb.tifr.res.in/sites/default/files/publications/ln/tifr29.pdf ; Ribet, Congruence Relations between Modular Forms, discussion of Shimura subgroup and maximal unramified intermediate cover, https://math.berkeley.edu/~ribet/Articles/icm.pdf ; Wuthrich, Numerical modular symbols for elliptic curves, pp.1-3 and Proposition1, https://www.maths.nottingham.ac.uk/plp/pmzcw/download/modsym.pdf ; PARI/GP msfromell normalization, https://pari.math.u-bordeaux1.fr/dochtml/ref/Modular_symbols.html .

**Consequence and limitation.** For every finite m, some element of Gamma(m) has nonzero chi-value: otherwise ker chi would contain Gamma(m) and be congruence. So the primitive 2-adic period character is not recoverable on ALL modular loops from any finite congruence matrix residue. This does not exclude special relations on the selected prime-denominator modular cycles; it does not prove BSD.

## 626. Exact Fricke inversion on prime-denominator imaginary symbols

Fix E0 with N=4·41·2141=351124 and Fricke eigenvalue epsilon_N=+1, because the analytic rank3 certificate makes root number -1 and in weight2 epsilon_N= minus root number. Set F(r)=2pi i integral_(i infinity)^r f_E0(z) dz, using the usual limit from the upper half plane. Given q prime to N and a unit modulo q, choose b with Nab=-1 modulo q, and integer A=(1+Nab)/q. The matrix gamma=[A,b;Na,q] has determinant1 and belongs to Gamma_0(N). The composite gamma W_N maps (infinity,a/q) to (b/q,infinity), with EXACT rational endpoints. Its pullback on f(z)dz is epsilon_N f(z)dz, so

 F(a/q) = -epsilon_N F(b/q), b=-(Na)^(-1) modq.

As f has real coefficients, F(-r)=conjugate F(r). Therefore the imaginary coordinate s_q(a):=-Im F(a/q)/Omega_E0^- satisfies

 s_q(a)=epsilon_N s_q((Na)^(-1) modq).

The sign cannot be silently guessed; here epsilon_N=+1. If epsilon_N=-1 and chi_(−q)(N)=+1, the corresponding complete odd quadratic twist sum is forced to vanish, agreeing with the functional equation root sign.

For the eligible q≡7 mod8, chi_(−q)(41)=chi_(−q)(2141)=+1, so (N/q)=+1. The map iota_q(a)=(Na)^(-1) preserves the set of nonresidues. Its fixed points solve Na²=1 modq; they are opposite and have opposite quadratic character because (-1/q)=-1. There is precisely ONE fixed nonresidue, denoted a_q^*.

E0(Q)_tors=0: reduction at good primes 5,7 gives #E0(F5)=7 and #E0(F7)=12, excluding all torsion primes by prime-to-residue-characteristic injection. The rational cusp 0 is torsion-different from infinity under phi by Manin--Drinfeld, hence maps to O; all a/q with (q,N)=1 represent this cusp. Thus the complex relative symbol F(a/q) is an actual period lattice element, and s_q(a) is an INTEGER for E0 with c_E=1.

The exact Hecke relation with L(E0,1)=0 and the odd quadratic Gauss sum show, in the retained orientation,

 I_q= sqrt(q) L(E0^(−q),1)/(2 Omega_E0^-) = sum_{(a/q)=-1} s_q(a).

Hence the **exact** reduction

 I_q = s_q(a_q^*) + 2 sum_{two-element nonresidue iota_q-orbits} s_q(a),
 I_q ≡ s_q(a_q^*) (mod 2).

This is positive mathematical progress on the user's proposed involution. It does NOT by itself compute I_q/12 mod2, which needs I_q mod24.

For q=31, a^*=22 and the seven two-element orbits are (3,27),(6,29),(11,13),(12,30),(15,24),(17,23),(21,26). For q=23, a^*=21. The unique fixed nonresidue assertion has been checked for all 14 previously eligible q<=1663 and additional q3583; see bsd_fricke_wolhfahrt_kummer_verifier.py.

## 627. An ACTUAL elliptic-curve failure witness for lifting the Fricke cancellation to mod 4 or 24

For a fixed q, put y0=1/(q sqrt N). At the exact Fricke split height, the cusp integral is represented by the absolutely convergent paired Fourier series

 F(a/q)= sum_{n>=1} (a_n/n) exp(-2pi n y0) [ exp(2pi i n a/q) - exp(2pi i n b/q) ],
 b=-(Na)^(-1) modq.

All a_n are computed from good-prime finite-field point counts and Hecke recurrences, with a_2=0, a_41=-1, a_2141=+1. The primitive imaginary period is Omega_-=1.1372506124765919624128.... For the finite truncation at n=90,000, the Deligne/divisor bound |a_n|<=2n proves the tail bound for each exponential series

 2 exp[-2pi (90001)/(q sqrt N)]/(1-exp[-2pi/(q sqrt N)]).

An independent exact-rational outward enclosure verifier constructs pi by Machin arctan series, bounds all cubic roots by integer bisection, bounds Omega_- by the arithmetic-geometric mean, bounds exp and sin using Taylor remainders, and accumulates all Fourier terms in 10^30 fixed-point integer arithmetic. Its certified per-symbol errors are below 1.4·10^(-13) at q23 and 7.9·10^(-10) at q31. Together with the established integrality of each symbol, these establish EXACT integer values, not merely floating point guesses:

 q=23, nonresidue orbits (5,10):−2, (7,17):2, (11,15):2, (14,20):1, (19,22):−2, fixed(21):−2.
 Thus I_23=−2+2(−2+2+2+1−2)=0.

 q=31, nonresidue orbits (3,27):2, (6,29):1, (11,13):0, (12,30):−1, (15,24):1, (17,23):0, (21,26):0, fixed(22):6.
 Thus I_31=6+2(2+1+0−1+1+0+0)=12.

**Actual failure witness:** I_31−s_31(a_31^*)=6, so this difference is NOT divisible by4, let alone24. In particular the one fixed term does not recover the arithmetic bit I_31/12 mod2; its seven nonfixed orbits contribute an indispensable 6. The q23 control also has nonzero fixed term −2 while its global L-value is zero. The statement that pairing by Fricke makes all other terms disappear after dividing by12 is therefore false for the actual original E0.

Executable sources: bsd_fricke_imaginary_symbol_verifier.cpp generates exact Hecke coefficients in a private flat binary vector; bsd_fricke_interval_verifier.py then performs the 100% rational outward bounds and prints PASS for both q. No third-party code was downloaded or installed.

## 628. All three reduced Fisher quartics are ACTUAL halving quartics of E0 rational point directions

Let E0:y²=x³−28x+1, and P=(-2,7), Q=(-4,7), R=(0,1). Exact group addition yields T1=Q+R=(25/4,67/8), T2=P+Q=(6,-7), T3=P+R=(11,32). For T=(x_T,y_T), the 2-division x-polynomial is

 H_T(X)=X^4−4 x_T X³+56X²+(112x_T−8)X+(784−4x_T).

Its four roots are precisely the x-coordinates of V with 2V=T. If x is such a root, its y coordinate is the RATIONAL expression

 y_V=[x³−3x_T x²+28(x+x_T)−2]/(2y_T).

Direct polynomial division proves y_V²=x³−28x+1 and [2]V=T.

For the three reduced binary quartics G1=(-16,-24,24,8,-1), G2=(-4,16,12,-28,3), G3=(-4,8,60,64,15) listed in the user's message (coefficients from s^4 to t^4), put g_i(s)=G_i(s,1) and

 X1(s)=−2+6s+8s²,
 X2(s)=−1−4s+2s²,
 X3(s)=−5−2s+2s².

Then **exact polynomial remainders** satisfy H_{Ti}(Xi(s))=0 modulo g_i(s) for all i. These identities are verified with rational polynomial arithmetic in bsd_fricke_wolhfahrt_kummer_verifier.py. G1 and G2 are irreducible modulo 13; G3 is irreducible modulo17. Consequently each quartic root field Q(s_i) is EXACTLY a field over which one half of its indicated rational T_i is defined, and the reduced quartics have no extra guessed isogeny or algebraic-point interpretation. In particular the monic polynomial for u=2s in G1 is u⁴+3u³−6u²−4u+1, and x(V)=−2+3u+2u². Its halving polynomial is X⁴−25X³+56X²+692X+759, with discriminant 87781·67^4, while the defining quartic field has discriminant87781.

The full 192-element Fisher RADICAL field is larger than these quartic point-halving fields. This result alone does not identify the nonabelian central Fisher quadratic extension with a specific iterated Kummer/Heisenberg lift of the two points; that comparison remains a separate problem.

## 629. The common twist-Selmer plane equals the pair-sum Kummer plane of the ORIGINAL E0

In the cubic K=Q(theta), theta³−28theta+1=0, the following are EXACT square identities:

 144+23theta=(25/4−theta)*((-320−96theta−10theta²)/67)^2,
 239+23theta=(6−theta)*((-45+17theta+4theta²)/7)^2,
 4586+575theta=(11−theta)*((-661+141theta+39theta²)/32)^2.

Every identity reduces to zero modulo the cubic and is checked with exact rational arithmetic. The 2-descent Kummer map for E0 sends (x,y) to the class x−theta. Under the canonical identification of E0[2] with E0^(D)[2] for a quadratic twist (roots theta to Dtheta), the COMMON two-dimensional twist-Selmer classes from the project are therefore

 alpha1=delta_2(Q+R), alpha2=delta_2(P+Q), alpha3=delta_2(P+R)

as actual classes in H¹(Q,E0[2]). In particular the common 2-Selmer plane of the negative twists is an honest rational-point subspace in E0(Q)/2E0(Q). The very same classes are rational points for D=-23, order-two Sha obstructions for D=-31, and 4-liftable but non-point classes for D=-1303. This does NOT make the negative-twist Sha classes rational in those twists.

All P,Q,R lie in the bounded real component of E0(R), because their x values are between the two smaller real cubic roots. Their pair sums T_i lie in the identity component, and the three alpha_i are totally positive in the cubic K. Thus the common plane is the even-parity Kummer plane, making the three real embedding signatures and the negative-twist local condition transparent.

Moreover P,Q,R themselves are independent mod2 in E0(Q): an odd combination has nontrivial (+--) cubic sign; the three nonzero even combinations are the distinct nontrivial alpha_i. Since rank E0(Q)=3 and E0(Q)tors=0, these three points form a Z_2-basis of its free Mordell-Weil lattice (their index is odd).

## 630. Partial Atkin--Lehner involutions do not supply a second pairing WITHIN the same half-sum

The exact Atkin--Lehner divisors of N are 4,41,2141. Their eigenvalues on the weight-two newform are epsilon_41=+1 (nonsplit I1, a_41=-1), epsilon_2141=-1 (split I1, a_2141=+1), and epsilon_4=-1, because their product is epsilon_N=+1.

The original relative path symbols are between a/q, which lies at cusp-denominator label1 (the orbit of 0), and infinity, label N. For an exact divisor Q of N, W_Q toggles the Q components of the denominator label, so it takes the unordered pair {1,N} to {Q,N/Q}. Explicitly,

 W_4: {1,351124}->{4,87781},
 W_41:{1,351124}->{41,8564},
 W_2141:{1,351124}->{2141,164}.

These are DIFFERENT cusp pairs. Only the identity and full Fricke W_N preserve the original unordered pair. Thus partial W_41 and W_2141 do not induce additional permutations a->a' of the SAME collection of prime-denominator symbols {F(a/q)} by this elementary cusp-pair argument. They produce paths between OTHER unitary cusp orbits. Although all those cusp images happen to be O under E0's optimal parametrization, comparison introduces additional period cycles; their mod4/24 contributions have NOT been shown to vanish. The actual q31 value above demonstrates why this missing information is essential.

This defeats the proposed AUTOMATIC fourfold cancellation, not every deeper use of Atkin--Lehner and Manin relations. The proper next task is an explicit modular-symbol identity involving the extra cusp-label pairs, with the full integral period correction retained. Source for exact-divisor cusp action: Atkin--Lehner cusp-denominator formulas in https://www.numdam.org/item/10.5802/aif.1273.pdf and https://webspace.maths.qmul.ac.uk/abhishek.saha/research/nottingham-2022-talk.pdf .

## 631. Geometric synthesis: the degree-four 2-division pullback cover of X0(N)

For ANY X_0-optimal E with surjective residual E[2] representation, form the fibre product

 Y=X_0(N) x_{E,phi,[2]} E,

so a point of Y is a pair (x,V) satisfying [2]V=phi(x). Over C, [2]:E->E is an unramified fourfold cover with deck group E[2]. Optimality implies phi_* on integral H1 is onto, hence the induced map on H1 modulo2 is onto E[2]. Consequently Y_C is connected and its geometric monodromy is the full E[2]. If the arithmetic image on E[2] is GL2(F2)=S3 (as for E0), the arithmetic monodromy on the four sheet labels is the full affine group E[2]⋊S3=AGL2(F2)=S4. (Order reasoning: the image contains all 4 geometric translations and surjects to S3, hence has order 24, equal to the affine group.)

Its nontrivial geometric degree-two characters are precisely the nonzero mod2 period characters of entries625--626; their kernels are noncongruence by the theorem above. This gives a concrete global geometric manifestation of the noncongruence character. The rational-point 2-halving fields of entry628 are fibres of the multiplication-by-two cover [2]:E0->E0 at T1,T2,T3. The modular cover Y is its pullback by phi. Do NOT infer these fibres arise from Q-rational points on X0(N), since not every rational E0-point necessarily has a rational preimage under phi. There is also no automatic equality of the 192-element Fisher central extension with an iterated [4]-division field. What IS proved is the exact appearance of the same original E0[2] and actual rational Mordell--Weil Kummer directions in both constructions.

## 632. Status and target after this proof/failure cycle

(A) The general noncongruence period-character theorem is proved, under optimality and E(Q)[2]=0. The correct Neron primitive coordinate, not the arbitrary eclib/minimal imaginary period quotient, is essential. (B) The user's Fricke inverse map is correct, and exact imaginary symbols pair; exactly one nonresidue term survives modulo2. (C) The actual E0 q31 and q23 modular symbols prove that this cannot be promoted to mod4 or mod24 by discarding nonfixed terms: at q31 the fixed value is6, the nonfixed total is6 and the required total is12. (D) Partial W_41 and W_2141 do not preserve the original cusp-label pair and thus do not automatically give additional cancellation. (E) The small Fisher quartics are explicitly the real 2-division quartic fields of three rational pair-sums on the ORIGINAL E0, and the common twist 2-Selmer plane is their rational Kummer plane over E0. This is a concrete upgrade from a mere abstract isomorphism of residual modules.

No proof of I_q/12 mod2 in terms of the quartic ray-class Fisher bit has been obtained, and no unconditional complex analytic nonvanishing on the infinite positive-Fisher-sign prime family was derived. Even that nonvanishing would produce new rank-zero BSD cases, not prove rank E(Q)=ord_(s=1)L(E,s) for all curves. The surviving all-target problem remains a uniform extension-sensitive arithmetic-to-COMPLEX-analytic order comparison, beyond finite descent, local Frobenius matching, and first-height/period characters. No outside code downloads, installation, spending, submission or outreach occurred.

## 633. Exact criterion for CONGRUENCE period characters, including rational-two-torsion optimal curves

Let E/Q be X_0(N)-optimal, phi:X_0(N)->E with phi(infinity)=0, and let 0!=chi:Gamma_0(N)->F_2 be a character pulled back from a primitive integral homology functional of E. Write P_chi∈E^vee[2](C) for the associated nonzero degree-zero order-two line bundle under the Weil/Picard duality. The induced order-two line bundle on X_0(N) is phi^vee(P_chi)∈J_0(N)[2]. Then the following are EQUIVALENT:

(i) ker chi is a congruence subgroup of PSL_2(Z) (with -I killed by chi).
(ii) Gamma_1(N)⊂ker chi (after passing to PSL_2).
(iii) phi^vee(P_chi) belongs to the Shimura subgroup Sigma(N)=ker[J_0(N)->J_1(N)].

Proof: χ kills every cusp parabolic, so its index-two kernel has unchanged cusp widths and geometric level N. If congruence, Wohlfahrt gives Gamma(N)⊂ker chi. The generator T of Gamma_1(N)/Gamma(N) fixes infinity, hence lies in ker chi; so Gamma_1(N)⊂ker chi. Conversely any group containing Gamma_1(N) is congruence. The equivalence between (ii) and (iii) follows from the character/unramified-double-cover description of the Shimura subgroup: a 2-character of the modular curve factors through X_1(N)->X_0(N) exactly when its Picard-two-torsion line bundle is in Sigma(N). The Picard line bundle is the pullback phi^vee(P_chi). No assumption on E(Q)[2] is needed for this equivalence. If E[2] is irreducible, equivalently E(Q)[2]=0 (over F_2 all one-dimensional characters are trivial), the intersection is zero because Sigma[2] is rational multiplicative type, recovering 625. In general a rational 2-torsion point in E is NECESSARY but not sufficient for congruence of a given period character; membership in Sigma is the exact condition.

A genuinely stronger example: X_0(14) itself is the optimal elliptic curve 14a1 with E(Q)_tors=C6, hence has rational 2-torsion (LMFDB https://www.lmfdb.org/EllipticCurve/Q/14a1/ ; optimality https://www.lmfdb.org/EllipticCurve/Q/14a/ ). Nevertheless (Z/14Z)^×/{±1} has order3, so there is no nontrivial order-two character factoring through Gamma_0(14)/±Gamma_1(14). Therefore EVERY nonzero parabolic-trivial mod-two character of Gamma_0(14), including every primitive elliptic period character, has a NONCONGRUENCE kernel. This extends the noncongruence conclusion to a concrete reducible E[2] case rather than incorrectly claiming irreducibility is strictly stronger than absence of rational 2-torsion.

More generally if |(Z/NZ)^×/{±1}| is odd, the same quotient argument proves noncongruence of every nontrivial parabolic-trivial mod-two character, independent of the elliptic quotient. The criterion and example do not determine any BSD analytic rank or replace the original arithmetic-to-complex-analytic bridge.

---

## 634. All-squarefree odd-discriminant Fricke parity and the exact next-digit reduction (2026-11-21, successor continuation)

User-provided further proof input (the 1,148-state/19-class reduction itself was NOT independently replayed in this turn): for E0:y^2=x^3-28x+1, N=351124, every positive squarefree m≡3 (mod 4) prime to N has EVEN imaginary-period nonresidue half-sum I_m. The fixed-semicycle computation is formulated using the quadratic form [Nm,-2Na,(Na²-1)/m] of discriminant 4N and the involution a -> (Na)^(-1) mod m. The user checked nineteen unoriented geodesic classes, all with even primitive signed imaginary period. When χ_{-m}(N)=-1, the functional equation gives I_m=0. Otherwise the involution preserves the nonresidues and pairs all nonfixed orbits.

Let F_m be the nonresidue fixed-point set and O_m a representative from each two-element nonresidue orbit. For each imaginary modular symbol s_m(a)∈Z, the exact relation from entry626 gives

 I_m = Σ_{a∈F_m} s_m(a) + 2 Σ_{a∈O_m} s_m(a).

Using the supplied evenness of all FIXED symbols, define J_m=Σ_F s_m(a)/2 + Σ_O s_m(a). Then I_m=2J_m. For the prime Fisher comparison and any eligible m with 12|I_m,

 I_m/12 = J_m/6, and (I_m/12 mod 2) = e(α_m) iff J_m ≡ 2e(α_m) (mod 4).

This formula RETAINS EVERY nonfixed orbit. No fixed-term-only mod4 or mod24 lifting is valid: for m31 the fixed term is6, nonfixed representative sum3 and J31=6, I31=12. For m23 fixed term -2, nonfixed sum1, J23=0, I23=0. The 19-class global parity argument is accepted here as user-supplied, with three further independent composite m checks below; it is not promoted to a newly independent verification of the entire 1148-state enumeration.

## 635 / 637. CRITICAL SOURCE SCOPE CORRECTION: weight-3/2 is not covered by the cited k≥2 newform statement

The Manickam–Meher–Ramakrishnan 2015 *Theory of Newforms of Half-Integral Weight* explicitly assumes k≥2 for weight k+1/2 at the beginning of its published statement. Its quoted level-16M correspondence therefore DOES NOT justify a unique rational 3/2-newline for the original weight-two E0 (k=1). The prior formulation of entry635 as proved was incorrect. Even if a level-16M plus-new vector exists, one must also establish it belongs to the correct local D=-31 packet. The odd bad-place signs are W41=+1,W2141=-1 but χ_{-31}(41)=χ_{-31}(2141)=+1. At 2141 the ordinary sign-matched squarefree-level packet is inappropriate without a local adjustment. Neither the extra dyadic level nor local test-vector level can be guessed from the odd squarefree-level formula. Sources: https://msp.org/pjm/2015/274-1/pjm-v274-n1-p11-s.pdf (check opening k≥2), Baruch–Mao https://citeseerx.ist.psu.edu/document?doi=6e64d0ba9e9b82bd68d417d22bed0e9800ea3408&repid=rep1&type=pdf Thm4.3, sections8-10.

## 636. Conditional integrality from all-discriminant evenness

Let C={m>0 squarefree: m≡7 mod8, (m,N)=1, χ_{-m}(41)=χ_{-m}(2141)=+1}. Suppose a SINGLE weight-3/2 classical vector with rational coefficient ratios b(m)/b(31) exists and has the CONSTANT-FINITE-LOCAL-FACTOR relation

 I_m/I_31=(b(m)/b(31))² for all m∈C, b(31)≠0.

Normalize b(31)=1; since I31=12, get I_m=12b(m)². Write b(m)=a/c in lowest terms. The user global-evenness gives I_m/2=6a²/c²∈Z, so c²|6; hence c=1. Thus ALL eligible fundamental b(m) are integers automatically, with b31=1, and I_m=12b(m)². Numerics: b=0 at seven rank-two controls, ±1 at six I=12 controls, ±3 at q3583 (I=108), ±6 at q1303 (I=432). This theorem is an exact implication; packet rationality and uniform local factor are not proved.

## 638. General weight-three-halves Waldspurger existence is published; it is NOT a rational constant-packet theorem

James–Ono, *Selmer Groups of Quadratic Twists of Elliptic Curves*, Theorem6, states for ANY modular E/Q there exists some halfweight eigenform g∈S_{3/2}(N_W,χ), with 4N(E)|N_W and algebraic-integer coefficients, and a formula b(|D|)^2=ε(D)√|D| L(E^(D),1)/Ω_F for signed squarefree D in its prescribed side and coprime to N_W. Here ε(D) belongs to a fixed number field and may vary with D. This removes the false use of the k≥2 newform theorem for EXISTENCE, but does not show the chosen form detects D=-31, is rational, or has ε(D) constant. Reference: https://uva.theopenscholar.com/files/ken-ono/files/043_8.pdf pp5-6.

Baruch–Mao, *Central Value of Automorphic L-Functions*, Theorem4.3/Corollary4.6, prove the precise vector-independent ADELIC square relation for each metaplectic packet ε and squarefree D in the same locally selected packet. For E0 and the eligible negative D=-m, the local squareclasses at 2,41,2141,∞ are fixed, so the proper packet selected by D=-31 is common. THIS DOES NOT make the actual Fourier coefficient of an arbitrary chosen fixed classical vector identical to the normalized Whittaker functional: local W_D(v) evaluations must be normalized and controlled. Reference: https://citeseerx.ist.psu.edu/document?doi=6e64d0ba9e9b82bd68d417d22bed0e9800ea3408&repid=rep1&type=pdf Theorem4.3, Cor4.6, Lemma7.2, §§8-10. The explicit classical square formula in its Theorem10.1 assumes odd squarefree level; E0 has conductor4·41·2141.

## 639. New exact COMPOSITE test, including failure of a too-broad square formula

An existing exact 90,000-term E0 Hecke coefficient binary vector was reused; the coefficient count was not repeated. New independent verifier bsd_composite_parity_verifier.py computes outward rational interval enclosures for the imaginary Néron period and all relevant modular-symbol Fourier integrals. It uses no external libraries or downloads. It rigorously certifies

 m=15: I_15=0, fixed nonresidue symbols s(7)=0,s(13)=0, per-symbol error<2.9e-19;
 m=35: I_35=4, fixed s(18)=-2,s(32)=0, per-symbol error<2.2e-8;
 m=55: I_55=12, fixed s(27)=4,s(38)=-4, per-symbol error<0.000533.

All three satisfy m≡3 mod4 and have χ_{-m}(41)=χ_{-m}(2141)=-1. Thus they are NOT in the eligible packet C where both signs are +1. At m35 the global root sign still permits a central value, but I35=4 is NOT 12 times an integer square. So a single Waldspurger packet's constant-square relation must fix INDIVIDUAL local squareclasses, not only the global root number. The composite all-discriminant evenness passed these three adversarial tests. Program output ends COMPOSITE FRICKE INTEGER CERTIFICATES PASS.

## 640. A useful rational-Hecke-space lemma, with the packet-selection caveat

Let W_Q be a finite-dimensional Q-q-expansion space of weight-3/2 cusp forms on a fixed congruence subgroup with rational (e.g. quadratic) nebentypus. Suppose rational Hecke operators T_{ℓ²} (for all good ℓ) have a joint complex eigenvector with all eigenvalues λ_ℓ∈Q and with the coefficient at index31 nonzero. Then there is a RATIONAL joint eigenvector with nonzero index31 coefficient. Proof: the descending intersection of kernels ker(T_{ℓ²}-λ_ℓ) stabilizes in finite dimension and is cut out by finitely many rational matrices. The coefficient-at-31 functional is Q-linear and nonzero on this complexified space, so it is nonzero on a rational vector. Scale to b(31)=1. This elementary rational descent DOES NOT show the rational vector lies in the specified local Waldspurger packet, nor that every selected coefficient has the same local normalization; different local packets can share all good Hecke eigenvalues. If the relevant local packet is rationally selected by Hecke projectors, rationality follows, but those projectors have not been constructed at 2 and2141.

## 641. Hecke-square integrality and a single-seed thin-prime CHEBOTAREV theorem (conditional)

For weight3/2 form g with quadratic rational nebentypus χ and integral-weight Shimura eigenvalues λ_ℓ=a_ℓ(E0) or an integer quadratic twist thereof, at good ℓ the Hecke relation reads

 b(ℓ²n)=λ_ℓ b(n)-χ(ℓ)( (-n)/ℓ ) b(n)-ℓ b(n/ℓ²),

where b(n/ℓ²)=0 unless ℓ²|n. If squarefree part m of n is eligible and n coprime to the fixed level, integrality of b(m) plus this recursion gives b(n)∈Z. Let B be a multiple of 8 and every prime dividing the halfweight level, with 31 coprime to B. Sieve the coefficient indices n by the indicator C(n): n odd, n≡7 mod8, χ_{-n}(41)=χ_{-n}(2141)=+1, gcd(n,B)=1. If n=m t² is selected, then its squarefree part m is eligible. Therefore g_C=Σ C(n)b(n)q^n has INTEGRAL coefficients. The indicator C(n), depending only on n mod B, is a finite rational linear combination of Dirichlet characters modulo B, so g_C is a half-integral-weight modular form at a fixed higher level. Multiplying by θ(q)=1+2Σ_{j≥1}q^{j²} produces an integral WEIGHT-TWO modular form H(q)=g_C(q)θ(q) with H≡g_C mod2. Its prime-index coefficient satisfies a_q(H)≡b(q) mod2 for eligible q∤2B.

Published Serre/Galois pseudorepresentation theory for mod2 integral-weight modular forms says q↦a_q(H) mod2 at unramified primes is a conjugacy class function on some FINITE Galois extension F_H/Q, even if H is non-eigen or its Hecke algebra is nonreduced. Suppose IN ADDITION the chosen rational g is in the correct fixed local Waldspurger packet and has the constant ratio I_m=12b(m)² across all eligible squarefree m. Then b31=1, so a31(H)=1mod2, while prime31 has the NEGATIVE Fisher sign. In the compositum of F_H, the fixed Fisher W(D4) field and Q(ζ_B), the actual Frobenius class at31 gives a nonempty class with b(q) odd and negative Fisher sign. CHEBOTAREV gives a POSITIVE NATURAL DENSITY of primes in exactly this joint class, hence (by Fisher nondegeneracy) algebraic rank0 and (by b(q) odd/Waldspurger) L(E0^(-q),1)>0. This is a rigorous SUFFICIENT theorem for the true thin PRIME Fisher family, not a density-one-squarefree argument; its unproved premises are rational fixed classical packet and constant local coefficient normalization. No need to guess that every q in the whole Fisher-negative class has nonzero coefficient. The theorem assumes the chosen half-integral level prime to31, as needed to use31 as an unramified Frobenius seed in F_H. Choice of local spherical vector at31 is separately to be justified.

Source for finite-Galois mod2 prime coefficient class functions: Charlton–Mauth–Medvedovsky, *On the parity of coefficients of eta powers*, https://archive.mpim-bonn.mpg.de/id/eprint/5145/1/mpim-preprint_2024-30.pdf. The congruence θ≡1 mod2 is literal coefficientwise.

## 642. Local hypothesis and analytic scope checkpoint

Baruch–Mao gives a globally normalized metaplectic packet for D=-31 and all squarefree D of the same local squareclasses at 2,41,2141 and∞; it does NOT identify a scalar rational Fourier vector with a fixed integer coefficient ratio across all such D. At the odd multiplicative prime2141, Fricke W2141=-1 while χ_D(2141)=+1, requiring the proper alternate local type; at2 the level exponent is2 and k=1, outside the previously cited odd-squarefree and k≥2 shortcut theorems. In particular any assertion that the newform of level16·87781 itself gives b31≠0 is currently UNPROVED. A new, potentially sufficient finite task is to construct actual metaplectic local newvectors at2,2141 and31; show the 31-vector is spherical, identify the Q-rational Hecke eigenspace and its local packet projection, and compute W_D(v) at D=-31 and its squareclass. Once that is available, §641 would prove infinitely many prime rank-zero BSD cases in the actual Fisher class. This would NOT resolve unrestricted rank BSD or higher-rank L-derivative comparisons. No paper was submitted, source downloaded/installed, outside code used or spending authorized.


## 643. Rational odd local Waldspurger test vector at the split Steinberg prime 2141

SOURCE CHECK. Baruch–Mao, *Central Value of Automorphic L-functions*, arXiv:math/0301115v1, §8.3.3, Proposition 8.5 and Proposition 8.7, https://arxiv.org/pdf/math/0301115. This is the actual odd-residue local negative Weil packet, not the published odd-squarefree GLOBAL theorem transplanted to E0's even conductor.

Let l=2141, and let pi_l be the Steinberg representation of the split-multiplicative E0. In the notation of BM §8.3, its local parameter tau is a square. All eligible D=-q are nonzero unit squares in Q_l since chi_D(l)=+1. Thus the distinguished metaplectic packet is the negative Weil model r_{psi^tau}^- on odd Schwartz functions. Its D-Whittaker functional for D=tau*alpha² is evaluation Phi(alpha), with fixed normalization.

Choose a transversal R for F_l^×/{±1}; for example residues 1,...,1070. Put
 Phi(x)=1 if x mod l is in R;
 Phi(x)=-1 if x mod l is in -R;
 Phi(x)=0 if x in l Z_l.
This is a Q-valued odd locally constant Schwartz function, hence an actual vector in the negative Weil model. For every eligible local D, Phi(alpha)=±1, so the local Whittaker never vanishes. Its Schwartz-model invariant norm is the SAME as BM's Phi_chi (whose unit-residue values are all complex absolute-value1): with BM's normalization, ||Phi||²=(1-l^-1)/2. Thus e(Phi,psi_D)=||Phi||²/|Phi(alpha)|²=(1-l^-1)/2=1070/2141 independently of D. This checks the whole desired negative-local *magnitude* for a fixed rational Schwartz vector, WITHOUT requiring Phi to belong to a one-dimensional K00 character eigenspace.

The previous canonical local character choice chi(-1)=-1 does require a fourth-order character because l=2141≡5 mod8. The finite unit group has order 2140=4*535, 2 is a primitive root, and chi(2)=i gives chi(-1)=-1. Individual chi eigenspaces have Q(i)-valued phases. The rational sign function is a linear combination of many such eigenvectors; it avoids any local rationality obstruction from having to select ONE eigenspace, at the cost of forfeiting a convenient scalar tame nebentypus. It is not yet a global rational q-expansion.

## 644. Both odd bad-place normalized metaplectic factors are constant, and their product is a 2-adic unit

At 41, E0 has nonsplit I_1 and W_41=+1. In BM's notation tau is a nonsquare, and eligible D is a unit square, so D*tau is nonsquare. BM Prop8.4 yields the positive-special test vector with e_41=1/2, independently of the eligible D. At 2141 use §643's rational negative-Weil vector, with e_2141=1070/2141. Therefore
 e_41*e_2141=(1/2)*(1070/2141)=535/2141 in Z_2^×.
Their metaplectic norm denominators CANCEL as 2-adic valuations. This is an exact local statement, not an assertion of integrality for the entire Waldspurger global constant. The fixed GL2 special newvector norm is e(pi_l)=(1+l^-1)^-1, so the ratio e(pi)/e(tildepi) at BOTH bad primes still carries nontrivial 2-adic factors. One must retain dyadic, infinity, Petersson, rational q-expansion and period normalizations.

BM Lemma10.2 explicitly identifies W_l=+1 iff tau nonsquare, W_l=-1 iff tau square. Theorem10.1 for N odd squarefree, k=1 and just ONE sign flip s=1 would correspond to positive D (since (-1)^(s+k)=+1); our discriminants D=-q are NEGATIVE. This reinforces that the actual dyadic factor of E0 is essential and the odd-squarefree global recipe is not valid verbatim.

## 645. Explicit local dyadic Galois field: Q2(zeta3,cuberoot(2)), with tame dihedral supercuspidal type

For E0:y²=x³-28x+1, c4=1344, c6=-864, Delta=16*87781=1,404,496. Its minimal 2-adic reduction is Kodaira IV, conductor exponent f_2=2 (N=4*87781). This was an accepted geometric input in the earlier record and can be independently checked by Tate's algorithm.

Chao Li, *2-Selmer Groups, 2-Class Groups and Rational Points on Elliptic Curves*, Lemma3.5, https://www.math.columbia.edu/~chaoli/EC4d.pdf, proves for any such local type-IV curve that
 Q_2(E[3])=Q_2(zeta_3, cube_root(Delta)), a tamely ramified S3 extension.
Now Delta=2³*(2*87781), and 87781 is odd. Hensel's lemma applied to X³-87781 at X=1 mod2 (derivative 3=1 mod2) gives an EXACT cube root of 87781 in Q2. Therefore
  Q_2(E0[3])=Q_2(zeta_3, cube_root(2)).
Here Q2(zeta3)/Q2 is unramified quadratic; Q2(cube_root(2)) is totally tamely ramified cubic; inertia is C3 and Frobenius inverts it. Since the characteristic-zero l-adic inertia representation on V_lE0 (l !=2) has the two nontrivial cubic characters and arithmetic Frobenius interchanges them, its Weil–Deligne parameter is irreducible dihedral, induced from a character of W_{Q2(zeta3)} with order-three tame inertia; its unramified normalization is fixed by det Frobenius=2. Hence pi_2 is a depth-zero tame dihedral supercuspidal representation, not spherical or Steinberg.

This pins down the missing LOCAL 2-adic theta test: find an explicit vector in the metaplectic theta lift of this exact tame dihedral parameter with nonzero and constant-magnitude Whittaker values for D ∈1+8Z2 (the common eligible local squareclass). Rationality of its classical q-expansion and the global period comparison remain separate.

## 646. Precise scope of the published arbitrary-even-level explicit Waldspurger recipe

Soma Purkait, *Explicit application of Waldspurger's theorem*, LMS J Comput Math 16 (2013), pp216-245, https://www.math.titech.ac.jp/top/~purkait/Paper2_ExplicitWaldspurger.pdf, reviews Waldspurger's original local test vectors at non-squarefree levels. The paper's Theorem7 assumes (H1) and (H2), where (H2) is ONE of: (a) pi_2 not supercuspidal; (b) conductor of chi_0 divisible by16; (c) 16 divides the integral newform level M_phi. For quadratic nebentypus chi, the conductor of chi_0 divides8, so (b) impossible. For E0, pi2 supercuspidal (§645) and v2(M_phi)=2, so (a) and (c) fail too. Thus the easy explicit local-basis formula from Theorem7 CANNOT be invoked to construct E0's desired packet.

Purkait Corollary5.1 does establish existence of SOME weight-3/2 Shimura eigenspace with quadratic nebentypus for a weight-two rational newform. But that does NOT prove the nonzero coefficient b(31) belongs to that particular locally selected eigenspace; the wrong local theta packet can have zero b(31). Purkait Corollary5.2 has an important weaker scope: GIVEN a half-integral form in the correct Shimura eigenspace, with n1/n2 a local square at all primes dividing its fixed halfweight level, it supplies the exact ratio of square coefficients to twisted central L-values WITHOUT imposing (H2) anew. One still needs the right form and its 31 coefficient, and to track the local packet / nebentypus. The entire arbitrary-even-conductor recipe is not automatically a positive resolution for E0.

Related source caveat: Zhengyu Mao's 2008 *A generalized Shimura correspondence for newforms* (JNT 128, 71-95), cited in Purkait as a subsequent generalization, has ABSTRACT scope *odd level*, not E0 level4*87781. Do not import its stated theorem without checking a compatible even-level extension.

## 647. Exact odd-character and rational sign-vector checks

The self-contained verifier /mnt/data/bsd_waldspurger_local_tests.py uses integer modular arithmetic only. The group F_2141^× has order2140=4*5*107 and 2 is a primitive root. For D=-q, the chosen quartic character chi4(2)=i gives:
 q=31: chi4(D)=-1; q=631:-1; q=647:-1; q=1303:+1; q=983:+1; q=1567:+1; q=3583:-1; q=35:chi4(D)=i (not eligible since D nonsquare at2141).
For EVERY eligible D among all 16 checked, the explicit rational odd Schwartz Phi evaluates to +1 or -1 at a square root in F_2141; this is verified directly and its negative root has opposite value. Its norm quotient 1070/2141 and the E0 integral invariants were checked exactly.

A subtlety: even if chi4(D)=±1 on eligible local D, the eigencharacter Whittaker value chi4(sqrt D) need not be real; it can be ±i. The rational sign vector bypasses this LOCAL phase problem, but does not prove the Galois descent of its GLOBAL automorphic theta lift.

## 648. Remaining ORIGINAL BSD and thin-prime analytic theorem obligations after the new local work

We have now supplied one rational Schwartz vector with constant nonzero Whittaker magnitude at2141, and the published BM positive vector at41, discharging BOTH ODD-BAD-place magnitude comparisons. The remaining local gate is the exact dyadic tame-dihedral metaplectic newvector at2 (§645); the *global* gates are compatibility of the test vectors in a single cuspidal theta representation with nonzero q31 coefficient, rational Fourier coefficient ratios (or an equally effective 2-integral q-expansion), and exact matching of the central-value ratio at all eligible fundamental D. The user-proved evenness would force the normalized rational fundamental coefficients to be integral (§636), after which Hecke-square propagation and the finite Chebotarev seed argument §641 could establish a positive-density prime family with rank=analytic order0, not all BSD. None of these remaining gates has been proved by §643–647.

The user's 34 eligible controls (including I3583=108), all-discriminant parity, and the proven second-descent / quartic 2-covering calculations remain intact. The general rank BSD target is still unresolved; no auxiliary local calculation can replace a universal arithmetic-to-COMPLEX-analytic rank comparison.

---

## 649. A uniform local metaplectic Whittaker vector over an entire unit-squareclass (2026-11-21 continuation)

THEOREM (local, all nonarchimedean local fields of characteristic zero). Let F be such a field, ψ a nontrivial additive character, and (π~,V) a smooth complex representation of the twofold metaplectic cover Mp2(F) of SL2(F). If π~ has a nonzero ψ_{D0}-Whittaker functional W_{D0}, then there exists v∈V with W_{D0}(v)≠0 and, under compatible unitary Whittaker normalizations, |W_{D0 u²}(v)|=|W_{D0}(v)| for EVERY u∈O_F^×.

Proof: The preimage T~_O of the compact split torus T_O={h(u)=diag(u,u^{-1}):u∈O_F^×} is ABELIAN. For the standard Kubota cocycle, the restriction to T has cocycle the quadratic Hilbert symbol (u,v)_F, which is symmetric, so its commutator is1. This is explicit in the paper *Restriction of representations of metaplectic GL2(F) to tori*, equation(3) and its subsequent restriction to T^0, and in the Kubota definition. Choose w with W_{D0}(w)≠0. Because π~ is smooth and T~_O compact, the span of its T~_O orbit is finite-dimensional and its action factors through a finite abelian group. Project w to the character eigenspaces; some projection v has W_{D0}(v)≠0. If π~(t~(u))v=μ(u)v, then the relation h(u)n(x)h(u)^(-1)=n(u²x) transforms the ψ_{D0}-functional into the ψ_{D0 u²}-functional. Under the compatible Hilbert/Weil-index normalizations, W_{D0u²}(v)=c(u)μ(u)W_{D0}(v), with |c(u)|=|μ(u)|=1. This proves both nonvanishing and constant magnitude. The theorem concerns one fixed representation and one chosen local vector; it does not construct rational or integral q-expansions.

APPLICATION. All E0 eligible negative fundamental discriminants D=-q have q≡7 mod8, so D≡1 mod8 and lie in the SAME local squareclass in Q2× as D0=-31. The Baruch–Mao packet selected by L(E0^(-31),1)≠0 therefore admits ONE dyadic vector with constant nonzero Whittaker magnitude across all eligible D, even though π2 is tame dihedral supercuspidal (entry645). The old explicit dyadic vector formula from an unramified principal-series case is NOT invoked. Baruch–Mao Lemma7.2 only asserts finitely many possible Whittaker norm values for an arbitrary vector; the eigvector construction proves a stronger constant-magnitude statement for a specially chosen vector. Sources: https://citeseerx.ist.psu.edu/document?doi=6e64d0ba9e9b82bd68d417d22bed0e9800ea3408&repid=rep1&type=pdf Lemma7.2; https://www.researchgate.net/publication/312194470_Restriction_of_representations_of_metaplectic_GL2F_to_tori (torus preimage abelian).

## 650. A definite-quaternion Waldspurger toric-period construction is impossible for these squareclasses

THEOREM (for the ORIGINAL E0 automorphic representation). For any eligible D=-q, K=Q(sqrt(D)) splits at2 because D≡1 mod8, and splits at41 and2141 by χ_D(41)=χ_D(2141)=+1. The E0 weight-two local representation is discrete series exactly at2 (supercuspidal) and41,2141 (special); at all other finite primes it is unramified principal series. If a rational quaternion algebra B has Jacquet–Langlands transfer of this same π and embeds K, any finite ramified place v of B must be one of {2,41,2141} (local JL) AND K_v must be a field (because F_v×F_v has idempotents and cannot embed into a division algebra). Both are impossible simultaneously in the eligible family. Hence B must split at every finite place. By parity of the ramification set, it also splits at infinity. In particular NO definite B can supply the conventional definite-quaternion ternary theta series for this original π and these imaginary K. This does not obstruct a split-quaternion, Shintani/indefinite, or direct metaplectic construction. Source for local toric periods and embedding: https://www.math.iitb.ac.in/~dprasad/comp2013.pdf §2.4; standard local Jacquet–Langlands discrete-series criterion.

This generalizes: if E/Q is a modular elliptic curve and K/Q is a quadratic field split at EVERY finite prime where π_E is discrete series, then a quaternion B supporting both the π_E Jacquet–Langlands transfer and an embedding of K cannot be definite.

## 651. Unconditional normalized adelic square law versus the UNPROVED rational classical packet

Let π correspond to f_E0 and let π~ be the global Waldspurger packet selected by the proven nonzero central L(E0^(-31),1). All eligible negative D=-q have the same local squareclasses at each bad v∈{2,41,2141,∞}, so by Baruch–Mao Theorem3.2 they lie in the same packet. Let S={∞,2,41,2141}, d_D=d_{π~}(S,ψ_D)≥0 the intrinsic normalized Whittaker coefficient as in Baruch–Mao equation(2.10). Theorem4.3 gives
 d_D² = C_π L^S(π⊗χ_D,1/2) Π_{v∈S}|D|_v^{-1},
with C_π independent of D, after fixing π and ψ. The removed finite local L-factors are equal for all eligible D because χ_D,v is trivial at the bad places; the real gamma normalization is the same for all negative D. For D=-q, Π_{v∈S}|D|_v^{-1}=1/q. Thus
  d_{-q}²/d_{-31}² = (31/q)·[L(E0^(-q),1)/L(E0^(-31),1)].
With I_q=√q L(E0^(-q),1)/(2 Ω_im), I31=12, one gets the exact ALL-ELIGIBLE intrinsic norm law
  I_q/12 = (q/31)^{3/2} · [d_{-q}/d_{-31}]².
The positive intrinsic quantities B_q=(q/31)^{3/4}d_{-q}/d_{-31} therefore satisfy I_q=12 B_q². The users' exact values give B_q=0,1,3,6 for the four observed I groups; this is a *complex norm* relation and does not establish B_q is rational for arbitrary q.

The local vector in entry649 makes bad-place Whittaker magnitudes independent of D for a SPECIALLY CHOSEN pure tensor; entries643–644 do the same explicitly at odd bad places. These facts make the general global classical-coefficient route more plausible, but do NOT supply a single classical weight-three-halves vector with rational Fourier coefficients, Galois descent of its local test vectors, full dyadic 2-integral normalization, or equality of its Fourier b(q) with the intrinsic norm B_q. If a single rational packet with b31=1 and I_q=12 b(q)² is constructed, entry636 plus the user's all-discriminant evenness forces every eligible fundamental b(q)∈Z and entry640's conditional Chebotarev propagation can give infinitely many Fisher-negative rank=analytic rank0 prime twists. This is a restricted theorem, NOT unrestricted BSD. Source: Baruch–Mao published adelic Theorems3.2,4.3 and Cor4.6, https://citeseerx.ist.psu.edu/document?doi=6e64d0ba9e9b82bd68d417d22bed0e9800ea3408&repid=rep1&type=pdf .

## 652. Rational structures do NOT follow formally from unit-torus constant-magnitude eigenvectors

ABSTRACT COUNTERMODEL (not the actual E0 local representation). Let C3 act on V_Q={(x1,x2,x3)∈Q³: x1+x2+x3=0} by cyclic permutation. Let L(x)=x1. Over C, the eigenvector (1,ω,ω²), ω³=1≠1, lies in V_C and its three translated L-values have constant nonzero modulus1. But there is NO v∈V_Q with |L(g^i v)| constant nonzero for i=0,1,2: otherwise each coordinate equals ±a for a fixed positive rational a, and three signed equal nonzero numbers cannot sum to0. Thus existence of a complex unit-torus eigvector whose Whittaker values have constant modulus does not by itself imply existence of a rational vector with the same property. The compact unit group of Q2 itself is pro2 rather than C3, so this is not an obstruction model for the actual E0 dyadic packet; it isolates the missing FIELD-OF-DEFINITION theorem.

NEXT EXACT STEP FOR BSD-RELEVANT PRIME FAMILY: produce a global 3/2-weight form g with Hecke eigenvalues a_l(E0) at l∤2N, whose local component is the D=-31 packet and whose normalized eligible squarefree coefficient ratios b(q)/b(31) are rational AND Whittaker norm factors match the intrinsic formula above. Verify integrality/Manin and chosen dyadic local vector, without assuming local Γ0(4N) newvector or the invalid k≥2 plus-newform theorem. Alternatively establish a uniform long prime-twist nonvanishing first moment on the Fisher-negative class. Full BSD rank equality for every E/Q remains open, including all higher analytic ranks.

## 653. Exact dyadic adjoint local factor from the tame-dihedral parameter

For E0 at2, the Weil–Deligne parameter is ρ=Ind_{W_L}^{W_Q2} ξ up to unramified twist, where L=Q2(ζ3) is the unramified quadratic extension and ξ has nontrivial order-three tame inertia character. In particular ξ^σ=ξ² on inertia. The adjoint trace-zero representation decomposes as
  Ad^0 ρ ≅ χ_{L/Q2} ⊕ Ind_{W_L}^{W_Q2}(ξ/ξ^σ).
The induced 2D part has NO inertia invariants because ξ/ξ^σ is ramified order3; the one-dimensional χ_{L/Q2} is the unramified quadratic character and Frobenius has eigenvalue -1. Hence the exact local adjoint Euler factor is
  L_2(s, Ad E0)=(1+2^{-s})^{-1},   L_2(1, Ad E0)=2/3.
Its 2-adic valuation at s=1 is +1. The other local adjoint and Petersson factors must still be matched when comparing Baruch–Mao intrinsic Whittaker norms with a normalized classical Fourier lattice. This follows from the already verified local field of entry645, not from an inapplicable ordinary/spherical formula at p=2.

## 654. The rational-flat-dyadic-vector question reduces to a finite signed matrix-coefficient test

Let U~ denote the compact inverse image of the split diagonal unit torus in Mp2(Q2). Entry649 proves there is a complex unit-torus eigenvector with constant nonzero Whittaker magnitude along D∈D0(Z2×)². But that vector need not lie in a Q-rational structure, even if the ambient local representation does.

PRECISE FINITE TEST. Fix a finite-dimensional Q-vector subspace W_Q of a putative rational realization of the dyadic packet that is stable under U~, and assume the D0-Whittaker functional λ is Q-valued on W_Q after a fixed normalization. Because the action is smooth and U~ is compact, its action on W_Q factors through a finite abelian quotient A. For each a∈A let T_a be its (rational) matrix. Form the rational linear map
  Ψ:W_Q→Q^A,   Ψ(v)_a=λ(T_av).
There is a vector v∈W_Q with λ(v)=1 and all translated Whittaker values equal ±1 if and only if im Ψ contains a sign vector ε∈{±1}^A with ε_1=+1. This is equivalent to solving finitely many rational LINEAR systems Ψ(v)=ε, one per sign pattern, and checking the nonzero normalization. For actual Fourier coefficient phases, first transport the known metaplectic Weil-index factor c(a): the corresponding target set is c(a)^(-1) times desired unit/real values; if c(a)∉Q, carry out the linear test in its exact cyclotomic coefficient field and impose Q-rational descent separately.

This is a mathematically exact algorithmic criterion, but NOT a computed positive result for the actual E0 dyadic representation: neither the finite quotient A, the Q-form of W, nor its λ-matrix has been constructed in the project. The local field and tame C3-type in entry645 sharply constrain that calculation. It is not legitimate to infer a rational global weight-3/2 q-expansion from the complex unit-torus lemma alone.

The attempted standard definite-quaternion ternary-theta route is independently ruled out in entry650 by the simultaneous local JL and quadratic field embedding conditions. An indefinite / split-quaternion cohomological theta construction or the direct metaplectic packet remains possible. Unrestricted BSD rank equality, and the assertion I_q/12 is a rational square for every eligible q, remain unproved.

## 655. The DYADIC metaplectic Weil-index multiplier is rational on the relevant square-roots

All eligible D=-q have q≡7 mod8, D≡1 mod8, as does D0=-31. Thus D/D0∈1+8 Z2. The squaring map 1+4Z2 → 1+8Z2 is an isomorphism (2-adic log gives multiplication by2:4Z2→8Z2), and uniquely D=D0 u² for u∈1+4Z2. On these units, the 2-adic Hilbert symbol (a,b)_2 is1: the explicit odd-unit formula is (-1)^(((a-1)/2)((b-1)/2)), with both half-differences even. Hence the metaplectic double cover of SL2(Q2) is SPLIT on the needed compact torus subgroup. With the standard Weil multiplier μ_ψ(a)=γ(ψ)/γ(ψ_a), the relation μ_ψ(a)μ_ψ(b)=(a,b)_2 μ_ψ(ab) and square-invariance of Weil indices give
  μ_ψ(u)^2=(u,u)_2 μ_ψ(u²)=(u,-1)_2=1
for u∈1+4Z2. Thus μ_ψ(u)∈{±1}. This is stronger than entry649's magnitude result: the CANONICAL dyadic Weil phase along all eligible D is rational and only the chosen torus eigencharacter could still introduce nonrational phases. The remaining task is determine a dyadic packet vector defined over a rational coefficient lattice whose torus eigencharacter on 1+4Z2 is ±1 (or produce a rational combination with constant phase-corrected Whittaker amplitudes). Global rational classical Fourier descent remains separate. This proof uses no false blanket application of odd-squarefree-level Kohnen or of Purkait's (H2).

An independent finite sanity check, /mnt/data/bsd_dyadic_squareclass_torus_verifier.py, confirms the square-class bijection up to 2^12 and the odd-unit Hilbert symbols modulo128, and constructs unique square-roots u≡1 mod4 modulo2^11 for all eligible numerical controls. The universal assertions come from the Hilbert-symbol formula and the 2-adic logarithm, not those checks.
