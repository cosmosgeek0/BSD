# BSD Conjecture — single working research handoff

**Authoritative working handoff · 20 November 2026 · Research resumed (private, on user request)**

> **Verdict: NO solution is ready to check, publish, or claim.** This project has **not** proved or disproved the Birch–Swinnerton-Dyer conjecture for every elliptic curve over \(\mathbb Q\). No complete proof of finiteness of the entire Tate–Shafarevich group or of the refined all-prime formula exists in the project. There is no Clay-prize claim. The earlier conditional finite-precision \(GU(2,2)\) theorem (§2) **has no proved implication to the rank of an arbitrary original elliptic curve and is parked**. The current direct rank-two experiments and their precise point-origin obstruction appear in §1B. No universal arithmetic-to-complex-rank bridge has been proved.

**Operating instruction.** This is the **only working handoff** to edit in later authorized sessions. All previous handoffs, archives, detailed research notes, computations, and records are *immutable evidence*, not competing active state files. **The owner expressly resumed research on 20 November 2026. Continue only in the active turn when requested; do not claim background operation. No purchases, publication, outreach, submission, or schedules are authorized.** On resumption, use independent specialist/adversarial checks if actual subagent tooling is available; never invent their availability or verdicts.

## 1. Exact target and scope boundary

For **every** elliptic curve \(E/\mathbb Q\), the principal rank assertion is
\[
\operatorname{rank}E(\mathbb Q)=\operatorname{ord}_{s=1}L(E,s).
\]
The following are **distinct obligations**, not consequences established by this work:

1. **Whole \(\Sha\) finiteness:** \(\Sha(E/\mathbb Q)\) finite, including all primary components and finite prime support.
2. **Refined leading coefficient:** with consistent Néron-period and height conventions,
   \[
   \frac{L^{(r)}(E,1)}{r!}
   =\frac{\Omega_E\,\operatorname{Reg}_E\,|\Sha(E/\mathbb Q)|
     \prod_\ell c_\ell}{|E(\mathbb Q)_{\rm tors}|^2}.
   \]
3. **Universality:** no restriction to selected conductor, coefficient prime, good ordinary condition, residual image, \(K\), theta nonvanishing, or an auxiliary modular form.

A Selmer-corank statement at one prime is not complex analytic rank equality. Vanishing of \(\Sha[p^\infty]\) for one fixed curve is not whole-\(\Sha\) finiteness, and no selected-prime congruence proves the refined formula.

**Current priority, corrected by the owner:** work directly on rational points and the rank comparison for **every** \(E/\mathbb Q\). A construction of two point-valued leading classes must preserve their rational origin and independence and supply an independent **upper rank bound**; a nonzero exterior power of a Selmer group is insufficient. The auxiliary \(GU\) direction stays parked for the Clay target until a proved map from its outcome to the original elliptic curve’s rank is supplied. See §1B.

## 1B. Direct rank-two exterior and covering construction — rigorous 20 November 2026 pass

**Verdict: two exact mechanisms tested; the universal BSD bridge remains open.** The quadratic invariant/exterior map is not point-valued in general. A genuine 3-covering provides an explicit descent obstruction and an actual nonflex point of zero rational trace. On the known rank-two curve 1480.a1 a separate exact reduction certificate proves two actual rational divisor classes independent. These do **not** tie a cohomological leading term to the complex second derivative for an arbitrary E, nor prove a uniform upper bound. No new global BSD case is claimed. The former §1A GU work is background only until a rank implication exists.

### A. Exact rational restriction, trace and exterior maps

Let F/Q be finite Galois with group G, m>=2, and E/Q elliptic. The Kummer cocycle of P∈E(F) is δ_F(P)(h)=hQ−Q for any mQ=P. Natural connecting maps give a commuting square

```
 E(F)/mE(F)      -- δ_F --> H^1(F,E[m])
      | N_{F/Q}                     | cor_{F/Q}
      v                              v
 E(Q)/mE(Q)      -- δ_Q --> H^1(Q,E[m]).
```

Indeed m(Σ_{τ∈G}τQ)=ΣτP, and applying g−1 to that sum computes the corestriction cocycle. Conversely res_F δ_Q(R)=δ_F(R), and res_F cor_F c=Σ_{τ∈G}τ c. A cohomological corestriction need not be Kummer: it may lie in Sel_m without coming from E(Q).

For quadratic F=Q(√D), put W=E(F)⊗Q and e_±=(1±σ)/2. The plus space is E(Q)⊗Q, the minus space is E^D(Q)⊗Q under the quadratic-twist isomorphism. Exactly

(∧²W)^G = ∧²W^+ ⊕ ∧²W^−,

 e_+^{∧²}(P∧Q)=P_+∧Q_+ + P_−∧Q_−,
 (e_+P)∧(e_+Q)=P_+∧Q_+.

Here e_+^{∧²} denotes averaging the G-action **on the exterior module**, not ∧²(e_+). Thus exterior averaging can retain two anti-invariant twist directions and fail to supply ANY two rational points on E. Genuine point-valued projection is ∧²e_+: it gives (TrP∧TrQ)/4, and is nonzero iff the two rational traces are Q-independent. A finite difference of trace-zero anticyclotomic/anti-invariant terms stays trace-zero. A character-wise wedge determinant or a G-invariant wedge does not replace this test.

### B. Exactly what a Selmer-leading exterior must satisfy

At the finite level S_p=Sel_p(E/Q), B_p=δ_p(E(Q)/pE(Q)), and C_p=Sha(E/Q)[p], the *unconditional* Kummer sequence is

0 → B_p → S_p --q--> C_p →0.

The source is finite-dimensional over F_p; no finiteness of whole Sha is assumed. Define the alternating linear map

Θ_q:∧²S_p → C_p⊗S_p,
 Θ_q(a∧b)=q(a)⊗b−q(b)⊗a.

**Exact point-origin lemma (proved here, elementary):** ker Θ_q = ∧²B_p. Proof: split S_p=B_p⊕C_p as vector spaces. ∧²S_p decomposes as ∧²B_p⊕(B_p⊗C_p)⊕∧²C_p. Θ_q kills exactly the first summand, maps the mixed summand injectively into C_p⊗B_p, and maps ∧²C_p injectively to antisymmetric C_p⊗C_p. Thus even a nonzero class Ω∈∧²Sel_p represents an exterior of rational Kummer classes **only if** Θ_qΩ=0. When p-torsion in E(Q) is zero, a nonzero Ω in that kernel proves rank E(Q)≥2.

The rationalized analogue uses S=H^1_f(Q,V_pE), B=E(Q)⊗Q_p, C=V_pSha(E/Q) and the same Θ. The exact 0→B→S→C→0 follows by taking inverse limits of the finite Kummer sequences and tensoring Q_p. It makes **no** finite-Sha assumption. Note that torsion Sha[p] is invisible after rationalization, which is why the explicit covering below is a finite-coefficient (not V_p) countertest. Both versions are algebraic *criteria*, not procedures to calculate q from local conditions or a proof that Θ=0 for a given Euler-system leading term.

For an E with analytic order exactly two, a possible complete certificate WITHOUT prior finite Sha is: construct Ω≠0 in ∧²Sel_p from actual data, prove Θ_qΩ=0 (or produce the two rational points directly), assume E(Q)[p]=0, and independently establish dim_Fp Sel_p≤2. Then r≥2 and r≤2, hence r=2, and Sha[p]=0. The last two ingredients do not follow from analytic order two in the present project. In general the standard *unconditional* upper bound is

r ≤ dim_Fp Sel_p(E/Q)−dim_Fp E(Q)[p].

A few good-prime reductions provide lower rank obstructions but cannot produce this upper bound.

### C. Genuine cubic covering: a nonzero point with zero rational trace

Take C: 3X³+4Y³+5Z³=0, Jac(C)=E_S:U³+V³+60W³=0, with origin (1:−1:0). Let H=O_C(1) have degree3. The algebraic map π(P)=[3P−H] from C to Pic^0(C)=E_S is defined over Q and, after choosing a geometric flex as origin, is [3], so degree9.

Choose F=Q(α), α³=−3, P=(α:1:1)∈C(F). This is not a flex: det Hess(3X³+4Y³+5Z³)=12960XYZ, nonzero at P. Therefore π(P)≠0 in E_S(F). **The line Y=Z cuts out the three conjugates of P**, so Tr_{F/Q}[P]=H and

Tr_{F/Q}π(P)=[3H−3H]=0 ∈ E_S(Q).

This repairs the tempting but useless coordinate-line example Y=0: its intersection points are FLEXES, and π(P)=0 before trace. More generally the line Y=tZ gives α_t³=−(4t³+5)/3; for any rational t giving an irreducible cubic with tα_t≠0, the corresponding point is a nonflex, π(P_t)≠0 and its trace is again zero. Their finite-difference traces remain zero, even after passing to a common compositum. This is a genuine geometric family, **not** a hypothetical Selmer vector.

Selmer proved C(Q_v) nonempty for all v but C(Q) empty. Thus ξ_C∈Sha(E_S/Q) is a nonzero class of exact order3: H has degree3, and no rational point trivializes ξ_C. Its lift along H^1(Q,E_S[3])→H^1(Q,E_S)[3] is in Sel_3 but is NOT a rational Kummer class. A rational divisor of degree coprime to3 would combine with H into a rational degree-one divisor, and genus-one Riemann–Roch would produce a rational point. Thus the index is exactly3 and no such divisor exists. This is the exact covering-descent obstruction to forcing a rational point from local data.

For the no-Q-point arithmetic descent, write X³+6Y³=10Z³ and α_0³=6. The source verifies that Q(α_0) has class number1 and that a primitive integral solution leads, after the unit-cube correction, to 2^k(X+Yα_0)=(α_0−2)(α_0−1)(A+Bα_0+Cα_0²)³. The α_0² coefficient must be

A³−9A²B+6A²C+6AB²+36ABC−54AC²+6B³−54B²C+36BC²+36C³=0.

Successively modulo 3,9,27 this forces 3|A,B,C, contradicting descent. Independent exact enumeration confirms the coefficient has **no primitive zero modulo27**. Local 3-solubility starts with 4·2³−5=27 and the applicable Hensel bound. The field-ideal/class-number argument is **known Selmer/Conrad mathematics**, not claimed newly proved here. Sources: https://kconrad.math.uconn.edu/blurbs/gradnumthy/selmerexample.pdf and https://www.dpmms.cam.ac.uk/~taf1000/papers/ctp.pdf (Kummer exact sequence and torsors). The Magma descent documentation https://www.math.uzh.ch/sepp/magma-2.26.5-dm/html/text1513.htm additionally reports E_S(Q) trivial and Sel_3(E_S/Q)≅(F_3)^2; so this *known finite-level case* really has ∧²Sel_3≠0 but ∧²E_S(Q)=0. Do not confuse it with a V_pSha statement.

### D. A direct rational-point certificate on a different known analytic-rank-two curve

On E_1480:y²=x³−28x+52 (minimal conductor 1480), choose P=(−2,10), Q=(−4,10). These are actual Q-rational points and degree-zero rational divisors P−O,Q−O. Its discriminant is 236800=2^8·5²·37, so 3,13,19 are good primes. Enumeration and exact doubling give

```
  l     #E(F_l)     P mod l in 2E(F_l)?    Q mod l in 2E(F_l)?
  3       7                 yes                    yes
  13     18                  NO                    yes
  19     24                 yes                     NO
```

Explicit halves: Q mod13=2(7,2), P mod19=2(4,17). Listing the 9 doubles at13 excludes P=(11,10), and listing the 12 doubles at19 excludes Q=(15,10). These two local homomorphisms give the identity matrix on (P,Q) in F_2². Since #E(F_3)=7 is odd, E(Q)[2]=0 by injection of prime-to-3 torsion at good reduction. Hence P,Q represent independent mod-2 **nontorsion** directions and P∧Q≠0 in ∧²(E_1480(Q)⊗Q). Thus rank E_1480(Q)≥2, proved here without BSD or any Sha finiteness assumption.

**Reverse bound:** NOT furnished by these finite reductions. Rank=2 and analytic rank=2 for this curve are already recorded with rigorous descent/modular-symbol provenance in https://www.lmfdb.org/EllipticCurve/Q/1480a1/ and https://www.lmfdb.org/knowledge/show/rcs.rigor.ec.q. This is a known special case and an independent arithmetic lower-bound check, **not** a new BSD proof. A uniform construction from L''(E,1) to two independent rational divisors and an independent upper bound is still missing.

### E. Reproducible arithmetic check (Python standard library; run on 20 November 2026)

```python
def curve(p):
    return [None]+[(x,y) for x in range(p) for y in range(p)
                   if (y*y-x*x*x+28*x-52)%p==0]
def add(P,Q,p):
    if P is None: return Q
    if Q is None: return P
    x,y=P; u,v=Q
    if x==u and (y+v)%p==0: return None
    a=((3*x*x-28)*pow(2*y,-1,p) if P==Q
       else (v-y)*pow(u-x,-1,p))%p
    xx=(a*a-x-u)%p
    return xx,(a*(x-xx)-y)%p
for p in (3,13,19):
    points=curve(p)
    doubles={add(T,T,p) for T in points}
    P=(-2%p,10%p); Q=(-4%p,10%p)
    print(p,len(points),len(doubles),P in doubles,Q in doubles)
assert add((7,2),(7,2),13)==(9,10)
assert add((4,17),(4,17),19)==(17,10)

def prod(U,V): # multiplication in Z[alpha]/(alpha^3-6)
    w=[0]*5
    for i in range(3):
        for j in range(3): w[i+j]+=U[i]*V[j]
    return w[0]+6*w[3], w[1]+6*w[4], w[2]
def coeff(A,B,C):
    g=(A,B,C)
    return prod(prod(prod((2,-3,1),g),g),g)[2]
primitive_zeros=sum(coeff(a,b,c)%27==0 and any(v%3 for v in (a,b,c))
                    for a in range(27) for b in range(27) for c in range(27))
print('primitive mod27 obstruction zeros:',primitive_zeros)
assert primitive_zeros==0
```

Output: `3 7 7 True True`, `13 18 9 False True`, `19 24 12 True False`, `primitive mod27 obstruction zeros: 0`. The last check verifies the final congruence, not the preceding ideal factorization or whole no-Q-point theorem. The first checks give a full finite reduction certificate for independent rational points.

**Exact remaining full-Clay bridge:** for arbitrary analytic-rank-two E/Q, construct from a genuine global L-leading class a **nonzero rational-point exterior**, i.e. one in ∧²(E(Q)⊗Q) and not merely ∧²Selmer or (∧²E(F))^G; then prove r≤2 by an independent arithmetic upper bound. A two-class Selmer determinant can satisfy this only after its quotient-to-Sha obstruction Θ vanishes, which is not known from variation, reciprocity, or nonzero Taylor order. Generalize beyond analytic rank2 to all r. Neither construction nor the comparison with ord_{s=1}L(E,s) is now proved.

## 1A. New research, 20 November 2026 — primary-source boundary test and a finite-character route

**Status after this pass: the all-\(E/\mathbb Q\) BSD target is STILL OPEN.** The conditional original-\(GU\) theorem (FP) in §2 is unchanged. The following are **verified exact local/source algebra calculations and a new finite-character test plan**, not a constructed original global \(GU\) eigencharacter. The current session did not have a distinct subagent-execution tool; these are directly checked calculations, not purported independent agent reviews. Research has resumed on the owner's instruction; nothing runs asynchronously.

### A. Applicable published theorems actually checked, including a new 2026 direct congruence method

- **Lan**, *Compactifications of PEL-Type Shimura Varieties and Kuga Families with Ordinary Loci*, [primary PDF](https://www.kwlan.org/articles/cpt-ram-ord.pdf), Theorem **8.2.1.3** (PDF p. 590, printed p. 559), proves vanishing of positive **higher direct images of the subcanonical** automorphic bundle to the ordinary minimal compactification for the stated ordinary-Levi representation, coefficient base and neat level. Corollary **6.3.2.5** (PDF p. 444, printed p. 413) proves the finite-\(p\)-power **ordinary minimal** locus is affine; Corollary **5.2.2.3** concerns specified finite étale **formal ordinary** transitions, not arbitrary integral covers. On that exact tower, these results can kill the cohomological connecting obstruction to lifting an **already given global section of the entire horizontal boundary quotient**. The sheaf sequence is \(0\to\mathcal F_{\rm sub}\to\mathcal F_{\rm can}\to\mathcal Q\to0\); the key map is \(H^0(\mathcal F_{\rm can})\to H^0(\mathcal Q)\). They do **not** manufacture the varying \(B(W)\in H^0(\mathcal Q)\), establish its denominator, or prove a divided cusp eigenvector is primitive. The project’s `latest/continuous_weight_prescribed_boundary_lift_independent_review.txt` checks this exact conditional geometry.
- **Brasca–Rosso**, [primary paper](https://arxiv.org/pdf/1711.05546), Proposition **4.5** and Theorem **4.6(1)–(3)** (PDF pp. 21–22), supply the **cuspidal** ordinary projector and finite-free Pontryagin dual over the relevant weight Iwasawa algebra, plus specialization/control under their conditions. They do **not** assert finite-freeness of all noncuspidal forms or give an eigencharacter of the original \(GU\) image before the entire boundary has been canceled.
- **Takeda**, *Congruences between Klingen–Eisenstein series and cusp forms on \(U_{n,n}\)*, [arXiv:2603.08626v2](https://arxiv.org/pdf/2603.08626), Theorem **6.2** (PDF pp. 32–35) is a directly relevant *pattern*: isolate a cusp eigencomponent from an integral pullback with one negative-valuation Fourier coefficient, using the exact period coefficient ideal \(\mathfrak A(f)\), lower-rank integrality and a primitive cusp Fourier coefficient (Lemma **5.19**, Proposition **5.20**). Under **all** its hypotheses it obtains one eigenform congruent mod a specified \(\mathfrak P^\alpha\), rather than merely a sum of depths. **But its stated theorem assumes an even \(\mu\ge2n\)**; for \(n=2\) this is \(\mu\ge4\), whereas this project's original critical ordinary \(GU(2,2)\) source is scalar weight **2**. It also imposes \(p>\mu+1\), coefficient-ideal and full Fourier integrality hypotheses, and uses a different Hecke/level module. The theorem cannot be applied directly to the weight-two critical source or declared to produce \(\phi_L:R_{GU}\to\mathcal O/\varpi^L\). Its proof suggests the **right next method**: construct one nonzero **original** cusp coefficient after full boundary subtraction and explicitly account for period/old-new denominator, then use its actual Hecke relations. This is a possible construction technique, not a completed step.

### B. Exact original local \(GU\) Klingen boundary matrix at a relevant arithmetic specialization

Work with the recorded local ten-orbit Klingen source from `work/nov16/whole_boundary_factorization_and_original_departure_connection.txt` and `work/nov16/check_moving_Jacobi_Hom_boundary_matrix.py`. Specialize the *same* rational local formula to coefficient \(p=13\), auxiliary inert \(q=7\), relevant to the recorded \(E_{389}\) source over \(K=\mathbb Q(\sqrt{-11})\). This is a **genuine native local \(GU\) source calculation**, not a fully constructed global ordinary cusp eigenvector or a newly computed global Fourier coefficient. For this pair \(13\nmid2q(q^4-1)(q^6-1)\). Normalize the two complete original local Klingen coordinates by \(b_1=B_1/H\), \(b_w=B_w/H\) (\(H\) is the original compact Haar factor, retained when returning to global coefficients).

With \(t=(1+W)^{-\kappa_7/2}\), \(\kappa_7=\log_{13}\langle7\rangle/\log_{13}(14)\equiv4\pmod{13}\), and \(d_t=(49-t^2)/98\), the original even and odd rows are

\[
\begin{pmatrix}E_t\\O_t\end{pmatrix}=
 d_t\begin{pmatrix}
 -t^2(7t+6)/7&1\\
 t^2(7t-6)/7&1
 \end{pmatrix}\begin{pmatrix}b_1\\b_w\end{pmatrix}.
\]

At \(W=0\), \(t=1\), the exact matrix and reduction are

\[
 M_0=\begin{pmatrix}-312/343&24/49\\24/343&24/49\end{pmatrix},\qquad
 M_0\bmod13=\begin{pmatrix}0&5\\10&5\end{pmatrix},\quad
 \det M_0\equiv2\pmod{13}.
\]

**Local consequence:** the *complete two-coordinate* boundary map is an isomorphism of the original \(\mathbb Z_{13}\)-lattice and stays one after **every Artin coefficient cut**; its inverse has no 13-denominator. The individual even row nevertheless kills the primitive \(b_1\)-direction mod 13, so one Fourier/Jacobi row cannot replace this whole map. For the actual native generators, \(B(f_4)=(-H,0)\), \(B(f_6)=(0,H)\); the local source has a right inverse with no 13-loss. This checks only the local source/target; it does not make the native global theta-period denominator \(\eta_{\rm full}/\xi_g\cdot\Theta_\chi\) a unit.

The more severe derivative check uses the *actual normalized local compact vector* \(v\). Its two Hom values and existing normalized boundary functional satisfy
\[
 E_t(v)=\frac{8(t+1)(7t^2-t+1)}{14(t^4+6t^2+1)},\qquad
 O_t(v)=-\frac{8(t-1)(7t^2+t+1)}{14(t^4+6t^2+1)},
 \quad A(t)=\frac{t^4+6t^2+1}{8t^3},\qquad
 A(t)(E_t(v)-O_t(v))=1.
\]
Since \(t'(0)=-\kappa_7/2\), at \(p=13\)
\[
 E'_W(0)\equiv3,\quad O'_W(0)\equiv5,\quad A'_W(0)\equiv2,\qquad
 \big[A(E-O)\big]'(0)=2+3-5=0\pmod{13}
\]
and the last equality is **exact in characteristic zero**, not just mod 13. A **unit odd derivative** can be canceled by the derivative of the *original* boundary change-of-basis. This excludes that proposed shortcut to a primitive global cusp departure.

### C. Exact \(p=13,q=7\) *original receiving module* test of the Katz candidate

The saved `work/nov16/e389_q7_actual_integral_old_new_node_and_coefficient_detector.txt` constructs the genuine **integral \(GL_2\)** cuspidal Manin/Hecke block at level \(2723=389\cdot7\): its full two-dimensional localized order is
\(B_{GL2}=\mathbb Z_{13}[t]/(t(t-d))\), \(t=U_7-1\), \(v_{13}(d)=1\), and its **literal relative old/new quotient** is \(\mathbb Z_{13}/(d)\), detected on the actual localized q-expansion cusp lattice by \(f\mapsto a_7(f)-a_1(f)\pmod{13}\). This is **not** the original 4-dimensional \(GU\) cusp module: the distinction must survive every deduction.

For the recorded normalized Katz weight derivative, with positive coefficients \(a_n=2\sum_{d\mid n,13\nmid d}d^{-1}\), the natural normalized tame correction is
\(F=(7\phi-V_7\phi)/6\). An **exact** divisor-sum identity for every \(n\) is
\[
 a_{7n}=(1+7^{-1})a_n-7^{-1}a_{n/7},\qquad
 [q^n]F=(7a_n-a_{n/7})/6,
 \qquad U_7F=F.
\]
Here \(a_{n/7}=0\) when \(7\nmid n\). Specifically
\[
 a_1(\phi)=2,\quad a_7(\phi)=16/7,\quad
 a_1(F)=a_7(F)=7/3\equiv11\pmod{13},\quad
 (a_7-a_1)(F)=0\ \text{exactly}.
\]
So this **natural scalar Katz candidate** has a unit \(a_1\), but the **original relative receiving functional evaluates it to zero**. The identity \(U_7F=F\) holds for the entire formal series, not just its first two coefficients (200 indices were checked exactly; the divisor-sum calculation proves all indices). Since \(F\) itself is a scalar Eisenstein-type source, **not an already localized cuspidal \(GU\) input**, the numerical zero is a negative *preprojection test*, not a proof that the completed Katz/theta/ordinary \(GU\) image vanishes. The actually missing evaluation is the original \(\eta_{\rm full}e_g e_{\rm ord}\) projected numerator after all period and theta factors.

### D. Genuine finite Artin character on the actual \(GL_2\) old/new Hecke node (alternative to a characteristic-zero graph)

The original **weight-family** order of that same \(GL_2\) block is \(B_W=\mathbb Z_{13}[[W]][t]/(t(t-d(W)))\). The saved source proves
\(d(0)\equiv143\pmod{169}\), \(d'_W(0)\equiv5\pmod{13}\), \(X_Y(0,0)\equiv1\), \(W'_Y(0)\equiv8\pmod{13}\). Consequently \(d'_W W'_Y-X_Y\equiv5\cdot8-1\equiv0\pmod{13}\), matching the **coupled** BF graph \(d(W(Y))-X=d(0)\); but the **naive** unfactored scalar \(d(W(Y))\) has unit slope \(1\) mod13. After base change along that original graph, the original congruence module \(Q=\mathbb Z_{13}[[W]]/(d(W))\) has \(Q\otimes\mathbb F_{13}[\eta]/\eta^2\cong\mathbb F_{13}\), with \(\eta\) acting **zero**. The coupled scalar class therefore does not yield a flat first-order class in the original coefficient quotient.

An **independent finite-character construction** in this actual \(GL_2\) order is nevertheless possible. Put \(A=(\mathbb Z/169)[\eta]/\eta^2\), and write \(d_1=d'_W(0)\bmod169\), which the archived computation determines only modulo \(13\) as \(d_1\equiv5\). The **correct exact assignment** is
\[
 \boxed{W\mapsto\eta,\qquad t\mapsto104-d_1\eta\quad\text{in }A.}
\]
Indeed \(d(\eta)=143+d_1\eta\), so \(t-d(\eta)=-39-2d_1\eta\), and
\[
 t(t-d(\eta))=-4056+(-208+39)d_1\eta=-169(24+d_1\eta)=0\pmod{169}.
\]
The **simpler numerical representative** \(t=104-5\eta\) is justified only if a further calculation proves \(d_1\equiv5\pmod{169}\); the currently recorded \(d_1\equiv5\pmod{13}\) does **not** suffice. This distinction was caught in an adversarial audit of the attempted construction. The corrected map reduces to \(W=t=0\) at the critical point and has **unit weight speed**. There is also the scalar specialization \(W\mapsto13\), \(t\mapsto39\) mod169, with \(d(13)\equiv39\) since \(13d_1\equiv65\pmod{169}\), giving a genuine \(B_W\to\mathbb Z/169\). **Neither constructs a character of the original \(GU\) cusp Hecke algebra, an Eisenstein 1|2|1 trace, or the required precision (TARGET).** The example does show why finite *Artin* Hecke characters are a credible route distinct from infinitely extending a particular BF source path.

### E. Independent concrete depth-sum countermodel and the exact replacement test

This is a directly proved **algebraic counterexample**, **not an automorphic realization, novelty assertion, or replacement for Berger–Klosin–Kramer Proposition 4.3** ([primary text](https://kklosin.github.io/files/bergerklosinkramer2013.pdf)). Let \(\mathcal O\) be a DVR with uniformizer \(\varpi\), and set
\[
 T_0=\mathcal O\mathbf1\oplus\mathcal O a\oplus\mathcal O b\subset\mathcal O^3,
 \quad\mathbf1=(1,1,1),\ a=(0,\varpi,0),\ b=(0,0,\varpi).
\]
It is a **reduced, local, finite-free rank-three order**, with relations \(a^2=\varpi a\), \(b^2=\varpi b\), \(ab=0\). Let \(\lambda_0,\lambda_1,\lambda_2\) be the three coordinate projections, with \(\lambda_0\) distinguished as Eisenstein and the other two cuspidal. Each individual cusp branch agrees with \(\lambda_0\) **exactly modulo \(\varpi\)** (depth 1), so their *sum* of depths is 2.

The original cusp projection \(\psi:T_0\twoheadrightarrow T_c\subset\mathcal O^2\) sends \(a\mapsto x=(\varpi,0)\), \(b\mapsto y=(0,\varpi)\). Inside the **original cusp order** there is the exact relation \(x+y=\varpi\mathbf1\). But \(\lambda_0(a)=\lambda_0(b)=0\). Thus no \(\lambda_0\)-compatible character \(T_c\to\mathcal O/\varpi^2\) can exist, since it would send \(\varpi\) simultaneously to 0 and to \(\varpi\ne0\). More intrinsically,
\[
 \ker\psi=\mathcal O(\varpi\mathbf1-a-b),\qquad
 \lambda_0(\ker\psi)=(\varpi),
\]
so **maximum** compatible precision is 1 although the sum of individual congruence depths is 2. At \(\varpi=13\), the relation is \(x+y=13\) and directly forbids a prescribed character mod169. Every relation was checked in \(\mathbb Z/169\), with no rational eigenline saturation. This is the exact counterexample requested; its scope remains purely algebraic.

**General exact Hecke-kernel criterion (elementary):** for any surjection \(\psi:T_0\twoheadrightarrow R\) and a specified \(\mathcal O\)-character \(\lambda:T_0\to\mathcal O\), a *compatible* character \(R\to\mathcal O/\varpi^L\) exists **if and only if** \(\lambda(\ker\psi)\subseteq\varpi^L\mathcal O\). Necessity is obvious; sufficiency follows by factoring the reduced character through the quotient. This is a precise **finite algorithm** on a genuine integral Hecke presentation and does not infer the answer from a length or one Fourier coefficient. For a proposed scalar \(GU\) character, compute the **entire** ideal of original Hecke relations and evaluate its prescribed Eisenstein eigenvalues; verify also the actual rank-two middle trace decomposition and original GMA return products. The current source collection has the original \(GL_2\) relative block and local \(GU\) boundary maps, **not** an executable matrix presentation of the full original \(GU(2,2)\) cuspidal Hecke image at this \(p=13,q=7\) specialization. Claiming the full test is complete would be false.

### F. Surviving next test and BSD consequences

The **first missing arithmetic implication** is unchanged but is now a sharper finite test. At one fixed deep anticyclotomic character: (i) evaluate the *entire original* ordinary \(GU\) boundary vector, all rows/cusps, and its genuine native period/source normalization; (ii) construct the divided cusp vector and **measure its original primitive coefficient** (not just the scalar Katz \(a_1\)); (iii) on the original finite-free \(GU\) cusp module, compute/verify the Eisenstein character on **every original Hecke relation**, possibly directly by the kernel criterion above; (iv) check the actual decomposable 1|2|1 trace, critical-\(p\) relation, central GMA quotient, and required precision \(L>\kappa+b+\sum a_v\). Either a character or an explicit incompatible integral relation is a meaningful outcome. This route changes the **construction method**, not the auxiliary length bound. It must not be confused with completing BSD.

**Unchanged nonconclusions:** no genuine original \(GU\) scalar character at (TARGET); no exclusion of \(\lambda_g=3\); no proven critical-\(p\) condition for all curves; no bridge from the selected prime-conductor/inert-\(K\) setup to **every** \(E/\mathbb Q\); no universal analytic-rank equality, no full \(\Sha\) finiteness, and no refined formula. A valid solution would still need all those steps.

**Reproduction:** archived check `work/nov16/check_moving_Jacobi_Hom_boundary_matrix.py` was independently rerun **from a copy** on 20 November: **46/46** exact symbolic identities passed. A separate direct rational/symbolic calculation gave the \(p=13,q=7\) matrix, determinant, first derivatives, and exact \(A(E-O)=1\); integer dual-number arithmetic checked the \(169\)-character with formal derivative coefficient \(d_1\); exact rational divisor sums verified \(U_7F=F\) for the first **200 indices**, with the displayed general identity proving all indices. The concrete earlier \(GL_2\) Hecke module proof and files remain in the archive; no full global \(GU\) Galois/Hecke check was rerun or claimed.

---

## 2. Best surviving BSD-directed theorem: finite original-\(GU\) precision bound

**Status:** conditional algebra/cohomology theorem, internally checked in the November 16 research page. No actual \(GU\) character meeting its premises has been constructed. Do not strip its hypotheses to claim an unconditional inequality for elliptic curves.

### 2.1 Objects that must NOT be replaced

Let \(\mathcal O\) be the actual complete coefficient DVR, uniformizer \(\varpi\), odd residue characteristic \(p\), \(D=\mathcal O/\varpi^N\), and
\(\lambda_D:R\to D\) the critical character of the **original big \(GU\) cusp Hecke algebra** \(R\). Keep its faithful trace/Cayley–Hamilton algebra and multiplicity-free residual \(1|2|1\) projectors, with constituents
\[
(\bar\varepsilon,\ \overline{T_g\otimes\chi},\ 1).
\]
The auxiliary form \(g\) is **not** the original elliptic curve \(E\) and need not have rational coefficients.

Write its original GMA corners
\[
C_R=e_\varepsilon\mathscr E_R e_1,\quad
P_R=e_\varepsilon\mathscr E_R e_V,\quad
Q_R=e_V\mathscr E_R e_1,
\quad L_R=\operatorname{im}(P_R\otimes_RQ_R\to C_R).
\]
For the opposite adjacent corners \(R_{\rm opp},S_{\rm opp}\), take the original primitive quotients
\(V_{P,R}=P_R/(C_RR_{\rm opp})\) and
\(V_{Q,R}=Q_R/(S_{\rm opp}C_R)\), with the relevant original coefficient relations retained. After **original** base change put
\[
U=(C_R/L_R)\otimes_R D,\quad
U_P=V_{P,R}\otimes_R D,\quad U_Q=V_{Q,R}\otimes_R D.
\]
These are not fresh faithful or saturated quotients after a critical specialization. The full nilpotent finite algebra and original return products must survive.

The universal central class (archive **427, 449–450**) is extracted from the *actual* \(a_{13}\) GMA entry and has Kummer coordinates
\[
c_{\rm univ}=u_p[p]+\sum_{v\in S_{\rm tame}}u_v[\ell_v],
\qquad
U=D u_p+T_{\rm tame},\quad T_{\rm tame}=\sum_vD u_v .
\]
Here \(S_{\rm tame}\) contains **every** retained non-\(p\) place of \(K\), including the dyadic place unless its unramifiedness has been proved in this exact algebra. A split rational prime can contribute two places. Define
\[
b=2v_\varpi(x),\qquad \kappa=\operatorname{length}_{\mathcal O}(U_P\otimes_DU_Q),
\]
where \(x=\chi(\gamma)-1\) in the selected finite anticyclotomic coefficient chart.

### 2.2 Precise conditional theorem

Assume **all**:

- **Big support:** \(\operatorname{Fitt}^0_R(C_R)=0\) on the original **big** algebra, not merely after the \(D\)-cut.
- **Short adjacent module:** at least one of \(\operatorname{length}_{\mathcal O}U_P,\operatorname{length}_{\mathcal O}U_Q\) is strictly less than \(N\).
- **Literal universal class:** the preceding generation and reduction identities really hold for the original GMA.
- **Weak critical-\(p\) relation:** \(x^2u_p\in T_{\rm tame}\), with \(b<N\). This is an arithmetic hypothesis, **not** a generic consequence of crystalline density or a rational monodromy type.
- An **actual** scalar character of the original algebra
  \[
  \phi_L:R\longrightarrow B_L=\mathcal O/\varpi^L,\quad L\ge N,
  \]
  reducing to \(\lambda_D\), whose trace has the actual normalized Eisenstein \(1|2|1\) decomposition with a genuine middle rank-two representation and the original residual projectors. Its outer character quotient must be
  \[
  \delta_L=\varepsilon\,\Psi_\rho^{-1}\pmod{\varpi^L},
  \qquad \Psi_\rho\equiv1\pmod{\varpi^N},
  \]
  for a specified **infinite-order**, \(\mathcal O\)-valued cyclotomic character. In the retained odd-\(p\) setup \(\rho\in p\mathcal O\setminus\{0\}\) is a safe choice; just \(\rho\ne0\) in a ramified maximal ideal can accidentally give torsion \(1+\rho\).
- For each retained tame place \(v\), the finite valuation
  \(a_v=v_\varpi(\Psi_\rho(\operatorname{Frob}_v)-1)\) satisfies \(a_v<L\).

Then
\[
\boxed{L\ \le\ \kappa+2v_\varpi(x)+\sum_{v\in S_{\rm tame}}a_v.}
\tag{FP}
\]
Therefore an actual \(\phi_L\) with
\[
\boxed{L\ge\kappa+2v_\varpi(x)+\sum_v a_v+1}
\tag{TARGET}
\]
would contradict the listed retained hypotheses. **Constructing such a character remains open.** An infinite graph point, O-flatness of the central quotient, and prior annihilation of all \(u_v\) are **not** needed for this finite criterion.

### 2.3 Recheckable proof, in five steps

1. Base change the **original** GMA by \(\phi_L\). Set \(C=C_R\otimes_RB_L\), \(L_{\rm prod}=\operatorname{im}(P_B\otimes_{B_L}Q_B\to C)\), \(M=C/L_{\rm prod}\). Right exactness gives \(M\otimes_{B_L}D=U\) for the *original* image. The true three-block trace and spectral projectors (not exterior-square traces) provide \(c_M\in H^1(G_{K,S},M(\delta_L))\) reducing **literally** to \(c_{\rm univ}\).
2. For tame generator \(\tau_v\), let \(m_v=c_M(\tau_v)\). The arithmetic-Frobenius relation \(F_v\tau_vF_v^{-1}=\tau_v^{Nv}\) and the cocycle law yield
   \((\delta_L(F_v)-Nv)m_v=0\), hence
   \((\Psi_\rho(F_v)-1)m_v=0\). Wild inertia has no additive \(p\)-primary image here. Consequently \(\varpi^{a_v}m_v=0\) and for \(T_M=\sum B_Lm_v\),
   \[
   \operatorname{length}T_M\le\sum_v a_v,\qquad
   \operatorname{im}(T_M\to U)=T_{\rm tame}.
   \]
3. Set \(V=M/T_M\). Then
   \(V/\varpi^NV\simeq U/T_{\rm tame}\), cyclic and annihilated by \(x^2\), hence of length at most \(b<N\). **Short-module lemma:** if a finite DVR module \(V\) satisfies \(\operatorname{length}(V/\varpi^NV)<N\), its elementary divisors all have length \(<N\); therefore \(V=V/\varpi^NV\) and \(\operatorname{length}V\le b\). Thus
   \(\operatorname{length}M\le b+\sum a_v\).
4. The same lemma applied to the short adjacent quotient shows its full \(B_L\) version is already killed by \(\varpi^N\). The return-product identities make central multiplication factor through
   \(U_P\otimes_DU_Q\), so
   \(\operatorname{length}L_{\rm prod}\le\kappa\).
5. Base change of \(\operatorname{Fitt}^0_R(C_R)=0\) gives
   \(\operatorname{Fitt}^0_{B_L}(C)=0\). For a finite module over \(\mathcal O/\varpi^L\) this forces \(\operatorname{length}_{\mathcal O} C\ge L\). Since \(\operatorname{length}C=\operatorname{length}L_{\rm prod}+\operatorname{length}M\), obtain (FP).

The strict \(+1\) in (TARGET) is essential: the retained Tate-coefficient equality model
\(M=(\mathcal O/\varpi^b)e_0\oplus\bigoplus_v(\mathcal O/\varpi^{a_v})e_v\), \(m_p=e_0,m_v=e_v\), attains \(L=b+\sum a_v\) with \(\kappa=0\). It is **not** an automorphic realization. Full proof and internal adversarial review: **[finite-precision research page](https://chatgpt.com/space/page_77a41f3887808191ac04ebe8095c02f7)** and the exact embedded note `latest/finite_precision_GU_character_and_universal_cyclic_witness.txt` (§7 below).

**Dependency warnings:** the original *construction* of big support/finite GMA in **423–426** and the dyadic chain **436–438** received repairs later but not a full independent external source audit; do **not** promote them to unconditional prerequisites. The safest use of (FP) explicitly retains \(a_2\) instead of relying on the dyadic deletion. A short adjacent length and weak-\(p\) relation for the actual finite character also remain to be established.

## 3. The single next construction, specified down to a coefficient

The missing object is a scalar **\(\phi_L\) of the original \(GU\) cuspidal Hecke algebra** at the precision (TARGET), preserving the **same** outer \(\varepsilon\Psi_\rho^{-1}\), middle representation, full boundary, original lattice and \(a_{13}\)-class. A \(GL_2\) Hida eigensystem, BF class, Katz Eisenstein family, ordinary raw GU section, or a boundary value alone does **not** define it.

**Finite cusp-vector route:** produce a genuine cusp Hecke eigenvector \(v\) modulo \(\varpi^{L+s}\) in the **original specialized ordinary cusp module**, with genuine prescribed eigenvalues and one **original** coefficient functional \(\ell\) satisfying \(v_\varpi(\ell(v))=s\) (a unit after dividing by \(\varpi^s\)). For every original Hecke relation \(h\) with eigenvalue \(\phi(h)\), \(hv=0\); applying \(\ell\) gives \(\varpi^s\phi(h)=0\bmod\varpi^{L+s}\), so \(\phi(h)=0\bmod\varpi^L\). Thus even a **nonprimitive** vector can certify a *true* map \(R\to B_L\) without dividing by \(\varpi^s\). The loss \(s\) and *every* boundary row must be computed, not guessed.

On resumption, perform **one matched calculation**:

- Keep the actual old/new Hecke node, coherent \(GU\) theta/Eisenstein source, Katz input, fixed full set of \(p\)-ordinary dual and tame/dyadic tests. Differentiate **after** the actual theta-degree projection and whole genus-three pullback. Compute the *entire* boundary (all cusps/rows), not just one Fourier–Jacobi coefficient.
- Subtract the entire boundary in the original geometric module, apply the original cuspidal ordinary projector, and produce **one explicitly nonzero original cusp coefficient**, with certified valuation \(s\). Its eigenrelations must be tested on the original finite/nonreduced Hecke module.
- Show that its resulting normalized outer character has nonzero **unit-speed** cyclotomic direction while retaining the critical reduction. Compute all \(a_v\), \(\kappa\), \(b\), \(N\), \(L\), and \(s\) in the *same* DVR and compare \(L\) with (TARGET). If a needed dependence fails, preserve the exact obstruction rather than hiding it in a period or scalar unit.

The alternate *class-specific* route is to find an actual scalar dual-number character \(\phi:R\to D[\eta]/\eta^2\) and compute the **original central relation jet**, not merely a BF class derivative. With an original presentation \(R^m\xrightarrow{P_{\rm rel}}R^r\to C_R/L_R\to0\), \(P_{\rm rel}(\phi)=P_0+\eta P_1\), the coefficient defect is the image
\[
\operatorname{im}\bigl(\ker P_0\xrightarrow{\,qP_1\,}
\operatorname{coker}P_0\bigr).
\]
The actual cocycle equation includes
\[
d(qv_1)+s\,\kappa_{\rm cyc}\smile c_{\rm univ}=qP_1r_0,\qquad
P_0r_0=0,
\]
where \(s\) must be a unit in the **normalized** cyclotomic coordinate. Its tame obstruction vector is
\[
\beta_{\rm cyc}(c_{\rm univ})=(b_\ell u_\ell)_\ell,\quad
b_\ell=\frac{\log_p\langle\ell^2\rangle}{\log_p(1+p)}
\in D^\times
\]
for the selected core primes (archive **449–450**). Unit \(b_\ell\) makes \(\beta=0\) *equivalent* to all \(u_\ell=0\); equivalence itself proves nothing. A bound on the **full** image, or a genuine annihilation of the original relation transgression, would be new progress.

## 4. Useful latest exact source facts — and their limit

The diagnostic **conductor-389 curve**
\(E_{389}:y^2+y=x^3+x^2-2x\)
with coefficient \(p=13\), auxiliary \(q=7\), and raised level \(2723\) is a **test system, not an every-\(E\) reduction**. Some later source calculations use \(K=\mathbb Q(\sqrt{-11})\), distinct from the original inert \(K=\mathbb Q(\sqrt{-2})\). Do not conflate these settings.

The original integral Hida node (retained full 259-coordinate calculations):
\[
B=\mathbb Z_{13}[[W]][t]/(t(t-d(W))),\quad
t_{\rm new}=0,\quad t_{\rm old}=d(W),
\]
with
\[
d(0)=143\bmod169,\qquad d'(0)=5\bmod13.
\]
After the *corrected* tame \(\Gamma_1\) cover degree \(q-1=6\), the native coefficients are
\[
X_Y(0,0)=1\bmod13,\quad W'(0)=8\bmod13,\quad
J'(0)=3\bmod13.
\]
The older claimed \(X_Y=6\), \(W'=9\) are superseded.

The corrected **actual coupled \(GL_2\)/BF path** (internally checked in the later recovered note) is
\[
\frac{z_B}{Y^3}
=C_3(W,Y)\,[t-d(W)+X(W,Y)]\,\epsilon_\infty,
\qquad C_3\in B[[Y]]^\times,\quad X(W,0)=0,
\]
with \(X/Y\) a unit. The determinant/cyclotomic coordinate uses
\(1+Y_j=(1+W)(1+Y)\); the ordinary source derivative \(d'(0)\) is a unit, so the implicit equation \(d(W(Y))-X(W(Y),Y)=d(0)\) has an integral path. On the genuine new branch,
\[
z_{\rm new}(W(Y),Y)
=-d(0)\,Y^3 C_3(W(Y),Y)\,\epsilon_\infty.
\]
Division by \(d(0)Y^3\) gives an integral *primitive Tate source* with the desired outer cyclotomic character **for that source**. **It does not lift the original GU universal central class.** Indeed its native scalar congruence module on the path is \(\mathcal O[[Y]]/(d(0)+X_{\rm path})\); after cutting by \(d(0)\) and \(Y^2\), its first-order module has *maximal* coefficient defect. No module-comparison map to \(C_R/L_R\) is established.

The \(GU\) outer ratio and opposite \(389\) spectral variable share the **same** total norm direction:
\[
\delta=\varepsilon\chi_W^{-1}\nu_J^{-2},
\qquad (1+W)(1+J)^2=1+Y,\qquad
Y_{389}=389^{-1}(1+Y)^{\kappa_{389}}.
\]
Redistributing weight speed between \(W\) and \(J\) therefore cannot magically slow the physical opposite-389 coefficient. The exact Laurent receiver kills the proposed \(r'_{389}\) residue contribution; an apparent numerical logarithmic cancellation is invalid. The necessary whole local initial/angular numerator, native period, old-trace tuple, and **all** ordinary boundary coefficients remain the same source-normalization gate.

A candidate whole bounded rank-one Eisenstein input comes from the Katz family. The recovered source records the normalized mod-13 first \(q\)-jet
\[
E'_X(0)\equiv2\sum_{n\ge1}
  \left(\sum_{\substack{d\mid n\\13\nmid d}}d^{-1}\right)q^n
\pmod{13},
\qquad a_0(0)=6\pmod{13}.
\]
This is **not** yet the whole \(GU\) boundary/cusp row. Apply the actual theta projection, entire pullback, dual, period and ordinary projector before using it as evidence for \(\phi_L\).

The project also has a **conditional** auxiliary \(\lambda_g\) bound. Deep theta values have valuation \(\lambda_g a\), \(\lambda_g>0\) odd; \(\mu_{\rm Iwasawa}=0\) does **not** imply \(\lambda_g=1\). Under the older stronger critical local assumptions, \(N\le3a\) leaves \(\lambda_g=3\) as a sharp equality configuration (**318, 405**). Algebraic polarized models **304**, local Galois models **441, 452**, and critical-\(p\) example **399** show why neither rank-one local type, polarization, characteristic-zero density, nor a naive stricter \(2a\) inequality resolves it. This equality case remains separate from (TARGET).

## 5. Decisive failed shortcuts: do not restart without a new hypothesis

| Proposed shortcut | Exact reason it fails / where to reopen |
|---|---|
| Local purity, selected Iwahori/Klingen type, perfect polarization \(\Rightarrow u_\ell=0\) | **441/452** explicitly realize nonzero central tame Kummer coordinates within the sharp \(3a\) pattern; only an *actual global integral coefficient comparison* could exclude them. |
| Exterior square or rank-six traces identify the central extension | **442** gives a valid *framed* \(B\to A\) detector \(-N_{14}I_2\); **444/447** give polarized trace counterexamples. Trace data lose the integral lattice/return-product quotient. |
| Very-regular classical density implies integral first-order critical specialization | It controls characteristic-zero trace identities, **not** the Tor defect of \(C_R/L_R\); taking a newly faithful trace quotient after base change deletes precisely the extension being studied. |
| A Hida/BF primitive source lifts the actual universal \(GU\) class | The coupled source class and its original scalar congruence quotient have different coefficient defects. The required comparison of the *original* central relation matrix \(P_1\), product image, and whole boundary is missing. |
| Ordinary family / higher-weight crystallinity forces critical Bloch–Kato finiteness | **399** gives a norm-compatible family whose higher-weight classes are crystalline but whose critical Tate class is not finite. The critical-\(p\) flag must be integral and actual. |
| Anticyclotomic norm compatibility annihilates tame units | **451** allows all relevant \(S\)-units to lift in that direction. Cyclotomic variation introduces real Bockstein/Tor information. |
| Automatic dyadic deletion | **436–438** have a plausible full-transfer/trace chain with explicit source dependence but not the degree of independent review required to make \(u_2=0\) a standing fact; retain \(v=2\) in (FP) until checked. |
| Characteristic/Fitting ideal or first height determinant alone determines rank | Abstract self-dual skew-Hermitian modules with equal characteristic order and unequal augmentation corank are in early archive items **8, 10, 119**. Extra transversality and point-origin theorems are genuine arithmetic hypotheses. |
| More auxiliary finite-Selmer/Heegner certificates settle all curves | The fixed E109 and E389 calculations are highly restricted, their complex analytic-rank and all-prime extensions are not proved; existence of rational correcting points can be equivalent to the rank equality sought (**67–69**). |
| Use the auxiliary \(A_4\) annihilator theorem as BSD | It gives **lower** point-rank bounds in the *same* splitting field, not the missing upper bound, complex rank, whole-\(\Sha\), or refined formula. |

These are obstacles to particular implications, **not** counterexamples to BSD.

## 6. Strong separate theorem worth preserving, but not BSD

**Archive item 453**, reconstructed from item 130, is a sharp candidate independent algebra theorem:

For every prime \(p\), finite abelian \(p\)-group \(G\), and finite-dimensional \(\mathbb Q_p[G]\)-module \(V\) with \(V^G=0\) and \(\dim_{\mathbb Q_p}V<p^4-1\), there exists \(f\in\mathbb Z_p[G]\) such that
\[
fV=0,\qquad \operatorname{aug}(f)=p^3.
\]
Hence an order-\(p^4\) element in \(H^1(G,M)\), for a finite free \(\mathbb Z_p\)-lattice \(M\), forces
\(\operatorname{rank}M-\operatorname{rank}M^G\ge p^4-1\).
Sharpness: augmentation ideal of \(\mathbb Z_p[C_{p^4}]\).

**Proof architecture, with all-prime difficult steps located exactly:** peel an order-\(p^4\) constituent; reduce to a homocyclic rank-three group; use the \(A_2/A_3\) annihilators; treat exponent \(p^2\) with the factored socle/interpolation identity; for fewer than \(p\) order-\(p^3\) types use the simultaneous integral \(B\subset\mathcal O^c\) Cayley–Hamilton/polarization lemma (the \(c! \in\mathcal O^\times\) condition is essential); in the all-low-types case reduce to the mixed-characteristic elementary-abelian norm lemma and a single factored group-ring correction. Finally use the cocycle identity \((h-1)z(g)=(g-1)z(h)\): \(f\) acts on \(H^1\) by augmentation. The **full self-contained proof** is archive **453(a)–(h)**, not this sketch; **455** records the November 8 **complete INTERNAL** reconstruction by coordinator and two separate AI reviewers, with no substantive gap found. This is **not external peer review, formal verification, or established originality/publication significance**. The literature comparison **454** (Adem, Borello–Willems–Zini, Wilde) is limited and does not establish novelty.

The arithmetic corollary applies to a Weil–Châtelet class of order \(p^4\) killed in a fixed finite abelian \(p\)-extension \(F/k\), when the stated point-torsion hypotheses hold: rank must rise by at least \(p^4-1\) **in that same \(F\)**. No independent same-field *upper* rank bound is known in this project.

## 7. Indispensable evidence, exact file identifiers, and executable paths

**Persistent source/evidence, not additional working handoffs:**

- **Complete original and recovered research / code, 37,234,822 bytes:** [BSD-complete-research-record-and-continuation-2026-11-17.txt](https://chatgpt.com/library?file_id=libfile_05ccbf94830881918dfb22a3e5b630d4&account_id=personal). Library ID `libfile_05ccbf94830881918dfb22a3e5b630d4`; exact source name. Its opening page specifies the record extraction format `BEGIN_BSD_EMBEDDED_FILES_V1` and SHA-256 validation. It contains the original full archives, later source notes, saved numerical artifacts, and explicit missing-file qualifications.
- **Latest cumulative continuation (12,117,470 bytes):** `BSD-continuation-2026-11-08.txt`, Library ID `libfile_9378c04de54c8191b9e0089be17d226f` (50 saved versions). Use the later recovered notes in the complete record when they correct this file.
- **Executable/data snapshot:** `BSD-research-reproducibility-2026-11-16.zip`, Library ID `libfile_e62f6a3f29c48191ad71d7c230fdd353`; also embedded, path-preserved in the complete record. A filename mentioned in prose is **not** proof of executable presence: check the ZIP/embedded path index.
- **Original project attachment:** `BSD-Pro-Handoff.txt.txt` (`file_00000000a06081f489b8823dd2238603`) and **lossless** `BSD-research-record-01-of-08.txt` through `-08-of-08.txt` (original numbered items through **455**). Keep originals unmodified; the November 8 update and **455** supersede the handoff appendix's older A4-review language.
- **Short proved finite-precision statement and review:** [BSD finite-precision central class research page](https://chatgpt.com/space/page_77a41f3887808191ac04ebe8095c02f7). In the complete record extract `latest/latest_finite_precision_research_page.txt`, `latest/finite_precision_GU_character_and_universal_cyclic_witness.txt`.
- **Actual source/Hecke/central-lift interfaces:** embedded paths `latest/nodal_BF_coupled_path_and_native_congruence_nonflatness_recovered.txt`; `latest/BF_coupled_path_actual_GU_spectral_row_and_boundary_jet.txt`; `latest/actual_GU_graph_character_original_base_change_and_central_class.txt`; `latest/actual_GU_character_transport_and_source_class_transgression_review.txt`; `work/nov16/original_relation_jet_central_transgression_and_raw_GU_character_loss.txt`; `latest/coordinator_graph_universality_and_codimension_two_restored.txt`.
- **Reproducible local checks, verified present in ZIP:** `work/nov16/check_mixed_characteristic_tame_image_bound.py` and matching `.json`; `work/nov16/check_e389_Up13_weight_derivative.py`, its independent `..._independent.py` and corresponding JSON; `work/nov16/check_e389_q7_new_Up13_weight_derivative.py`; `work/nov16/check_matched_row_first_order.py`; `work/nov16/check_native_Katz_HL_boundary_calibration.py`; `work/nov16/e389_good_prime_moments/e389_cyclotomic_modular_symbol_certificate.py` with its JSON and independent audit. These **check the stated finite calculations**, not a universal BSD theorem. They were not all rerun for this handoff.

**Primary theorem sources that matter most for resumption** (the source notes give exact sections and normalization):
- [Clay official BSD formulation](https://www.claymath.org/wp-content/uploads/2022/05/birchswin.pdf) and [Clay prize rules](https://www.claymath.org/wp-content/uploads/2022/03/millennium_prize_rules_0.pdf).
- [Bellaïche–Chenevier GMA and extension extraction](https://arxiv.org/pdf/math/0602340v2), especially §1.5.3 / Theorem 1.5.5.
- [Skinner, classical \(GU\) Galois traces](https://msp.org/ant/2012/6-8/ant-v6-n8-p03-s.pdf), Theorem B and §§4.2–4.3.
- [Skinner–Urban, integral Eisenstein/intertwining normalization](https://www.math.columbia.edu/~urban/eurp/MC.pdf), especially §§9.2 and 11.4; its split-\(p\) theorem is not an inert-\(p\) integral theorem.
- [Lan, ordinary PEL compactifications](https://www.kwlan.org/articles/cpt-ram-ord.pdf), Theorem 8.2.1.3, Corollaries 6.3.2.5 and 5.2.2.3; [Brasca–Rosso ordinary tower](https://arxiv.org/pdf/1711.05546).
- [Morel trace and cohomology](https://arxiv.org/pdf/0802.4451v2), §§7–8, for the **not-yet-fully-audited** dyadic chain; [Liu Iwahori theta type](https://arxiv.org/pdf/2105.14223).
- [Kings–Loeffler–Zerbes Rankin/Eisenstein](https://arxiv.org/pdf/1503.02888), including corrected tame cover conventions.
- [Fornea–Gehrmann anticyclotomic system](https://arxiv.org/html/2311.03100v2) for the *fixed-curve* Selmer moment certificates, not an analytic BSD converse.
- [Adem \(p\)-lattice cohomological exponents](https://www.math.ubc.ca/~adem/ZG-lattices.pdf); [Borello–Willems–Zini](https://web.math.ovgu.de/willems/papers/uncertainty.pdf); [Wilde](https://arxiv.org/pdf/1307.5780) for bounded A4 novelty comparisons.

## 8. Resume / review protocol (research resumed by owner on 20 November)

The owner **has now expressly authorized** private research in this chat. Do not create schedules or run background jobs. For a future GU-specific audit (NOT the present Clay-rank direction), the first independent worker should verify **(FP)** against the original module maps and hypotheses, including the nonprimitive cusp-vector-to-character argument. A second, distinct specialist should audit the actual \(GU\) whole-boundary/polarization and source-normalization chain—especially the original 425–426 big-Fitting support and the unreviewed dyadic 436–438 premises—without presuming either result from its label. If subagent tools are unavailable, perform independent proof/countermodel checks directly and label them as self-checks. Do not represent historical agent reviews as new reviews.

For the *separate auxiliary GU project only*, the old decision tree was: **(i)** produce an original finite \(GU\) character of sufficient precision and verify (FP) is applicable; **(ii)** if the construction fails, record its first exact violated map/integrality condition and investigate that arithmetic obstruction rather than changing the coefficient module; **(iii)** if the finite criterion resolves the restricted auxiliary theta case, separately prove or refute the bridge to all \(E/\mathbb Q\), complex analytic rank, whole-\(\Sha\), and the refined formula. Carry forward only rigorously supported lemmas. No novelty or publication conclusion follows automatically.

**File discipline:** future authorized changes modify **this same `BSD Conjecture.md`**, keeping the top verdict, best theorem, first open implication, and code/evidence pointers current; move a superseded line to a short “invalidated route” explanation in §5. Do not append a session log or create a new numbered handoff. Preserve source files and their original names/bytes. **Current state: research resumed on the owner's 20 November instruction; no full BSD solution ready. No autonomous background task is running.**
